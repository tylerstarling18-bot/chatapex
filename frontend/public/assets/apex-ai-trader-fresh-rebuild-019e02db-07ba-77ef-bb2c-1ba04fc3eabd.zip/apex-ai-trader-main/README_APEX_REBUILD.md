# Apex AI Trader — Fresh Rebuild MVP

This version was rebuilt from scratch around the actual product goal: a simulation-first, multi-agent crypto trading research platform.

## What is included

- Real-time market data engine using CoinGecko when available
- Fallback synthetic candle generation so the simulator always runs
- Multi-agent trading arena
- Apex Intelligence Core meta-agent
- Trade execution simulation with fees, spread, slippage, stops, take-profits, cooldowns and risk blocks
- Agent leaderboard with return, win rate, profit factor, drawdown and strategy weights
- AI explainability feed with confidence decomposition and skipped-trade reasons
- Backtest lab that runs all agents through the same replay stream
- Portfolio equity chart
- Open/closed trade tables
- Structured event logs
- Emergency stop / kill switch
- Live trading hard-disabled in code

## Safety

Live trading is disabled by design.

```env
ENABLE_LIVE_TRADING=false
```

No real exchange order placement is implemented in this MVP. The correct next step is read-only exchange adapters first.

## Run

```bash
cd src/frontend
pnpm install
pnpm dev
```

## Build

```bash
cd src/frontend
pnpm build
```

## Recommended next steps

1. Add persistent storage for trades, snapshots, agent memory and replay sessions.
2. Move the trading engine server-side so agents run even when the browser is closed.
3. Add read-only exchange adapters for Coinbase/Binance/Kraken.
4. Add database-backed user accounts and settings.
5. Add true OHLC historical candles from exchange APIs.
6. Add WebSocket broadcasting from backend to frontend.
7. Add test suite for indicators, execution, risk manager and backtesting.
