# Fresh Rebuild Changelog

## Strategy

I stopped trying to patch the generated app and rebuilt the product around the actual goal: a working autonomous crypto trading simulator and AI research terminal.

## Rebuilt files

### `src/frontend/src/lib/tradingEngine.ts`
New core trading engine containing:
- Market symbols and synthetic candle bootstrap
- CoinGecko live market snapshot fetcher
- Fallback market simulator if API fails
- Indicators: EMA, SMA, RSI, MACD, ATR, Bollinger-style bands, momentum
- Market regime detection
- Multi-agent decision logic
- Confidence decomposition
- Risk manager
- Emergency stop handling
- Trade cooldowns
- Simulated order execution
- Fees, spread, slippage
- Stop-loss and take-profit handling
- Closed trade logging
- Agent leaderboard
- Apex meta-agent weighting
- Backtest runner
- Decision/rejection log generation

### `src/frontend/src/App.tsx`
New single-page AI trading terminal containing:
- Header and safety controls
- Live market cards
- Agent leaderboard
- Portfolio equity chart
- Chart/replay panel
- Backtest lab
- AI explainability feed
- Open positions
- Closed trades
- Risk engine panel
- Structured event logs
- Safety/build notes

### `src/frontend/src/main.tsx`
Simplified React entrypoint without authentication blockers so the MVP can run immediately.

### `README_APEX_REBUILD.md`
Added run instructions, safety notes, feature list and next production steps.

## Important safety design

- Live trading is disabled.
- No real exchange execution adapter places orders.
- The app runs as simulation/paper trading only.
- Emergency stop blocks new trades.
- Agents use fake balances and simulated execution.

## Known limitations

This is a strong MVP/research terminal, not a production trading system yet.

Before real money trading, the platform still needs:
- Server-side execution
- Persistent database
- Authentication
- Read-only exchange adapters first
- True OHLC historical candles
- WebSocket backend broadcasting
- Full test suite
- Manual approval workflow
- Live trading feature flag validation
