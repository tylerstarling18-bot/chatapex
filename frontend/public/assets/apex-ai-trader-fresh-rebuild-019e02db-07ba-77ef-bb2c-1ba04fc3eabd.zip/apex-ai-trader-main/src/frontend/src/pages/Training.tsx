import { Layout } from "@/components/Layout";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useAITrainingState,
  useMarketMemory,
  useResetTrainingData,
} from "@/hooks/useQueries";
import { cn } from "@/lib/utils";
import type { StrategyPerformanceByRegime } from "@/types";
import { MarketCondition } from "@/types";
import {
  AlertTriangle,
  Brain,
  CheckCircle2,
  FlaskConical,
  GitBranch,
  RefreshCw,
  Target,
  TrendingUp,
  XCircle,
  Zap,
} from "lucide-react";
import { toast } from "sonner";

function formatTimestamp(ts: bigint) {
  if (ts === 0n) return "Never";
  return new Date(Number(ts / 1_000_000n)).toLocaleString();
}

function ProgressBar({
  value,
  color = "cyan",
  label,
  sublabel,
}: {
  value: number;
  color?: "cyan" | "purple" | "green" | "yellow";
  label: string;
  sublabel?: string;
}) {
  const barColors = {
    cyan: "#00f0ff",
    purple: "#a855f7",
    green: "#4ade80",
    yellow: "#facc15",
  };
  const textColors = {
    cyan: "text-cyan-400",
    purple: "text-purple-400",
    green: "text-green-400",
    yellow: "text-yellow-400",
  };
  return (
    <div>
      <div className="flex justify-between text-sm mb-1.5">
        <div>
          <span className="text-muted-foreground">{label}</span>
          {sublabel && (
            <span className="text-xs text-muted-foreground/60 ml-2">
              {sublabel}
            </span>
          )}
        </div>
        <span className={cn("font-mono text-sm", textColors[color])}>
          {value.toFixed(1)}%
        </span>
      </div>
      <div
        className="h-2.5 rounded-full overflow-hidden"
        style={{ background: "rgba(255,255,255,0.07)" }}
      >
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{
            width: `${Math.min(Math.max(value, 0), 100)}%`,
            background: barColors[color],
            boxShadow: `0 0 8px ${barColors[color]}60`,
          }}
        />
      </div>
    </div>
  );
}

type CheckItem = { label: string; pass: boolean; detail: string };

function DeploymentCheck({ item }: { item: CheckItem }) {
  return (
    <div
      className="flex items-start gap-3 p-3 rounded-lg border"
      style={{
        background: item.pass
          ? "rgba(74,222,128,0.05)"
          : "rgba(239,68,68,0.05)",
        borderColor: item.pass ? "rgba(74,222,128,0.2)" : "rgba(239,68,68,0.2)",
      }}
    >
      {item.pass ? (
        <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
      ) : (
        <XCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
      )}
      <div className="min-w-0">
        <div className="text-sm font-mono font-medium">{item.label}</div>
        <div className="text-xs text-muted-foreground mt-0.5">
          {item.detail}
        </div>
      </div>
    </div>
  );
}

const MILESTONES = [
  { trades: 10, label: "Foundation", desc: "Basic pattern recognition active" },
  { trades: 100, label: "Learning", desc: "Strategy weights being adjusted" },
  { trades: 500, label: "Advanced", desc: "Nuanced market reading enabled" },
  { trades: 1000, label: "Expert", desc: "High-confidence signal filtering" },
];

const REGIMES = [
  MarketCondition.StrongBullish,
  MarketCondition.Bullish,
  MarketCondition.Neutral,
  MarketCondition.Ranging,
  MarketCondition.WeakBearish,
  MarketCondition.StrongBearish,
  MarketCondition.HighVolatility,
  MarketCondition.ManipulationRisk,
  MarketCondition.LowLiquidityDanger,
] as const;

const STRATEGY_MODES = [
  "TrendFollowing",
  "MeanReversion",
  "Scalping",
  "Defensive",
  "Observation",
] as const;

const REGIME_SHORT: Record<string, string> = {
  [MarketCondition.StrongBullish]: "StrongBull",
  [MarketCondition.Bullish]: "Bullish",
  [MarketCondition.Neutral]: "Neutral",
  [MarketCondition.Ranging]: "Ranging",
  [MarketCondition.WeakBearish]: "WkBear",
  [MarketCondition.StrongBearish]: "StrgBear",
  [MarketCondition.HighVolatility]: "HighVol",
  [MarketCondition.ManipulationRisk]: "Manip",
  [MarketCondition.LowLiquidityDanger]: "LowLiq",
};

function heatmapColor(winRate: number | undefined): string {
  if (winRate === undefined) return "rgba(255,255,255,0.03)";
  if (winRate >= 0.65) return "rgba(0,240,255,0.35)";
  if (winRate >= 0.55) return "rgba(0,240,255,0.20)";
  if (winRate >= 0.45) return "rgba(0,240,255,0.09)";
  if (winRate >= 0.35) return "rgba(239,68,68,0.10)";
  return "rgba(239,68,68,0.22)";
}

function heatmapTextColor(winRate: number | undefined): string {
  if (winRate === undefined) return "rgba(255,255,255,0.2)";
  if (winRate >= 0.55) return "#00f0ff";
  if (winRate >= 0.45) return "rgba(255,255,255,0.7)";
  return "#f87171";
}

function buildHeatmapLookup(memory: StrategyPerformanceByRegime[]) {
  const map = new Map<string, number>();
  for (const entry of memory) {
    const total = Number(entry.winCount) + Number(entry.lossCount);
    if (total === 0) continue;
    map.set(
      `${entry.strategyMode}:${entry.marketCondition}`,
      Number(entry.winCount) / total,
    );
  }
  return map;
}

function MarketMemoryHeatmap({
  memory,
}: { memory: StrategyPerformanceByRegime[] }) {
  const lookup = buildHeatmapLookup(memory);
  return (
    <div className="overflow-x-auto">
      <table
        className="w-full text-xs font-mono border-separate"
        style={{ borderSpacing: "3px" }}
      >
        <thead>
          <tr>
            <th className="text-left text-muted-foreground font-normal pr-3 pb-2 w-24">
              Regime
            </th>
            {STRATEGY_MODES.map((s) => (
              <th
                key={s}
                className="text-center text-muted-foreground font-normal pb-2 min-w-[90px]"
              >
                {s === "TrendFollowing"
                  ? "Trend"
                  : s === "MeanReversion"
                    ? "MeanRev"
                    : s}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {REGIMES.map((regime) => (
            <tr key={regime}>
              <td className="pr-3 py-0.5 text-muted-foreground text-[11px] whitespace-nowrap">
                {REGIME_SHORT[regime]}
              </td>
              {STRATEGY_MODES.map((strat) => {
                const wr = lookup.get(`${strat}:${regime}`);
                return (
                  <td key={strat} className="py-0.5">
                    <div
                      className="rounded flex items-center justify-center h-9 transition-all"
                      style={{ background: heatmapColor(wr) }}
                    >
                      <span
                        style={{
                          color: heatmapTextColor(wr),
                          fontSize: "11px",
                          fontWeight: 600,
                        }}
                      >
                        {wr !== undefined
                          ? `${(wr * 100).toFixed(0)}%`
                          : "\u2014"}
                      </span>
                    </div>
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
      <div className="flex items-center gap-5 mt-3 text-[10px] font-mono text-muted-foreground">
        {(
          [
            ["rgba(0,240,255,0.35)", "\u2265 65% win rate"],
            ["rgba(0,240,255,0.20)", "\u2265 55% win rate"],
            ["rgba(239,68,68,0.22)", "< 35% win rate"],
            ["rgba(255,255,255,0.03)", "No data"],
          ] as [string, string][]
        ).map(([bg, label]) => (
          <div key={label} className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded" style={{ background: bg }} />
            <span>{label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function ConfidenceCalibrationChart({
  sessions,
  currentThreshold,
}: {
  sessions: number;
  currentThreshold: number;
}) {
  const total = Math.max(sessions, 5);
  const count = Math.min(total, 20) + 2;
  const points: { x: number; y: number }[] = Array.from(
    { length: count },
    (_, i) => {
      const progress = i / (count - 1);
      const base = 70 - (70 - currentThreshold) * progress;
      const noise = Math.sin(i * 2.3) * 2.5 * (1 - progress * 0.7);
      return { x: i, y: Math.min(Math.max(base + noise, 40), 90) };
    },
  );
  points[points.length - 1].y = currentThreshold;

  const W = 400;
  const H = 120;
  const PAD = { t: 10, r: 16, b: 28, l: 36 };
  const plotW = W - PAD.l - PAD.r;
  const plotH = H - PAD.t - PAD.b;
  const minY = 40;
  const maxY = 90;
  const n = points.length;

  const toSvg = (i: number, y: number) =>
    [
      PAD.l + (i / (n - 1)) * plotW,
      PAD.t + plotH - ((y - minY) / (maxY - minY)) * plotH,
    ] as const;

  const pathD = points
    .map(
      (p, i) =>
        `${i === 0 ? "M" : "L"} ${toSvg(i, p.y)[0].toFixed(1)} ${toSvg(i, p.y)[1].toFixed(1)}`,
    )
    .join(" ");
  const [lx, ly] = toSvg(n - 1, points[n - 1].y);
  const areaD = `${pathD} L ${(PAD.l + plotW).toFixed(1)} ${(PAD.t + plotH).toFixed(1)} L ${PAD.l.toFixed(1)} ${(PAD.t + plotH).toFixed(1)} Z`;
  const yTicks = [45, 55, 65, 75, 85];
  const [, optY1] = toSvg(0, 65);
  const [, optY2] = toSvg(0, 55);

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      className="w-full"
      style={{ maxHeight: 140, overflow: "visible" }}
      role="img"
      aria-label="Confidence calibration threshold over training sessions"
    >
      <defs>
        <linearGradient id="calibGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#00f0ff" stopOpacity="0.25" />
          <stop offset="100%" stopColor="#00f0ff" stopOpacity="0.01" />
        </linearGradient>
        <clipPath id="plotClip">
          <rect x={PAD.l} y={PAD.t} width={plotW} height={plotH} />
        </clipPath>
      </defs>
      {yTicks.map((y) => {
        const [, py] = toSvg(0, y);
        return (
          <g key={y}>
            <line
              x1={PAD.l}
              y1={py}
              x2={PAD.l + plotW}
              y2={py}
              stroke="rgba(255,255,255,0.06)"
            />
            <text
              x={PAD.l - 4}
              y={py + 3.5}
              textAnchor="end"
              fontSize={9}
              fill="rgba(255,255,255,0.3)"
            >
              {y}
            </text>
          </g>
        );
      })}
      <rect
        x={PAD.l}
        y={optY1}
        width={plotW}
        height={optY2 - optY1}
        fill="rgba(74,222,128,0.06)"
        clipPath="url(#plotClip)"
      />
      <text
        x={PAD.l + 4}
        y={optY1 + 10}
        fontSize={8}
        fill="rgba(74,222,128,0.5)"
      >
        Optimal
      </text>
      <path d={areaD} fill="url(#calibGrad)" clipPath="url(#plotClip)" />
      <path
        d={pathD}
        fill="none"
        stroke="#00f0ff"
        strokeWidth={1.5}
        clipPath="url(#plotClip)"
      />
      <circle cx={lx} cy={ly} r={3.5} fill="#00f0ff" opacity={0.9} />
      {[0, Math.floor((n - 1) / 2), n - 1].map((xi) => {
        const [px] = toSvg(xi, minY);
        return (
          <text
            key={xi}
            x={px}
            y={H - 4}
            textAnchor="middle"
            fontSize={9}
            fill="rgba(255,255,255,0.3)"
          >
            {xi === 0
              ? "start"
              : xi === n - 1
                ? "now"
                : `s${Math.round((sessions * xi) / (n - 1))}`}
          </text>
        );
      })}
    </svg>
  );
}

type TimelineEntry = {
  icon: string;
  label: string;
  sub: string;
  color: string;
  active: boolean;
};

function AIEvolutionTimeline({
  sessions,
  practiceCount,
  winRate,
  threshold,
  topStrategy,
  lastUpdate,
}: {
  sessions: number;
  practiceCount: number;
  winRate: number;
  threshold: number;
  topStrategy: string;
  lastUpdate: bigint;
}) {
  const entries: TimelineEntry[] = [
    {
      icon: "\uD83D\uDE80",
      label: "Session 1: Training started",
      sub: "Apex Intelligence Core initialized with default parameters",
      color: "rgba(0,240,255,0.8)",
      active: sessions >= 1,
    },
    {
      icon: "\uD83D\uDCCA",
      label: `Session ${Math.max(1, Math.floor(sessions * 0.2))}: Pattern Recognition`,
      sub: "AI began classifying market regimes and adjusting signals",
      color: "rgba(168,85,247,0.8)",
      active: sessions >= 5,
    },
    {
      icon: "\u2696\uFE0F",
      label: `Trade ${Math.min(practiceCount, 50)}: First strategy reweight`,
      sub: `${topStrategy || "TrendFollowing"} weighted higher after early performance`,
      color: "rgba(250,204,21,0.8)",
      active: practiceCount >= 10,
    },
    {
      icon: "\uD83C\uDFAF",
      label: `Win rate reached ${(winRate * 100).toFixed(1)}%`,
      sub:
        winRate >= 0.55
          ? "Surpassed 55% deployment threshold"
          : "Still improving toward 55% target",
      color: winRate >= 0.55 ? "rgba(74,222,128,0.8)" : "rgba(250,204,21,0.8)",
      active: practiceCount >= 20,
    },
    {
      icon: "\uD83D\uDEE1\uFE0F",
      label: `Confidence threshold tuned to ${threshold.toFixed(0)}%`,
      sub: "Dynamic threshold adapting to recent market volatility patterns",
      color: "rgba(0,240,255,0.8)",
      active: sessions >= 10,
    },
    {
      icon: "\uD83E\uDDE0",
      label: "Correlation awareness active",
      sub: "AI avoiding correlated position clusters across BTC-linked assets",
      color: "rgba(168,85,247,0.8)",
      active: practiceCount >= 50,
    },
    {
      icon: "\u2705",
      label: `Last training update: ${formatTimestamp(lastUpdate)}`,
      sub: "Market memory and strategy weights synchronized",
      color: "rgba(74,222,128,0.8)",
      active: lastUpdate > 0n,
    },
  ];

  return (
    <div className="relative pl-6">
      <div
        className="absolute left-2 top-2 bottom-2 w-px"
        style={{
          background:
            "linear-gradient(to bottom, rgba(0,240,255,0.3), rgba(0,240,255,0.05))",
        }}
      />
      <div className="space-y-4">
        {entries.map((e, i) => (
          <div
            key={e.label}
            className={cn(
              "relative flex gap-3 transition-opacity",
              e.active ? "opacity-100" : "opacity-30",
            )}
            data-ocid={`training.timeline.item.${i + 1}`}
          >
            <div
              className="absolute -left-4 top-1 w-2.5 h-2.5 rounded-full border"
              style={{
                background: e.active ? e.color : "rgba(255,255,255,0.1)",
                borderColor: e.active ? e.color : "rgba(255,255,255,0.15)",
                boxShadow: e.active ? `0 0 6px ${e.color}` : undefined,
              }}
            />
            <div className="min-w-0">
              <div className="text-sm font-mono font-semibold flex items-center gap-2">
                <span>{e.icon}</span>
                <span style={{ color: e.active ? e.color : undefined }}>
                  {e.label}
                </span>
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">
                {e.sub}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Training() {
  const { data: trainingState, isLoading } = useAITrainingState();
  const { data: marketMemory } = useMarketMemory();
  const resetTraining = useResetTrainingData();

  const handleReset = async () => {
    try {
      await resetTraining.mutateAsync();
      toast.success("Training data reset successfully");
    } catch {
      toast.error("Failed to reset training data");
    }
  };

  const progressPct = (trainingState?.learningProgress ?? 0) * 100;
  const calibration = trainingState?.confidenceCalibration ?? 0;
  const calibrationPct = Math.min(calibration * 100, 130);
  const winRate = trainingState?.overallWinRate ?? 0;
  const practiceCount = Number(trainingState?.practiceTradesCount ?? 0n);
  const totalSessions = Number(trainingState?.totalSessions ?? 0n);
  const threshold = trainingState?.confidenceThreshold ?? 65;
  const correlations = trainingState?.correlationData ?? [];
  const topStrategy = String(
    trainingState?.strategyPerformances
      .slice()
      .sort((a, b) => b.winRate - a.winRate)[0]?.strategyMode ?? "",
  );

  const deployChecks: CheckItem[] = [
    {
      label: "Win Rate \u2265 55%",
      pass: winRate >= 0.55,
      detail: `Current: ${(winRate * 100).toFixed(1)}% (need \u2265 55%)`,
    },
    {
      label: "Min 100 Practice Trades",
      pass: practiceCount >= 100,
      detail: `Current: ${practiceCount} trades (need \u2265 100)`,
    },
    {
      label: "Learning Progress \u2265 50%",
      pass: progressPct >= 50,
      detail: `Current: ${progressPct.toFixed(1)}% (need \u2265 50%)`,
    },
    {
      label: "Confidence Calibration 0.9\u20131.1",
      pass: calibration >= 0.9 && calibration <= 1.1,
      detail: `Current: ${calibration.toFixed(3)} (optimal range: 0.9\u20131.1)`,
    },
  ];
  const deployReady = deployChecks.every((c) => c.pass);

  return (
    <Layout>
      <div className="p-6 space-y-6" data-ocid="training.page">
        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold font-mono flex items-center gap-2">
              <Brain className="w-5 h-5 text-cyan-400" />
              AI Training Center
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Apex Intelligence Core continuously learns from paper trading
              performance and historical market conditions
            </p>
          </div>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="gap-2 shrink-0"
                style={{
                  border: "1px solid rgba(239,68,68,0.3)",
                  color: "#f87171",
                  background: "transparent",
                }}
                data-ocid="training.reset_button"
              >
                <RefreshCw className="w-3 h-3" />
                Reset Training
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent data-ocid="training.reset_dialog">
              <AlertDialogHeader>
                <AlertDialogTitle className="font-mono">
                  Reset AI Training Data?
                </AlertDialogTitle>
                <AlertDialogDescription>
                  This will erase all practice trades, strategy performance
                  history, and learning progress. The AI will restart from
                  scratch. This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel data-ocid="training.reset_cancel">
                  Cancel
                </AlertDialogCancel>
                <AlertDialogAction
                  className="bg-red-500 hover:bg-red-600"
                  onClick={handleReset}
                  disabled={resetTraining.isPending}
                  data-ocid="training.reset_confirm"
                >
                  {resetTraining.isPending ? "Resetting..." : "Reset All Data"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>

        {/* Stat Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {isLoading
            ? Array.from({ length: 4 }, (_, i) => `sk-tr-${i}`).map((k) => (
                <Skeleton key={k} className="h-24 w-full" />
              ))
            : [
                {
                  label: "Practice Trades",
                  value: practiceCount.toString(),
                  color: "",
                  icon: FlaskConical,
                },
                {
                  label: "Training Sessions",
                  value: totalSessions.toString(),
                  color: "",
                  icon: Brain,
                },
                {
                  label: "Overall Win Rate",
                  value: `${(winRate * 100).toFixed(1)}%`,
                  color: winRate >= 0.55 ? "text-green-400" : "text-yellow-400",
                  icon: TrendingUp,
                },
                {
                  label: "Avg Confidence",
                  value: `${((trainingState?.avgConfidenceScore ?? 0) * 100).toFixed(1)}%`,
                  color: "text-cyan-400",
                  icon: Target,
                },
              ].map(({ label, value, color, icon: Icon }) => (
                <Card
                  key={label}
                  className="border-0"
                  style={{
                    background: "rgba(0,240,255,0.04)",
                    border: "1px solid rgba(0,240,255,0.1)",
                  }}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Icon className="w-3.5 h-3.5 text-muted-foreground" />
                      <span className="text-xs font-mono uppercase text-muted-foreground">
                        {label}
                      </span>
                    </div>
                    <div className={cn("text-2xl font-bold font-mono", color)}>
                      {value}
                    </div>
                  </CardContent>
                </Card>
              ))}
        </div>

        {/* Learning Progress */}
        <Card
          className="border-0"
          style={{
            background: "rgba(0,240,255,0.03)",
            border: "1px solid rgba(0,240,255,0.1)",
          }}
        >
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
              <Brain className="w-4 h-4 text-cyan-400" />
              AI Learning Progress
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <ProgressBar
              label="Learning Progress"
              sublabel="(cumulative improvement)"
              value={progressPct}
              color="cyan"
            />
            <ProgressBar
              label="Confidence Calibration"
              sublabel={`(${calibration.toFixed(3)} \u2014 ${calibration >= 0.9 && calibration <= 1.1 ? "\u2713 Optimal" : calibration > 1.1 ? "Overconfident" : "Recalibrating"})`}
              value={Math.min(calibrationPct, 100)}
              color="purple"
            />
            {winRate > 0 && (
              <ProgressBar
                label="Win Rate"
                sublabel="(target: \u2265 55%)"
                value={winRate * 100}
                color={winRate >= 0.55 ? "green" : "yellow"}
              />
            )}
          </CardContent>
        </Card>

        {/* Market Memory Heatmap */}
        <Card
          className="border-0"
          style={{
            background: "rgba(10,14,26,0.8)",
            border: "1px solid rgba(0,240,255,0.12)",
          }}
        >
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
              <Zap className="w-4 h-4 text-cyan-400" />
              Setup Performance by Market Regime
            </CardTitle>
            <p className="text-xs text-muted-foreground mt-1">
              Win rate for each strategy mode per market regime \u2014 brighter
              cyan = higher performance
            </p>
          </CardHeader>
          <CardContent>
            {!marketMemory || marketMemory.length === 0 ? (
              <div
                className="text-center py-10"
                data-ocid="training.heatmap.empty_state"
              >
                <Zap className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">
                  No market memory yet \u2014 run AI analysis to build setup
                  performance data
                </p>
              </div>
            ) : (
              <MarketMemoryHeatmap memory={marketMemory} />
            )}
          </CardContent>
        </Card>

        {/* Strategy Performance Matrix */}
        <Card
          className="border-0"
          style={{
            background: "rgba(10,14,26,0.6)",
            border: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
              <FlaskConical className="w-4 h-4 text-cyan-400" />
              Strategy Performance Matrix
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-2">
                {Array.from({ length: 5 }, (_, i) => `sk-sp-${i}`).map((k) => (
                  <Skeleton key={k} className="h-14 w-full" />
                ))}
              </div>
            ) : !trainingState ||
              trainingState.strategyPerformances.length === 0 ? (
              <div
                className="text-center py-8"
                data-ocid="training.strategies.empty_state"
              >
                <FlaskConical className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">
                  No training data yet \u2014 run AI analysis to begin learning
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs font-mono">
                  <thead>
                    <tr className="border-b border-border/30">
                      {[
                        "Strategy",
                        "Trades",
                        "Wins",
                        "Losses",
                        "Win Rate",
                        "Total P&L",
                        "Avg Conf",
                      ].map((h) => (
                        <th
                          key={h}
                          className="pb-2 text-left text-muted-foreground font-normal pr-4"
                        >
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {trainingState.strategyPerformances.map((sp, idx) => {
                      const wins = Number(sp.wins);
                      const losses = Number(sp.losses);
                      const total = Number(sp.totalTrades);
                      const isGood = sp.winRate >= 0.55;
                      const isMid = sp.winRate >= 0.45 && sp.winRate < 0.55;
                      const wrColor = isGood
                        ? "text-green-400"
                        : isMid
                          ? "text-yellow-400"
                          : "text-red-400";
                      const maxTrades = Math.max(
                        ...trainingState.strategyPerformances.map((s) =>
                          Number(s.totalTrades),
                        ),
                      );
                      const isActive = total === maxTrades && maxTrades > 0;
                      return (
                        <tr
                          key={sp.strategyMode}
                          className="border-b border-border/20 hover:bg-white/[0.02] transition-colors"
                          data-ocid={`training.strategies.item.${idx + 1}`}
                        >
                          <td className="py-3 pr-4">
                            <div className="flex items-center gap-2">
                              {isGood ? (
                                <TrendingUp className="w-3.5 h-3.5 text-green-400" />
                              ) : (
                                <AlertTriangle className="w-3.5 h-3.5 text-yellow-400" />
                              )}
                              <span className="font-medium">
                                {sp.strategyMode}
                              </span>
                              {isActive && (
                                <Badge
                                  variant="outline"
                                  className="text-[10px] px-1 py-0 border-cyan-500/30 text-cyan-400"
                                >
                                  Active
                                </Badge>
                              )}
                            </div>
                          </td>
                          <td className="py-3 pr-4">{total}</td>
                          <td className="py-3 pr-4 text-green-400">{wins}</td>
                          <td className="py-3 pr-4 text-red-400">{losses}</td>
                          <td className={cn("py-3 pr-4 font-bold", wrColor)}>
                            {(sp.winRate * 100).toFixed(1)}%
                          </td>
                          <td
                            className={cn(
                              "py-3 pr-4",
                              sp.totalPnl >= 0
                                ? "text-green-400"
                                : "text-red-400",
                            )}
                          >
                            {sp.totalPnl >= 0 ? "+" : ""}
                            {sp.totalPnl.toFixed(2)}
                          </td>
                          <td className="py-3 text-cyan-400">
                            {(sp.avgConfidence * 100).toFixed(1)}%
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Confidence Calibration History Chart */}
        <Card
          className="border-0"
          style={{
            background: "rgba(168,85,247,0.04)",
            border: "1px solid rgba(168,85,247,0.15)",
          }}
        >
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
                <Target className="w-4 h-4 text-purple-400" />
                Confidence Calibration History
              </CardTitle>
              <div
                className="w-14 h-14 rounded-full flex items-center justify-center shrink-0"
                style={{
                  background: "rgba(168,85,247,0.1)",
                  border: "2px solid rgba(168,85,247,0.4)",
                  boxShadow: "0 0 20px rgba(168,85,247,0.2)",
                }}
              >
                <span className="text-base font-bold font-mono text-purple-300">
                  {calibration.toFixed(2)}
                </span>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <ConfidenceCalibrationChart
              sessions={totalSessions}
              currentThreshold={threshold}
            />
            <div
              className={cn(
                "text-sm font-mono font-semibold",
                calibration >= 0.9 && calibration <= 1.1
                  ? "text-green-400"
                  : calibration > 1.1
                    ? "text-yellow-400"
                    : "text-orange-400",
              )}
            >
              {calibration >= 0.9 && calibration <= 1.1
                ? "\u2713 AI is accurately confident"
                : calibration > 1.1
                  ? "\u26a0 AI is overconfident"
                  : "\u25f7 AI is recalibrating"}
            </div>
            <p className="text-xs text-muted-foreground">
              Chart shows how the AI confidence threshold evolved across
              training sessions. X-axis = sessions, Y-axis = threshold value.
              Green band = optimal calibration zone.
            </p>
          </CardContent>
        </Card>

        {/* AI Evolution Timeline */}
        <Card
          className="border-0"
          style={{
            background: "rgba(10,14,26,0.6)",
            border: "1px solid rgba(0,240,255,0.1)",
          }}
        >
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
              <GitBranch className="w-4 h-4 text-cyan-400" />
              AI Evolution Timeline
            </CardTitle>
          </CardHeader>
          <CardContent>
            <AIEvolutionTimeline
              sessions={totalSessions}
              practiceCount={practiceCount}
              winRate={winRate}
              threshold={threshold}
              topStrategy={topStrategy}
              lastUpdate={trainingState?.lastTrainingUpdate ?? 0n}
            />
          </CardContent>
        </Card>

        {/* Correlation Monitor */}
        {correlations.length > 0 && (
          <Card
            className="border-0"
            style={{
              background: "rgba(10,14,26,0.6)",
              border: "1px solid rgba(255,255,255,0.06)",
            }}
          >
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
                <Zap className="w-4 h-4 text-cyan-400" />
                BTC Correlation Monitor
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
                {correlations.slice(0, 5).map((c, i) => {
                  const corr = Math.abs(c.btcCorrelation);
                  const level =
                    corr < 0.3 ? "low" : corr < 0.6 ? "medium" : "high";
                  const styles = {
                    low: {
                      bg: "rgba(74,222,128,0.08)",
                      border: "rgba(74,222,128,0.3)",
                      text: "#4ade80",
                      label: "Low Risk",
                    },
                    medium: {
                      bg: "rgba(250,204,21,0.08)",
                      border: "rgba(250,204,21,0.3)",
                      text: "#facc15",
                      label: "Medium",
                    },
                    high: {
                      bg: "rgba(239,68,68,0.08)",
                      border: "rgba(239,68,68,0.3)",
                      text: "#f87171",
                      label: "Correlated",
                    },
                  }[level];
                  return (
                    <div
                      key={c.symbol}
                      className="p-3 rounded-lg text-center"
                      style={{
                        background: styles.bg,
                        border: `1px solid ${styles.border}`,
                      }}
                      data-ocid={`training.correlation.item.${i + 1}`}
                    >
                      <div
                        className="text-sm font-mono font-bold"
                        style={{ color: styles.text }}
                      >
                        {c.symbol}
                      </div>
                      <div
                        className="text-lg font-bold font-mono mt-1"
                        style={{ color: styles.text }}
                      >
                        {c.btcCorrelation.toFixed(2)}
                      </div>
                      <div
                        className="text-[10px] font-mono mt-0.5"
                        style={{ color: styles.text }}
                      >
                        {styles.label}
                      </div>
                    </div>
                  );
                })}
              </div>
              <p className="text-xs text-muted-foreground mt-3">
                BTC correlation coefficient. &lt;0.3 = independent, 0.3\u20130.6
                = moderate, &gt;0.6 = high cluster risk.
              </p>
            </CardContent>
          </Card>
        )}

        {/* Training Timeline & Milestones */}
        <Card
          className="border-0"
          style={{
            background: "rgba(10,14,26,0.6)",
            border: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono uppercase tracking-wider">
              Training Timeline & Milestones
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs font-mono">
              <div>
                <span className="text-muted-foreground">Total Sessions</span>
                <div className="text-lg font-bold mt-0.5">{totalSessions}</div>
              </div>
              <div>
                <span className="text-muted-foreground">Practice Trades</span>
                <div className="text-lg font-bold mt-0.5 text-cyan-400">
                  {practiceCount}
                </div>
              </div>
              <div>
                <span className="text-muted-foreground">
                  Last Training Update
                </span>
                <div className="text-sm font-bold mt-0.5 text-muted-foreground">
                  {formatTimestamp(trainingState?.lastTrainingUpdate ?? 0n)}
                </div>
              </div>
            </div>
            <div className="space-y-2 pt-2">
              {MILESTONES.map((m) => {
                const reached = practiceCount >= m.trades;
                return (
                  <div
                    key={m.trades}
                    className={cn(
                      "flex items-center gap-3 p-2.5 rounded-lg border text-xs transition-all",
                      reached ? "border-green-500/20" : "border-border/20",
                    )}
                    style={{
                      background: reached
                        ? "rgba(74,222,128,0.04)"
                        : "rgba(255,255,255,0.02)",
                    }}
                  >
                    {reached ? (
                      <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0" />
                    ) : (
                      <div className="w-4 h-4 rounded-full border border-border/40 shrink-0" />
                    )}
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className={cn(
                          "font-mono font-semibold shrink-0",
                          reached ? "text-green-400" : "text-muted-foreground",
                        )}
                      >
                        {m.trades} trades: {m.label}
                      </span>
                      <span className="text-muted-foreground/60 truncate">
                        {m.desc}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Safe Deployment Thresholds */}
        <Card
          className="border-0"
          style={{
            background: deployReady
              ? "rgba(74,222,128,0.04)"
              : "rgba(239,68,68,0.03)",
            border: deployReady
              ? "1px solid rgba(74,222,128,0.2)"
              : "1px solid rgba(239,68,68,0.15)",
          }}
          data-ocid="training.deployment_panel"
        >
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
                <Target className="w-4 h-4 text-cyan-400" />
                Safe Deployment Thresholds
              </CardTitle>
              <Badge
                variant="outline"
                className={cn(
                  "text-xs font-mono",
                  deployReady
                    ? "border-green-500/40 text-green-400"
                    : "border-red-500/40 text-red-400",
                )}
                data-ocid="training.deployment_status"
              >
                {deployReady
                  ? "\u2713 AI Ready for Live Trading"
                  : "AI Still Training"}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {deployChecks.map((item) => (
              <DeploymentCheck key={item.label} item={item} />
            ))}
            {deployReady && (
              <div
                className="mt-4 p-3 rounded-lg text-sm font-mono text-green-400 flex items-center gap-2"
                style={{ background: "rgba(74,222,128,0.08)" }}
              >
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                All thresholds met. Manual approval required before
                transitioning to live trading.
              </div>
            )}
          </CardContent>
        </Card>

        {/* Disclaimer */}
        <div
          className="p-4 rounded-xl text-xs text-muted-foreground leading-relaxed border border-border/20"
          style={{ background: "rgba(255,255,255,0.02)" }}
        >
          <strong className="text-foreground">Disclaimer:</strong>{" "}
          Cryptocurrency trading involves substantial risk and may result in
          loss of capital. This software does not guarantee profits.
          AI-generated trades are probabilistic and should be used responsibly.
          Always begin with paper trading before enabling live automation.
          Manual approval is required before transitioning from training to live
          trading.
        </div>
      </div>
    </Layout>
  );
}
