import { Layout } from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useOpenPositions,
  usePortfolio,
  useStrategyPerformances,
  useTradeHistory,
} from "@/hooks/useQueries";
import { cn } from "@/lib/utils";
import { BarChart3, PieChart, TrendingDown, TrendingUp } from "lucide-react";
import {
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

export default function Portfolio() {
  const { data: portfolio, isLoading } = usePortfolio();
  const { data: positions } = useOpenPositions();
  const { data: strategies } = useStrategyPerformances();
  const { data: trades } = useTradeHistory(200n);

  const equityCurveData = (() => {
    if (!trades || trades.length === 0) return [];
    const sorted = [...trades]
      .filter((t) => t.closeTime !== undefined && t.closeTime !== null)
      .sort((a, b) => Number(a.closeTime) - Number(b.closeTime));
    let balance = 100_000;
    return sorted.map((t, i) => {
      balance += t.pnl ?? 0;
      return { day: i + 1, value: Math.round(balance * 100) / 100 };
    });
  })();

  return (
    <Layout>
      <div className="p-6 space-y-6" data-ocid="portfolio.page">
        <div>
          <h1 className="text-xl font-bold font-mono">Portfolio Analytics</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            AI portfolio manager — exposure, performance &amp; risk
          </p>
        </div>

        {/* Key metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
          {isLoading
            ? Array.from({ length: 5 }, (_, i) => `sk-port-${i}`).map((k) => (
                <Skeleton key={k} className="h-20 w-full" />
              ))
            : [
                {
                  label: "Total Value",
                  value: `$${portfolio?.totalValue.toLocaleString("en-US", { minimumFractionDigits: 2 }) ?? "0.00"}`,
                },
                {
                  label: "Cash",
                  value: `$${portfolio?.cashBalance.toFixed(2) ?? "0.00"}`,
                },
                {
                  label: "Total P&L",
                  value: `${portfolio && portfolio.totalPnl >= 0 ? "+" : ""}$${portfolio?.totalPnl.toFixed(2) ?? "0.00"}`,
                  positive: (portfolio?.totalPnl ?? 0) >= 0,
                },
                {
                  label: "Win Rate",
                  value: `${((portfolio?.winRate ?? 0) * 100).toFixed(1)}%`,
                  positive: (portfolio?.winRate ?? 0) >= 0.5,
                },
                {
                  label: "Trades",
                  value: portfolio?.totalTrades?.toString() ?? "0",
                },
              ].map(({ label, value, positive }) => (
                <Card key={label} className="glass-panel border-0">
                  <CardContent className="p-4">
                    <div className="text-xs font-mono uppercase text-muted-foreground mb-1">
                      {label}
                    </div>
                    <div
                      className={cn(
                        "text-lg font-bold font-mono",
                        positive === true
                          ? "text-green-400"
                          : positive === false
                            ? "text-red-400"
                            : "",
                      )}
                    >
                      {value}
                    </div>
                  </CardContent>
                </Card>
              ))}
        </div>

        {/* Equity Curve */}
        <Card className="glass-panel border-0">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
              Equity Curve
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={equityCurveData}>
                <XAxis
                  dataKey="day"
                  tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }}
                />
                <YAxis tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }} />
                <Tooltip
                  contentStyle={{
                    background: "oklch(0.18 0 0)",
                    border: "1px solid oklch(0.28 0 0)",
                    borderRadius: "8px",
                  }}
                  labelStyle={{ color: "oklch(0.55 0 0)", fontSize: 11 }}
                  itemStyle={{ color: "#22d3ee", fontSize: 12 }}
                />
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke="#22d3ee"
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Positions + Strategy */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="glass-panel border-0">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
                <PieChart className="w-4 h-4 text-cyan-400" />
                Open Positions
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!positions || positions.length === 0 ? (
                <div
                  className="text-center py-6"
                  data-ocid="portfolio.positions.empty_state"
                >
                  <p className="text-sm text-muted-foreground">
                    No open positions
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {positions.map((pos, idx) => {
                    const allocation = portfolio
                      ? ((pos.quantity * pos.currentPrice) /
                          portfolio.totalValue) *
                        100
                      : 0;
                    return (
                      <div
                        key={pos.symbol}
                        className="space-y-1"
                        data-ocid={`portfolio.positions.item.${idx + 1}`}
                      >
                        <div className="flex items-center justify-between text-sm">
                          <span className="font-mono font-medium">
                            {pos.symbol}
                          </span>
                          <span
                            className={cn(
                              "font-mono",
                              pos.unrealizedPnlPercent >= 0
                                ? "text-green-400"
                                : "text-red-400",
                            )}
                          >
                            {pos.unrealizedPnlPercent >= 0 ? "+" : ""}
                            {pos.unrealizedPnlPercent.toFixed(2)}%
                          </span>
                        </div>
                        <div className="h-1.5 bg-muted/30 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-cyan-500 rounded-full"
                            style={{ width: `${Math.min(allocation, 100)}%` }}
                          />
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {allocation.toFixed(1)}% of portfolio
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="glass-panel border-0">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-cyan-400" />
                Strategy Breakdown
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!strategies || strategies.length === 0 ? (
                <div
                  className="text-center py-6"
                  data-ocid="portfolio.strategies.empty_state"
                >
                  <p className="text-sm text-muted-foreground">
                    No strategy data yet
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {strategies.map((s) => (
                    <div
                      key={s.strategyMode}
                      className="space-y-1"
                      data-ocid={`portfolio.strategies.item.${strategies.indexOf(s) + 1}`}
                    >
                      <div className="flex items-center justify-between text-sm">
                        <span className="font-mono">{s.strategyMode}</span>
                        <div className="flex items-center gap-1">
                          {s.totalPnl >= 0 ? (
                            <TrendingUp className="w-3 h-3 text-green-400" />
                          ) : (
                            <TrendingDown className="w-3 h-3 text-red-400" />
                          )}
                          <span
                            className={cn(
                              "font-mono text-xs",
                              s.totalPnl >= 0
                                ? "text-green-400"
                                : "text-red-400",
                            )}
                          >
                            {s.totalPnl >= 0 ? "+" : ""}
                            {s.totalPnl.toFixed(2)}
                          </span>
                        </div>
                      </div>
                      <div className="h-1.5 bg-muted/30 rounded-full overflow-hidden">
                        <div
                          className={cn(
                            "h-full rounded-full",
                            s.winRate >= 0.5 ? "bg-green-500" : "bg-red-500",
                          )}
                          style={{ width: `${s.winRate * 100}%` }}
                        />
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {(s.winRate * 100).toFixed(1)}% win rate ·{" "}
                        {Number(s.totalTrades)} trades
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
