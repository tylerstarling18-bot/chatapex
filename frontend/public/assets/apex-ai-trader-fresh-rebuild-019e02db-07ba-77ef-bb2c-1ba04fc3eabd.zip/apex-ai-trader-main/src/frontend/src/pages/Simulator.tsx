import type { BotConfig } from "@/backend";
import { BotStatus, TradingMode } from "@/backend";
import { Layout } from "@/components/Layout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useAllConfidenceTimeline,
  useBotConfig,
  useBotState,
  useClosePosition,
  useCurrentEquity,
  useDataFeedStatus,
  useDecisionCycleStats,
  useEmergencyStopBot,
  useEquityHistory,
  useLiveActivityFeed,
  useOpenPositions,
  usePauseBot,
  useResetBot,
  useResumeBot,
  useRunDecisionCycle,
  useRunMarketCycle,
  useSimulationStats,
  useStartBot,
  useUpdateBotConfig,
} from "@/hooks/useQueries";
import { cn } from "@/lib/utils";
import { useQueryClient } from "@tanstack/react-query";
import {
  Activity,
  AlertTriangle,
  BarChart3,
  Bot,
  ChevronDown,
  ChevronUp,
  Clock,
  Cpu,
  DollarSign,
  Gauge,
  Pause,
  Play,
  RefreshCw,
  Settings,
  ShieldAlert,
  StopCircle,
  TrendingDown,
  TrendingUp,
  Wifi,
  WifiOff,
  X,
  Zap,
} from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Scatter,
  ScatterChart,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { toast } from "sonner";

// ─── Helpers ────────────────────────────────────────────────────────────────

function fmtUSD(n: number, d = 2) {
  return n.toLocaleString("en-US", {
    minimumFractionDigits: d,
    maximumFractionDigits: d,
  });
}

function timeAgo(ns: bigint): string {
  const ms = Date.now() - Number(ns) * 1000;
  if (ms < 0) return "just now";
  if (ms < 30_000) return "just now";
  if (ms < 3_600_000) return `${Math.floor(ms / 60_000)}m ago`;
  if (ms < 86_400_000) return `${Math.floor(ms / 3_600_000)}h ago`;
  return `${Math.floor(ms / 86_400_000)}d ago`;
}

function fmtTime(ns: bigint): string {
  const d = new Date(Number(ns) * 1000);
  return d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
}

function PnlText({ value, suffix = "" }: { value: number; suffix?: string }) {
  return (
    <span
      className={cn(
        "font-mono font-bold",
        value >= 0 ? "text-green-400" : "text-red-400",
      )}
    >
      {value >= 0 ? "+" : ""}
      {value.toFixed(2)}
      {suffix}
    </span>
  );
}

const ASSET_COLORS: Record<string, string> = {
  BTC: "#f97316",
  ETH: "#6366f1",
  SOL: "#a855f7",
  BNB: "#eab308",
  AVAX: "#22c55e",
  DOT: "#ec4899",
  MATIC: "#06b6d4",
  ADA: "#3b82f6",
};

const ACTION_CFG: Record<string, { label: string; color: string }> = {
  BUY: { label: "ENTRY", color: "#22c55e" },
  ENTRY: { label: "ENTRY", color: "#22c55e" },
  SELL: { label: "EXIT", color: "#ef4444" },
  EXIT: { label: "EXIT", color: "#ef4444" },
  HOLD: { label: "HOLD", color: "#06b6d4" },
  SKIP: { label: "SKIP", color: "#64748b" },
};

function ActionBadge({ action }: { action: string }) {
  const cfg = ACTION_CFG[action.toUpperCase()] ?? {
    label: action.toUpperCase(),
    color: "#94a3b8",
  };
  return (
    <span
      className="text-[10px] font-bold font-mono px-1.5 py-0.5 rounded flex-shrink-0"
      style={{
        color: cfg.color,
        background: `${cfg.color}18`,
        border: `1px solid ${cfg.color}30`,
      }}
    >
      {cfg.label}
    </span>
  );
}

const BOT_STATUS_CFG = {
  [BotStatus.Running]: { label: "RUNNING", color: "#22c55e", pulse: true },
  [BotStatus.Paused]: { label: "PAUSED", color: "#eab308", pulse: false },
  [BotStatus.Stopped]: { label: "STOPPED", color: "#64748b", pulse: false },
  [BotStatus.EmergencyStopped]: {
    label: "EMERGENCY STOP",
    color: "#ef4444",
    pulse: true,
  },
} as const;

// ─── Countdown Timer ─────────────────────────────────────────────────────────

function CountdownTimer({
  seconds,
  label,
}: { seconds: number; label: string }) {
  return (
    <div className="flex flex-col items-center">
      <span className="text-lg font-bold font-mono text-cyan-400">
        {Math.max(0, seconds)}
      </span>
      <span className="text-[9px] font-mono text-muted-foreground uppercase tracking-wider">
        {label}
      </span>
    </div>
  );
}

// ─── Equity Chart Tooltip ─────────────────────────────────────────────────────

function EquityTooltip({
  active,
  payload,
}: {
  active?: boolean;
  payload?: Array<{ value: number; payload: { time: string } }>;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div
      className="rounded-lg px-3 py-2 text-xs font-mono"
      style={{
        background: "rgba(10,15,30,0.9)",
        border: "1px solid rgba(6,182,212,0.3)",
      }}
    >
      <p className="text-muted-foreground">{payload[0].payload.time}</p>
      <p className="text-cyan-400 font-bold">${fmtUSD(payload[0].value)}</p>
    </div>
  );
}

// ─── Simulator Page ───────────────────────────────────────────────────────────

export default function Simulator() {
  const qc = useQueryClient();

  // Bot control hooks
  const { data: botState, isLoading: botStateLoading } = useBotState();
  const { data: botConfig } = useBotConfig();
  const { data: dataFeed } = useDataFeedStatus();
  const { data: equity } = useCurrentEquity();
  const { data: equityHistory = [] } = useEquityHistory(1440n);
  const { data: activityFeed = [] } = useLiveActivityFeed(50n);
  const { data: positions = [] } = useOpenPositions();
  const { data: cycleStats } = useDecisionCycleStats();
  const { data: simStats } = useSimulationStats();
  const { data: confidenceTimeline = [] } = useAllConfidenceTimeline(200n);

  const startBot = useStartBot();
  const pauseBot = usePauseBot();
  const resumeBot = useResumeBot();
  const resetBot = useResetBot();
  const emergStop = useEmergencyStopBot();
  const runMarket = useRunMarketCycle();
  const runDecision = useRunDecisionCycle();
  const closePos = useClosePosition();
  const updateConfig = useUpdateBotConfig();

  // UI state
  const [configOpen, setConfigOpen] = useState(false);
  const [expandedItem, setExpandedItem] = useState<number | null>(null);
  const [confirmStop, setConfirmStop] = useState(false);
  const [marketCd, setMarketCd] = useState(60);
  const [decisionCd, setDecisionCd] = useState(30);

  // Local config edit state
  const [cfgEdit, setCfgEdit] = useState<BotConfig | null>(null);
  // Sync cfgEdit from botConfig whenever botConfig changes and we are not actively editing
  useEffect(() => {
    if (botConfig && !configOpen) setCfgEdit(botConfig);
    // cfgEdit intentionally excluded: we only want to reset from server data, not on local edits
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [botConfig, configOpen]);

  // Auto-cycle timers
  const marketIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const decisionIntervalRef = useRef<ReturnType<typeof setInterval> | null>(
    null,
  );
  const marketCdRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const decisionCdRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const isRunning = botState?.status === BotStatus.Running;

  // Extract primitive config values to avoid object reference instability in effect deps
  const mIntervalSecs = Number(botConfig?.refreshIntervalSecs ?? 60n);
  const dIntervalSecs = Number(botConfig?.decisionIntervalSecs ?? 60n);

  const triggerMarket = useCallback(async () => {
    try {
      await runMarket.mutateAsync();
      qc.invalidateQueries({ queryKey: ["equityHistory"] });
      qc.invalidateQueries({ queryKey: ["currentEquity"] });
    } catch {
      /* silently proceed */
    }
  }, [runMarket, qc]);

  const triggerDecision = useCallback(async () => {
    try {
      await runDecision.mutateAsync();
      qc.invalidateQueries({ queryKey: ["liveActivityFeed"] });
      qc.invalidateQueries({ queryKey: ["openPositions"] });
      qc.invalidateQueries({ queryKey: ["decisionCycleStats"] });
    } catch {
      /* silently proceed */
    }
  }, [runDecision, qc]);

  // Stable refs to always-current callbacks — intervals read these so they
  // never need to re-register just because the callback identity changed.
  const triggerMarketRef = useRef(triggerMarket);
  const triggerDecisionRef = useRef(triggerDecision);
  useEffect(() => {
    triggerMarketRef.current = triggerMarket;
  }, [triggerMarket]);
  useEffect(() => {
    triggerDecisionRef.current = triggerDecision;
  }, [triggerDecision]);

  useEffect(() => {
    // Always clear old intervals before deciding what to do.
    if (marketIntervalRef.current) clearInterval(marketIntervalRef.current);
    if (decisionIntervalRef.current) clearInterval(decisionIntervalRef.current);
    if (marketCdRef.current) clearInterval(marketCdRef.current);
    if (decisionCdRef.current) clearInterval(decisionCdRef.current);
    marketIntervalRef.current = null;
    decisionIntervalRef.current = null;
    marketCdRef.current = null;
    decisionCdRef.current = null;

    if (!isRunning) return;

    // Fire first cycles immediately so the UI shows data within seconds,
    // not after the first interval tick (which could be 60+ seconds away).
    // Use setTimeout(0) to avoid calling setState during render.
    const firstMarket = setTimeout(() => triggerMarketRef.current(), 0);
    const firstDecision = setTimeout(() => triggerDecisionRef.current(), 200);

    setMarketCd(mIntervalSecs);
    marketCdRef.current = setInterval(
      () => setMarketCd((c) => (c <= 1 ? mIntervalSecs : c - 1)),
      1000,
    );
    marketIntervalRef.current = setInterval(
      () => triggerMarketRef.current(),
      mIntervalSecs * 1000,
    );

    setDecisionCd(dIntervalSecs);
    decisionCdRef.current = setInterval(
      () => setDecisionCd((c) => (c <= 1 ? dIntervalSecs : c - 1)),
      1000,
    );
    decisionIntervalRef.current = setInterval(
      () => triggerDecisionRef.current(),
      dIntervalSecs * 1000,
    );

    return () => {
      clearTimeout(firstMarket);
      clearTimeout(firstDecision);
      if (marketIntervalRef.current) clearInterval(marketIntervalRef.current);
      if (decisionIntervalRef.current)
        clearInterval(decisionIntervalRef.current);
      if (marketCdRef.current) clearInterval(marketCdRef.current);
      if (decisionCdRef.current) clearInterval(decisionCdRef.current);
    };
    // Only primitive deps — isRunning (boolean), mIntervalSecs (number), dIntervalSecs (number).
    // Callback stability is handled via triggerMarketRef/triggerDecisionRef above.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isRunning, mIntervalSecs, dIntervalSecs]);

  // Bot startup status displayed during the async sequence
  const [startupPhase, setStartupPhase] = useState<
    "idle" | "starting" | "market" | "decision"
  >("idle");

  // Bot actions
  const handleStart = async () => {
    setStartupPhase("starting");
    try {
      const res = await startBot.mutateAsync();
      if (res.__kind__ === "err") {
        toast.error(`Failed to start bot: ${res.err}`);
        setStartupPhase("idle");
        return;
      }
      // Step 1: invalidate bot state so the UI reflects Running immediately
      await qc.invalidateQueries({ queryKey: ["botState"] });
      toast.success("Bot started — Apex Intelligence Core is live");

      // Step 2: fetch live market data first (AI needs prices before decisions)
      setStartupPhase("market");
      try {
        await runMarket.mutateAsync();
        qc.invalidateQueries({ queryKey: ["dataFeedStatus"] });
        qc.invalidateQueries({ queryKey: ["marketSnapshot"] });
        qc.invalidateQueries({ queryKey: ["equityHistory"] });
        qc.invalidateQueries({ queryKey: ["currentEquity"] });
      } catch (_err) {
        // Market cycle failure is non-fatal — log and continue to decision cycle
        toast.warning(
          "Market data fetch had an issue — decision cycle may be limited",
        );
      }

      // Step 3: run first decision cycle now that we have market data
      setStartupPhase("decision");
      try {
        await runDecision.mutateAsync();
        qc.invalidateQueries({ queryKey: ["liveActivityFeed"] });
        qc.invalidateQueries({ queryKey: ["openPositions"] });
        qc.invalidateQueries({ queryKey: ["decisionCycleStats"] });
        qc.invalidateQueries({ queryKey: ["botState"] });
      } catch (_err) {
        toast.warning(
          "Initial decision cycle encountered an issue — will retry on next cycle",
        );
      }
    } catch {
      toast.error("Failed to start bot — please try again");
    } finally {
      setStartupPhase("idle");
    }
  };

  const handlePause = async () => {
    try {
      await pauseBot.mutateAsync();
      toast.info("Bot paused");
    } catch {
      toast.error("Failed to pause bot");
    }
  };

  const handleResume = async () => {
    try {
      await resumeBot.mutateAsync();
      toast.success("Bot resumed");
    } catch {
      toast.error("Failed to resume bot");
    }
  };

  const handleReset = async () => {
    try {
      await resetBot.mutateAsync();
      toast.info("Bot reset to initial state");
    } catch {
      toast.error("Failed to reset bot");
    }
  };

  const handleEmergencyStop = async () => {
    if (!confirmStop) {
      setConfirmStop(true);
      return;
    }
    try {
      await emergStop.mutateAsync();
      setConfirmStop(false);
      toast.error("⚠️ Emergency stop — all activity halted");
    } catch {
      toast.error("Failed to trigger emergency stop");
    }
  };

  const handleClosePosition = async (symbol: string) => {
    try {
      await closePos.mutateAsync(symbol);
      toast.success(`Closed ${symbol} position`);
    } catch {
      toast.error(`Failed to close ${symbol}`);
    }
  };

  const handleSaveConfig = async () => {
    if (!cfgEdit) return;
    try {
      const res = await updateConfig.mutateAsync(cfgEdit);
      if (res.__kind__ === "err") {
        toast.error(res.err);
        return;
      }
      toast.success("Bot configuration saved");
      setConfigOpen(false);
    } catch {
      toast.error("Failed to save config");
    }
  };

  // Derived data
  const status = botState?.status ?? BotStatus.Stopped;
  const statusCfg = BOT_STATUS_CFG[status] ?? BOT_STATUS_CFG[BotStatus.Stopped];

  const equityCurveData = equityHistory.map((s) => ({
    time: fmtTime(s.timestamp),
    value: s.equity,
  }));

  const sessionStart =
    equityHistory.length > 0
      ? equityHistory[0].equity
      : (equity?.equity ?? 10000);
  const currentVal = equity?.equity ?? sessionStart;
  const sessionPnl = currentVal - sessionStart;
  const sessionPnlPct =
    sessionStart > 0 ? (sessionPnl / sessionStart) * 100 : 0;

  const confChartData = confidenceTimeline.map((pt) => ({
    x: Number(pt.timestamp) * 1000,
    y: pt.confidence * 100,
    asset: pt.asset,
    action: pt.action,
    color: ASSET_COLORS[pt.asset] ?? "#94a3b8",
  }));

  const uptimeSecs = Number(botState?.uptimeSeconds ?? 0n);
  const uptimeStr =
    uptimeSecs < 60
      ? `${uptimeSecs}s`
      : uptimeSecs < 3600
        ? `${Math.floor(uptimeSecs / 60)}m ${uptimeSecs % 60}s`
        : `${Math.floor(uptimeSecs / 3600)}h ${Math.floor((uptimeSecs % 3600) / 60)}m`;

  const dataStale =
    dataFeed?.staleSince !== undefined
      ? Date.now() - Number(dataFeed.staleSince as bigint) * 1000 > 90_000
      : false;

  return (
    <Layout>
      <div className="p-5 space-y-4" data-ocid="simulator.page">
        {/* ── Bot Status Bar ── */}
        <div
          className="rounded-xl p-4"
          style={{
            background: "rgba(6,182,212,0.04)",
            border: "1px solid rgba(6,182,212,0.18)",
          }}
          data-ocid="simulator.status_bar"
        >
          <div className="flex flex-wrap items-center gap-4">
            {/* Status pill */}
            <div className="flex items-center gap-2.5">
              <div
                className={cn(
                  "w-3 h-3 rounded-full flex-shrink-0",
                  statusCfg.pulse && "animate-pulse",
                )}
                style={{
                  background: statusCfg.color,
                  boxShadow: `0 0 8px ${statusCfg.color}80`,
                }}
              />
              <span
                className="text-sm font-bold font-mono"
                style={{ color: statusCfg.color }}
              >
                BOT: {statusCfg.label}
              </span>
            </div>

            {/* Data feed health */}
            <div className="flex items-center gap-1.5">
              {dataFeed?.healthy && !dataStale ? (
                <Wifi className="w-3.5 h-3.5 text-green-400" />
              ) : (
                <WifiOff className="w-3.5 h-3.5 text-red-400" />
              )}
              <span
                className={cn(
                  "text-xs font-mono",
                  dataFeed?.healthy && !dataStale
                    ? "text-green-400"
                    : "text-red-400",
                )}
              >
                FEED:{" "}
                {dataFeed?.healthy && !dataStale
                  ? "HEALTHY"
                  : dataStale
                    ? "STALE"
                    : "OFFLINE"}
              </span>
              <span className="text-[10px] font-mono text-muted-foreground">
                ({(dataFeed?.assetCount ?? 0n).toString()} assets)
              </span>
            </div>

            {/* Uptime */}
            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-muted-foreground" />
              <span className="text-xs font-mono text-muted-foreground">
                UPTIME:{" "}
              </span>
              <span className="text-xs font-mono text-foreground">
                {uptimeStr}
              </span>
            </div>

            {/* Session stats */}
            <div className="flex items-center gap-3 text-xs font-mono">
              <span className="text-muted-foreground">Decisions:</span>
              <span className="text-foreground">
                {(botState?.decisionCycleCount ?? 0n).toString()}
              </span>
              <span className="text-muted-foreground">Trades:</span>
              <span className="text-foreground">
                {(botState?.tradesExecutedCount ?? 0n).toString()}
              </span>
              <span className="text-muted-foreground">Win Rate:</span>
              <span className="text-green-400">
                {((cycleStats?.winRate ?? 0) * 100).toFixed(1)}%
              </span>
            </div>

            {/* Cycle countdowns */}
            {isRunning && (
              <div
                className="flex items-center gap-4 px-3 py-1.5 rounded-lg ml-auto"
                style={{
                  background: "rgba(6,182,212,0.08)",
                  border: "1px solid rgba(6,182,212,0.15)",
                }}
              >
                <CountdownTimer seconds={marketCd} label="Market" />
                <div
                  className="w-px h-8"
                  style={{ background: "rgba(6,182,212,0.2)" }}
                />
                <CountdownTimer seconds={decisionCd} label="Decision" />
              </div>
            )}

            {/* Bot Controls */}
            <div className="flex items-center gap-2 ml-auto">
              {botStateLoading ? (
                <Skeleton className="h-8 w-48" />
              ) : status === BotStatus.Stopped ? (
                <div className="flex flex-col items-start gap-1">
                  <Button
                    size="sm"
                    className="gap-1.5 text-xs font-mono bg-green-500 hover:bg-green-400 text-background border-0"
                    onClick={handleStart}
                    disabled={startupPhase !== "idle" || startBot.isPending}
                    data-ocid="simulator.start_button"
                  >
                    {startupPhase !== "idle" || startBot.isPending ? (
                      <RefreshCw className="w-3 h-3 animate-spin" />
                    ) : (
                      <Play className="w-3 h-3" />
                    )}
                    START BOT
                  </Button>
                  {startupPhase !== "idle" && (
                    <span
                      className="text-[9px] font-mono text-cyan-400 animate-pulse"
                      data-ocid="simulator.startup_status"
                    >
                      {startupPhase === "starting" && "Starting bot…"}
                      {startupPhase === "market" && "Fetching market data…"}
                      {startupPhase === "decision" && "Running AI analysis…"}
                    </span>
                  )}
                </div>
              ) : status === BotStatus.Running ? (
                <Button
                  size="sm"
                  variant="outline"
                  className="gap-1.5 text-xs font-mono"
                  style={{
                    borderColor: "rgba(234,179,8,0.4)",
                    color: "#eab308",
                  }}
                  onClick={handlePause}
                  disabled={pauseBot.isPending}
                  data-ocid="simulator.pause_button"
                >
                  <Pause className="w-3 h-3" />
                  PAUSE
                </Button>
              ) : status === BotStatus.Paused ? (
                <Button
                  size="sm"
                  className="gap-1.5 text-xs font-mono bg-cyan-500 hover:bg-cyan-400 text-background border-0"
                  onClick={handleResume}
                  disabled={resumeBot.isPending}
                  data-ocid="simulator.resume_button"
                >
                  <Play className="w-3 h-3" />
                  RESUME
                </Button>
              ) : null}

              <Button
                size="sm"
                variant="outline"
                className="gap-1.5 text-xs font-mono"
                style={{
                  borderColor: "rgba(100,116,139,0.4)",
                  color: "#94a3b8",
                }}
                onClick={handleReset}
                disabled={resetBot.isPending}
                data-ocid="simulator.reset_button"
              >
                <RefreshCw className="w-3 h-3" />
                RESET
              </Button>

              {/* Emergency Stop */}
              <Button
                size="sm"
                className={cn(
                  "gap-1.5 text-xs font-bold font-mono border-0",
                  confirmStop
                    ? "bg-red-500 animate-pulse hover:bg-red-400 text-white"
                    : "bg-red-500/20 hover:bg-red-500 text-red-400 hover:text-white border border-red-500/40",
                )}
                onClick={handleEmergencyStop}
                disabled={emergStop.isPending}
                data-ocid="simulator.emergency_stop_button"
              >
                <StopCircle className="w-3 h-3" />
                {confirmStop ? "CONFIRM STOP" : "E-STOP"}
              </Button>
              {confirmStop && (
                <Button
                  size="sm"
                  variant="outline"
                  className="gap-1.5 text-xs font-mono"
                  onClick={() => setConfirmStop(false)}
                  data-ocid="simulator.cancel_estop_button"
                >
                  <X className="w-3 h-3" />
                  Cancel
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* ── Row 1: Equity Curve + Cycle Stats + Sim Costs ── */}
        <div className="grid grid-cols-1 xl:grid-cols-10 gap-4">
          {/* Equity Curve 60% */}
          <div
            className="xl:col-span-6 glass-panel rounded-xl"
            data-ocid="simulator.equity_panel"
          >
            <div
              className="px-5 pt-4 pb-3 border-b"
              style={{ borderColor: "rgba(6,182,212,0.12)" }}
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <TrendingUp
                      className="w-3.5 h-3.5"
                      style={{ color: "#06b6d4" }}
                    />
                    <span
                      className="text-[11px] font-mono uppercase tracking-widest"
                      style={{ color: "#06b6d4" }}
                    >
                      Equity Curve
                    </span>
                    <Badge
                      variant="outline"
                      className="text-[9px] font-mono"
                      style={{
                        borderColor: "rgba(6,182,212,0.3)",
                        color: "#06b6d4",
                      }}
                    >
                      24H
                    </Badge>
                  </div>
                  <p className="text-[10px] font-mono text-muted-foreground mt-0.5">
                    Session P&L: <PnlText value={sessionPnl} /> (
                    <PnlText value={sessionPnlPct} suffix="%" />)
                  </p>
                </div>
                <div className="text-right">
                  <div
                    className="text-xl font-bold font-mono"
                    style={{ color: "#06b6d4" }}
                  >
                    ${fmtUSD(currentVal)}
                  </div>
                  <div className="text-[10px] font-mono text-muted-foreground">
                    Cash: ${fmtUSD(equity?.cash ?? 0)} · Pos: $
                    {fmtUSD(equity?.positionValue ?? 0)}
                  </div>
                </div>
              </div>
            </div>
            <div className="px-5 py-4">
              {equityCurveData.length < 1 ? (
                <div className="flex flex-col items-center justify-center h-48 gap-3">
                  {isRunning ? (
                    <>
                      <div className="flex items-center gap-2">
                        <RefreshCw className="w-4 h-4 animate-spin text-cyan-400" />
                        <span className="text-sm font-mono text-cyan-400">
                          Initializing…
                        </span>
                      </div>
                      <span className="text-xs font-mono text-muted-foreground">
                        First market cycle in progress
                      </span>
                    </>
                  ) : (
                    <span className="text-muted-foreground text-sm font-mono">
                      Start the bot to track equity
                    </span>
                  )}
                </div>
              ) : (
                <ResponsiveContainer width="100%" height={200}>
                  <AreaChart
                    data={equityCurveData}
                    margin={{ top: 4, right: 4, left: 0, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient
                        id="equityGrad"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop
                          offset="5%"
                          stopColor="#06b6d4"
                          stopOpacity={0.18}
                        />
                        <stop
                          offset="95%"
                          stopColor="#06b6d4"
                          stopOpacity={0}
                        />
                      </linearGradient>
                    </defs>
                    <CartesianGrid
                      strokeDasharray="3 3"
                      stroke="rgba(255,255,255,0.04)"
                    />
                    <XAxis
                      dataKey="time"
                      tick={{
                        fontSize: 9,
                        fontFamily: "monospace",
                        fill: "rgba(148,163,184,0.5)",
                      }}
                      axisLine={false}
                      tickLine={false}
                      interval="preserveStartEnd"
                    />
                    <YAxis
                      tick={{
                        fontSize: 9,
                        fontFamily: "monospace",
                        fill: "rgba(148,163,184,0.5)",
                      }}
                      axisLine={false}
                      tickLine={false}
                      tickFormatter={(v: number) =>
                        `$${(v / 1000).toFixed(0)}k`
                      }
                      width={44}
                    />
                    <Tooltip content={<EquityTooltip />} />
                    <Area
                      type="monotone"
                      dataKey="value"
                      stroke="#06b6d4"
                      strokeWidth={2}
                      fill="url(#equityGrad)"
                      dot={false}
                      activeDot={{ r: 4, fill: "#06b6d4", strokeWidth: 0 }}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          {/* Right col: Cycle Stats + Sim Costs 40% */}
          <div className="xl:col-span-4 flex flex-col gap-4">
            {/* Decision Cycle Stats */}
            <div
              className="glass-panel rounded-xl p-5"
              data-ocid="simulator.cycle_stats_panel"
            >
              <div className="flex items-center gap-2 mb-3">
                <Cpu className="w-3.5 h-3.5" style={{ color: "#a855f7" }} />
                <span
                  className="text-[11px] font-mono uppercase tracking-widest"
                  style={{ color: "#a855f7" }}
                >
                  Decision Engine
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {[
                  {
                    label: "Total Cycles",
                    value: (cycleStats?.totalCycles ?? 0n).toString(),
                  },
                  {
                    label: "No-Trade Rate",
                    value: `${((cycleStats?.noTradeRate ?? 0) * 100).toFixed(1)}%`,
                  },
                  {
                    label: "Avg Confidence",
                    value: `${((cycleStats?.avgConfidence ?? 0) * 100).toFixed(1)}%`,
                  },
                  {
                    label: "Cycles/Hour",
                    value: (cycleStats?.cyclesPerHour ?? 0).toFixed(1),
                  },
                  {
                    label: "Win Rate",
                    value: `${((cycleStats?.winRate ?? 0) * 100).toFixed(1)}%`,
                    color: "#22c55e",
                  },
                  {
                    label: "Trades/Session",
                    value: (cycleStats?.tradesThisSession ?? 0n).toString(),
                  },
                ].map(({ label, value, color }) => (
                  <div
                    key={label}
                    className="rounded-lg p-2"
                    style={{
                      background: "rgba(255,255,255,0.03)",
                      border: "1px solid rgba(255,255,255,0.06)",
                    }}
                  >
                    <p className="text-[9px] font-mono text-muted-foreground">
                      {label}
                    </p>
                    <p
                      className="text-sm font-bold font-mono"
                      style={{ color: color ?? "#e2e8f0" }}
                    >
                      {value}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Simulation Cost Tracker */}
            <div
              className="glass-panel rounded-xl p-5"
              data-ocid="simulator.sim_costs_panel"
            >
              <div className="flex items-center gap-2 mb-3">
                <Gauge className="w-3.5 h-3.5" style={{ color: "#eab308" }} />
                <span
                  className="text-[11px] font-mono uppercase tracking-widest"
                  style={{ color: "#eab308" }}
                >
                  Simulation Fidelity
                </span>
              </div>
              <div className="space-y-2">
                {[
                  {
                    label: "Total Slippage",
                    value: `$${fmtUSD(simStats?.totalSlippageCost ?? 0)}`,
                    pct: `${((simStats?.avgSlippagePct ?? 0) * 100).toFixed(3)}%`,
                  },
                  {
                    label: "Total Fees",
                    value: `$${fmtUSD(simStats?.totalFeeCost ?? 0)}`,
                    pct: `${((simStats?.avgFeePct ?? 0) * 100).toFixed(3)}%`,
                  },
                  {
                    label: "Total Spread",
                    value: `$${fmtUSD(simStats?.totalSpreadCost ?? 0)}`,
                    pct: "",
                  },
                ].map(({ label, value, pct }) => (
                  <div
                    key={label}
                    className="flex items-center justify-between"
                  >
                    <span className="text-xs font-mono text-muted-foreground">
                      {label}
                    </span>
                    <span className="text-xs font-mono text-foreground">
                      {value}{" "}
                      <span className="text-muted-foreground">{pct}</span>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* ── Row 2: Activity Feed + Active Positions ── */}
        <div className="grid grid-cols-1 xl:grid-cols-5 gap-4">
          {/* Live Activity Feed 60% */}
          <div
            className="xl:col-span-3 glass-panel rounded-xl flex flex-col"
            data-ocid="simulator.activity_feed_panel"
          >
            <div
              className="px-5 pt-4 pb-3 border-b"
              style={{ borderColor: "rgba(6,182,212,0.12)" }}
            >
              <div className="flex items-center gap-2">
                <Activity
                  className="w-3.5 h-3.5"
                  style={{ color: "#06b6d4" }}
                />
                <span
                  className="text-[11px] font-mono uppercase tracking-widest"
                  style={{ color: "#06b6d4" }}
                >
                  Live Activity Feed
                </span>
                <span className="ml-auto text-[10px] font-mono text-muted-foreground">
                  auto-updates every 15s
                </span>
              </div>
            </div>
            <div
              className="flex-1 overflow-y-auto max-h-80 px-3 py-2"
              data-ocid="simulator.activity_list"
            >
              {activityFeed.length === 0 ? (
                <div
                  className="flex flex-col items-center justify-center h-32"
                  data-ocid="simulator.activity_feed.empty_state"
                >
                  <Bot
                    className="w-8 h-8 mb-2"
                    style={{ color: "rgba(6,182,212,0.25)" }}
                  />
                  <p className="text-sm font-mono text-muted-foreground">
                    No activity yet
                  </p>
                  <p className="text-xs font-mono text-muted-foreground mt-0.5">
                    Start the bot to see live decisions
                  </p>
                </div>
              ) : (
                activityFeed.map((item, idx) => (
                  <button
                    type="button"
                    key={`${item.asset}-${item.timestamp.toString()}-${idx}`}
                    className="w-full text-left py-2.5 border-b cursor-pointer hover:bg-muted/10 rounded px-2 transition-colors"
                    style={{ borderColor: "rgba(255,255,255,0.05)" }}
                    onClick={() =>
                      setExpandedItem(expandedItem === idx ? null : idx)
                    }
                    onKeyDown={(e) => {
                      if (e.key === "Enter" || e.key === " ")
                        setExpandedItem(expandedItem === idx ? null : idx);
                    }}
                    data-ocid={`simulator.activity.item.${idx + 1}`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono text-muted-foreground min-w-[52px]">
                        {timeAgo(item.timestamp)}
                      </span>
                      <span
                        className="text-[10px] font-bold font-mono px-1.5 py-0.5 rounded"
                        style={{
                          color: ASSET_COLORS[item.asset] ?? "#94a3b8",
                          background: `${ASSET_COLORS[item.asset] ?? "#94a3b8"}18`,
                          border: `1px solid ${ASSET_COLORS[item.asset] ?? "#94a3b8"}30`,
                        }}
                      >
                        {item.asset}
                      </span>
                      <ActionBadge action={item.action} />
                      <span className="text-[10px] font-mono text-cyan-400 ml-auto">
                        {(item.confidence * 100).toFixed(0)}%
                      </span>
                      {item.executed ? (
                        <Zap className="w-3 h-3 text-green-400 flex-shrink-0" />
                      ) : (
                        <span className="w-3 h-3 flex-shrink-0" />
                      )}
                    </div>
                    {expandedItem === idx ? (
                      <p className="text-[11px] font-mono text-muted-foreground mt-1.5 leading-relaxed">
                        {item.reasoning}
                      </p>
                    ) : (
                      <p className="text-[10px] font-mono text-muted-foreground mt-1 line-clamp-1">
                        {item.reasoning.length > 80
                          ? `${item.reasoning.slice(0, 80)}…`
                          : item.reasoning}
                      </p>
                    )}
                  </button>
                ))
              )}
            </div>
          </div>

          {/* Active Positions 40% */}
          <div
            className="xl:col-span-2 glass-panel rounded-xl flex flex-col"
            data-ocid="simulator.positions_panel"
          >
            <div
              className="px-5 pt-4 pb-3 border-b"
              style={{ borderColor: "rgba(34,197,94,0.15)" }}
            >
              <div className="flex items-center gap-2">
                <TrendingUp
                  className="w-3.5 h-3.5"
                  style={{ color: "#22c55e" }}
                />
                <span
                  className="text-[11px] font-mono uppercase tracking-widest"
                  style={{ color: "#22c55e" }}
                >
                  Active Positions
                </span>
                {positions.length > 0 && (
                  <Badge
                    variant="outline"
                    className="ml-auto text-[10px] font-mono"
                    style={{
                      borderColor: "rgba(34,197,94,0.3)",
                      color: "#22c55e",
                    }}
                  >
                    {positions.length} open
                  </Badge>
                )}
              </div>
            </div>
            <div className="px-5 py-3 flex-1 overflow-y-auto max-h-80">
              {positions.length === 0 ? (
                <div
                  className="flex flex-col items-center justify-center h-32"
                  data-ocid="simulator.positions.empty_state"
                >
                  <Play
                    className="w-8 h-8 mb-2"
                    style={{ color: "rgba(34,197,94,0.2)" }}
                  />
                  <p className="text-sm font-mono text-muted-foreground">
                    No open positions
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {positions.map((pos, idx) => {
                    const sl = pos.stopLoss;
                    const tp = pos.takeProfit ?? pos.currentPrice * 1.05;
                    const range = tp - sl;
                    const progress =
                      range > 0
                        ? Math.min(
                            100,
                            Math.max(
                              0,
                              ((pos.currentPrice - sl) / range) * 100,
                            ),
                          )
                        : 50;
                    return (
                      <div
                        key={pos.symbol}
                        className="p-3 rounded-lg"
                        style={{
                          background: "rgba(255,255,255,0.03)",
                          border: "1px solid rgba(255,255,255,0.06)",
                        }}
                        data-ocid={`simulator.positions.item.${idx + 1}`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-2">
                            <span
                              className="text-xs font-bold font-mono"
                              style={{
                                color: ASSET_COLORS[pos.symbol] ?? "#e2e8f0",
                              }}
                            >
                              {pos.symbol}
                            </span>
                            <span className="text-[10px] font-mono text-muted-foreground">
                              {timeAgo(pos.openTime)}
                            </span>
                          </div>
                          <PnlText
                            value={pos.unrealizedPnlPercent}
                            suffix="%"
                          />
                        </div>
                        <div className="flex justify-between text-[10px] font-mono mb-1.5">
                          <span className="text-muted-foreground">
                            {pos.quantity.toFixed(4)} @ $
                            {fmtUSD(pos.averageEntryPrice)}
                          </span>
                          <span
                            style={{
                              color:
                                pos.unrealizedPnl >= 0 ? "#22c55e" : "#ef4444",
                            }}
                          >
                            {pos.unrealizedPnl >= 0 ? "+" : ""}$
                            {fmtUSD(pos.unrealizedPnl)}
                          </span>
                        </div>
                        {/* Stop-loss to take-profit bar */}
                        <div
                          className="relative h-1.5 rounded-full overflow-hidden mb-2"
                          style={{ background: "rgba(255,255,255,0.07)" }}
                        >
                          <div
                            className="absolute left-0 top-0 h-full rounded-full"
                            style={{
                              width: `${progress}%`,
                              background:
                                pos.unrealizedPnl >= 0 ? "#22c55e" : "#ef4444",
                            }}
                          />
                        </div>
                        <div className="flex justify-between text-[9px] font-mono text-muted-foreground mb-2">
                          <span style={{ color: "#ef4444" }}>
                            SL ${fmtUSD(sl)}
                          </span>
                          <span style={{ color: "#22c55e" }}>
                            TP ${fmtUSD(tp)}
                          </span>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          className="w-full h-6 text-[10px] font-mono gap-1"
                          style={{
                            borderColor: "rgba(239,68,68,0.3)",
                            color: "#ef4444",
                          }}
                          onClick={() => handleClosePosition(pos.symbol)}
                          disabled={closePos.isPending}
                          data-ocid={`simulator.close_position_button.${idx + 1}`}
                        >
                          <X className="w-2.5 h-2.5" />
                          Close Position
                        </Button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* ── Row 3: Confidence Timeline + Market Data Health ── */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
          {/* Confidence Timeline 67% */}
          <div
            className="xl:col-span-2 glass-panel rounded-xl"
            data-ocid="simulator.confidence_chart_panel"
          >
            <div
              className="px-5 pt-4 pb-3 border-b"
              style={{ borderColor: "rgba(168,85,247,0.15)" }}
            >
              <div className="flex items-center gap-2">
                <BarChart3
                  className="w-3.5 h-3.5"
                  style={{ color: "#a855f7" }}
                />
                <span
                  className="text-[11px] font-mono uppercase tracking-widest"
                  style={{ color: "#a855f7" }}
                >
                  AI Confidence Timeline
                </span>
                <div className="flex items-center gap-2 ml-auto">
                  {Object.entries(ASSET_COLORS)
                    .slice(0, 5)
                    .map(([a, c]) => (
                      <span key={a} className="flex items-center gap-1">
                        <span
                          className="w-2 h-2 rounded-full"
                          style={{ background: c }}
                        />
                        <span className="text-[9px] font-mono text-muted-foreground">
                          {a}
                        </span>
                      </span>
                    ))}
                </div>
              </div>
            </div>
            <div className="px-5 py-4">
              {confChartData.length < 2 ? (
                <div className="flex items-center justify-center h-40 text-muted-foreground text-xs font-mono">
                  No confidence data yet — run decision cycles to populate
                </div>
              ) : (
                <ResponsiveContainer width="100%" height={180}>
                  <ScatterChart
                    margin={{ top: 4, right: 4, left: 0, bottom: 0 }}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      stroke="rgba(255,255,255,0.04)"
                    />
                    <XAxis
                      dataKey="x"
                      type="number"
                      scale="time"
                      domain={["auto", "auto"]}
                      tick={{
                        fontSize: 9,
                        fontFamily: "monospace",
                        fill: "rgba(148,163,184,0.4)",
                      }}
                      tickFormatter={(v: number) =>
                        new Date(v).toLocaleTimeString("en-US", {
                          hour: "2-digit",
                          minute: "2-digit",
                        })
                      }
                      axisLine={false}
                      tickLine={false}
                    />
                    <YAxis
                      dataKey="y"
                      type="number"
                      domain={[0, 100]}
                      tick={{
                        fontSize: 9,
                        fontFamily: "monospace",
                        fill: "rgba(148,163,184,0.4)",
                      }}
                      axisLine={false}
                      tickLine={false}
                      tickFormatter={(v: number) => `${v}%`}
                      width={36}
                    />
                    <Tooltip
                      content={({ active, payload }) => {
                        if (!active || !payload?.length) return null;
                        const d = payload[0].payload as {
                          asset: string;
                          y: number;
                          action: string;
                        };
                        return (
                          <div
                            className="rounded-lg px-3 py-2 text-xs font-mono"
                            style={{
                              background: "rgba(10,15,30,0.9)",
                              border: "1px solid rgba(168,85,247,0.3)",
                            }}
                          >
                            <p
                              className="font-bold"
                              style={{
                                color: ASSET_COLORS[d.asset] ?? "#94a3b8",
                              }}
                            >
                              {d.asset}
                            </p>
                            <p className="text-muted-foreground">
                              {d.action} · {d.y.toFixed(1)}% confidence
                            </p>
                          </div>
                        );
                      }}
                    />
                    <Scatter data={confChartData} fill="#a855f7" />
                  </ScatterChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          {/* Market Data Health 33% */}
          <div
            className="glass-panel rounded-xl p-5"
            data-ocid="simulator.data_health_panel"
          >
            <div className="flex items-center gap-2 mb-4">
              {dataFeed?.healthy ? (
                <Wifi className="w-3.5 h-3.5 text-green-400" />
              ) : (
                <WifiOff className="w-3.5 h-3.5 text-red-400" />
              )}
              <span
                className="text-[11px] font-mono uppercase tracking-widest"
                style={{ color: dataFeed?.healthy ? "#22c55e" : "#ef4444" }}
              >
                Data Feed Status
              </span>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-muted-foreground">
                  Feed Health
                </span>
                <span
                  className={cn(
                    "text-xs font-bold font-mono",
                    dataFeed?.healthy ? "text-green-400" : "text-red-400",
                  )}
                >
                  {dataFeed?.healthy ? "HEALTHY" : "OFFLINE"}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-muted-foreground">
                  Assets Tracked
                </span>
                <span className="text-xs font-mono text-foreground">
                  {(dataFeed?.assetCount ?? 0n).toString()}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-muted-foreground">
                  Last Fetch
                </span>
                <span className="text-xs font-mono text-foreground">
                  {dataFeed?.lastFetchAt
                    ? timeAgo(dataFeed.lastFetchAt as bigint)
                    : "—"}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-muted-foreground">
                  Data Stale
                </span>
                <span
                  className={cn(
                    "text-xs font-bold font-mono",
                    dataStale ? "text-red-400" : "text-green-400",
                  )}
                >
                  {dataStale ? "⚠️ YES" : "NO"}
                </span>
              </div>
            </div>
            {dataStale && (
              <div
                className="mt-3 p-2 rounded-lg flex items-center gap-2"
                style={{
                  background: "rgba(239,68,68,0.1)",
                  border: "1px solid rgba(239,68,68,0.2)",
                }}
              >
                <AlertTriangle className="w-3.5 h-3.5 text-red-400 flex-shrink-0" />
                <p className="text-[10px] font-mono text-red-400">
                  Data &gt;90s old — AI operating on stale prices
                </p>
              </div>
            )}
          </div>
        </div>

        {/* ── Bot Config (collapsible) ── */}
        <div
          className="glass-panel rounded-xl"
          data-ocid="simulator.config_panel"
        >
          <button
            type="button"
            className="w-full px-5 py-3 flex items-center gap-2 text-left"
            onClick={() => setConfigOpen(!configOpen)}
            data-ocid="simulator.config_toggle"
          >
            <Settings className="w-3.5 h-3.5 text-muted-foreground" />
            <span className="text-[11px] font-mono uppercase tracking-widest text-muted-foreground">
              Bot Configuration
            </span>
            {configOpen ? (
              <ChevronUp className="w-4 h-4 ml-auto text-muted-foreground" />
            ) : (
              <ChevronDown className="w-4 h-4 ml-auto text-muted-foreground" />
            )}
          </button>
          {configOpen && cfgEdit && (
            <div
              className="px-5 pb-5 border-t"
              style={{ borderColor: "rgba(255,255,255,0.06)" }}
            >
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5 mt-4">
                {/* Refresh Interval */}
                <div>
                  <label
                    htmlFor="cfg-refresh-interval"
                    className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground block mb-1"
                  >
                    Market Refresh Interval:{" "}
                    {cfgEdit.refreshIntervalSecs.toString()}s
                  </label>
                  <input
                    id="cfg-refresh-interval"
                    type="range"
                    min={30}
                    max={300}
                    step={10}
                    value={Number(cfgEdit.refreshIntervalSecs)}
                    onChange={(e) =>
                      setCfgEdit({
                        ...cfgEdit,
                        refreshIntervalSecs: BigInt(e.target.value),
                      })
                    }
                    className="w-full accent-cyan-500"
                    data-ocid="simulator.config.refresh_interval"
                  />
                  <div className="flex justify-between text-[9px] font-mono text-muted-foreground mt-0.5">
                    <span>30s</span>
                    <span>300s</span>
                  </div>
                </div>

                {/* Decision Interval */}
                <div>
                  <label
                    htmlFor="cfg-decision-interval"
                    className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground block mb-1"
                  >
                    Decision Interval: {cfgEdit.decisionIntervalSecs.toString()}
                    s
                  </label>
                  <input
                    id="cfg-decision-interval"
                    type="range"
                    min={60}
                    max={300}
                    step={10}
                    value={Number(cfgEdit.decisionIntervalSecs)}
                    onChange={(e) =>
                      setCfgEdit({
                        ...cfgEdit,
                        decisionIntervalSecs: BigInt(e.target.value),
                      })
                    }
                    className="w-full accent-cyan-500"
                    data-ocid="simulator.config.decision_interval"
                  />
                  <div className="flex justify-between text-[9px] font-mono text-muted-foreground mt-0.5">
                    <span>60s</span>
                    <span>300s</span>
                  </div>
                </div>

                {/* Trading Mode */}
                <div>
                  <label
                    htmlFor="cfg-trading-mode"
                    className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground block mb-1"
                  >
                    Trading Mode
                  </label>
                  <select
                    id="cfg-trading-mode"
                    className="w-full rounded-lg px-3 py-2 text-xs font-mono bg-muted border-border text-foreground"
                    value={cfgEdit.tradingMode}
                    onChange={(e) =>
                      setCfgEdit({
                        ...cfgEdit,
                        tradingMode: e.target.value as TradingMode,
                      })
                    }
                    data-ocid="simulator.config.trading_mode_select"
                  >
                    {Object.values(TradingMode).map((m) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Slippage */}
                <div>
                  <label
                    htmlFor="cfg-slippage"
                    className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground block mb-1"
                  >
                    Slippage %:{" "}
                    {(cfgEdit.simulationFidelity.slippagePct * 100).toFixed(3)}%
                  </label>
                  <input
                    type="number"
                    step="0.001"
                    min="0"
                    max="1"
                    value={(
                      cfgEdit.simulationFidelity.slippagePct * 100
                    ).toFixed(3)}
                    onChange={(e) =>
                      setCfgEdit({
                        ...cfgEdit,
                        simulationFidelity: {
                          ...cfgEdit.simulationFidelity,
                          slippagePct: Number.parseFloat(e.target.value) / 100,
                        },
                      })
                    }
                    className="w-full rounded-lg px-3 py-2 text-xs font-mono bg-muted border border-border text-foreground"
                    id="cfg-slippage"
                    data-ocid="simulator.config.slippage_input"
                  />
                </div>

                {/* Fee Taker */}
                <div>
                  <label
                    htmlFor="cfg-fee-taker"
                    className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground block mb-1"
                  >
                    Fee Taker %:{" "}
                    {(cfgEdit.simulationFidelity.feeTakerPct * 100).toFixed(3)}%
                  </label>
                  <input
                    type="number"
                    step="0.001"
                    min="0"
                    max="1"
                    value={(
                      cfgEdit.simulationFidelity.feeTakerPct * 100
                    ).toFixed(3)}
                    onChange={(e) =>
                      setCfgEdit({
                        ...cfgEdit,
                        simulationFidelity: {
                          ...cfgEdit.simulationFidelity,
                          feeTakerPct: Number.parseFloat(e.target.value) / 100,
                        },
                      })
                    }
                    className="w-full rounded-lg px-3 py-2 text-xs font-mono bg-muted border border-border text-foreground"
                    id="cfg-fee-taker"
                    data-ocid="simulator.config.fee_taker_input"
                  />
                </div>

                {/* Fee Maker */}
                <div>
                  <label
                    htmlFor="cfg-fee-maker"
                    className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground block mb-1"
                  >
                    Fee Maker %:{" "}
                    {(cfgEdit.simulationFidelity.feeMakerPct * 100).toFixed(3)}%
                  </label>
                  <input
                    type="number"
                    step="0.001"
                    min="0"
                    max="1"
                    value={(
                      cfgEdit.simulationFidelity.feeMakerPct * 100
                    ).toFixed(3)}
                    onChange={(e) =>
                      setCfgEdit({
                        ...cfgEdit,
                        simulationFidelity: {
                          ...cfgEdit.simulationFidelity,
                          feeMakerPct: Number.parseFloat(e.target.value) / 100,
                        },
                      })
                    }
                    className="w-full rounded-lg px-3 py-2 text-xs font-mono bg-muted border border-border text-foreground"
                    id="cfg-fee-maker"
                    data-ocid="simulator.config.fee_maker_input"
                  />
                </div>

                {/* Volatility position sizing toggle */}
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                    Volatility Position Sizing
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      setCfgEdit({
                        ...cfgEdit,
                        volatilityPositionSizing:
                          !cfgEdit.volatilityPositionSizing,
                      })
                    }
                    className={cn(
                      "relative w-10 h-5 rounded-full transition-colors",
                      cfgEdit.volatilityPositionSizing
                        ? "bg-cyan-500"
                        : "bg-muted",
                    )}
                    data-ocid="simulator.config.volatility_sizing_toggle"
                    aria-label="Toggle volatility position sizing"
                  >
                    <span
                      className={cn(
                        "absolute top-0.5 w-4 h-4 rounded-full bg-foreground transition-transform",
                        cfgEdit.volatilityPositionSizing
                          ? "translate-x-5"
                          : "translate-x-0.5",
                      )}
                    />
                  </button>
                </div>
              </div>

              <div className="mt-4 flex items-center gap-3">
                <Button
                  size="sm"
                  className="gap-1.5 text-xs font-mono bg-cyan-500 hover:bg-cyan-400 text-background border-0"
                  onClick={handleSaveConfig}
                  disabled={updateConfig.isPending}
                  data-ocid="simulator.config.save_button"
                >
                  {updateConfig.isPending ? (
                    <RefreshCw className="w-3 h-3 animate-spin" />
                  ) : (
                    <ShieldAlert className="w-3 h-3" />
                  )}
                  Save Configuration
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="text-xs font-mono"
                  onClick={() => {
                    setCfgEdit(botConfig ?? cfgEdit);
                    setConfigOpen(false);
                  }}
                  data-ocid="simulator.config.cancel_button"
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Disclaimer */}
        <p className="text-[9px] font-mono text-muted-foreground text-center leading-relaxed">
          ⚠️ Paper Trading Mode · Cryptocurrency trading involves substantial
          risk. AI-generated decisions are probabilistic. Always begin with
          paper trading before enabling live automation.
        </p>
      </div>
    </Layout>
  );
}
