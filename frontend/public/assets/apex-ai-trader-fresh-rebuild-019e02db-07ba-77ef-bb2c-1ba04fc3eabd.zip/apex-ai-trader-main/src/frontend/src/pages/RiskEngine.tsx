import { Layout } from "@/components/Layout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import {
  useEmergencyStop,
  useResumeTrading,
  useRiskEvents,
  useRiskSettings,
  useRiskStatus,
  useUpdateRiskSettings,
} from "@/hooks/useQueries";
import { cn } from "@/lib/utils";
import { RiskSeverity } from "@/types";
import type { RiskSettings } from "@/types";
import {
  Activity,
  AlertOctagon,
  AlertTriangle,
  BookOpen,
  CheckCircle,
  Cpu,
  Play,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Sliders,
  StopCircle,
  TrendingDown,
  Zap,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

// ─── Arc Gauge ────────────────────────────────────────────────────────────────
function ArcGauge({
  value,
  max = 100,
  label,
  color,
}: {
  value: number;
  max?: number;
  label: string;
  color: string;
}) {
  const pct = Math.min(Math.max(value / max, 0), 1);
  const r = 42;
  const cx = 56;
  const cy = 56;
  const startAngle = 220;
  const sweep = 280;
  const endAngle = startAngle + sweep * pct;

  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const trackEnd = startAngle + sweep;

  const arcPath = (from: number, to: number) => {
    const x1 = cx + r * Math.cos(toRad(from));
    const y1 = cy + r * Math.sin(toRad(from));
    const x2 = cx + r * Math.cos(toRad(to));
    const y2 = cy + r * Math.sin(toRad(to));
    const large = to - from > 180 ? 1 : 0;
    return `M ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2}`;
  };

  return (
    <div className="flex flex-col items-center gap-1">
      <svg
        width="112"
        height="80"
        viewBox="0 0 112 90"
        role="img"
        aria-label="Risk gauge"
      >
        <path
          d={arcPath(startAngle, trackEnd)}
          fill="none"
          stroke="rgba(255,255,255,0.08)"
          strokeWidth="8"
          strokeLinecap="round"
        />
        {pct > 0 && (
          <path
            d={arcPath(startAngle, endAngle)}
            fill="none"
            stroke={color}
            strokeWidth="8"
            strokeLinecap="round"
            style={{ filter: `drop-shadow(0 0 6px ${color})` }}
          />
        )}
        <text
          x={cx}
          y={cy - 2}
          textAnchor="middle"
          fill="white"
          fontSize="16"
          fontWeight="bold"
          fontFamily="monospace"
        >
          {Math.round(pct * max)}
        </text>
        <text
          x={cx}
          y={cy + 14}
          textAnchor="middle"
          fill="rgba(255,255,255,0.5)"
          fontSize="9"
          fontFamily="monospace"
        >
          / {max}
        </text>
      </svg>
      <span className="text-xs text-muted-foreground font-mono">{label}</span>
    </div>
  );
}

// ─── Horizontal bar gauge ────────────────────────────────────────────────────
function BarGauge({
  value,
  max,
  label,
  unit = "%",
  color,
}: {
  value: number;
  max: number;
  label: string;
  unit?: string;
  color: string;
}) {
  const pct = Math.min((value / max) * 100, 100);
  return (
    <div className="space-y-1.5">
      <div className="flex justify-between text-xs">
        <span className="text-muted-foreground font-mono">{label}</span>
        <span className="font-mono font-bold" style={{ color }}>
          {value.toFixed(2)}
          {unit}
        </span>
      </div>
      <div
        className="h-2 rounded-full"
        style={{ background: "rgba(255,255,255,0.08)" }}
      >
        <div
          className="h-2 rounded-full transition-all duration-700"
          style={{
            width: `${pct}%`,
            background: color,
            boxShadow: `0 0 8px ${color}`,
          }}
        />
      </div>
      <div className="flex justify-between text-xs text-muted-foreground font-mono">
        <span>0{unit}</span>
        <span>
          {max}
          {unit}
        </span>
      </div>
    </div>
  );
}

// ─── Risk gauge color helper ─────────────────────────────────────────────────
function riskColor(score: number) {
  if (score < 30) return "#22c55e";
  if (score < 60) return "#eab308";
  return "#ef4444";
}

// ─── Settings Slider ─────────────────────────────────────────────────────────
function SettingSlider({
  label,
  sublabel,
  value,
  min,
  max,
  step,
  unit,
  onChange,
  ocid,
}: {
  label: string;
  sublabel?: string;
  value: number;
  min: number;
  max: number;
  step: number;
  unit: string;
  onChange: (v: number) => void;
  ocid: string;
}) {
  return (
    <div className="space-y-2">
      <div className="flex justify-between items-baseline">
        <div>
          <Label className="text-sm font-medium">{label}</Label>
          {sublabel && (
            <p className="text-xs text-muted-foreground mt-0.5">{sublabel}</p>
          )}
        </div>
        <span className="font-mono font-bold text-cyan-400 text-sm">
          {value}
          {unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        data-ocid={ocid}
        className="w-full accent-cyan-500"
        style={{ height: "4px" }}
      />
      <div className="flex justify-between text-xs text-muted-foreground font-mono">
        <span>
          {min}
          {unit}
        </span>
        <span>
          {max}
          {unit}
        </span>
      </div>
    </div>
  );
}

// ─── Main Component ──────────────────────────────────────────────────────────
export default function RiskEngine() {
  const { data: riskStatus } = useRiskStatus();
  const { data: riskSettings } = useRiskSettings();
  const { data: riskEvents } = useRiskEvents(20n);
  const emergencyStop = useEmergencyStop();
  const resumeTrading = useResumeTrading();
  const updateSettings = useUpdateRiskSettings();

  const [showEmergencyDialog, setShowEmergencyDialog] = useState(false);
  const [showResumeDialog, setShowResumeDialog] = useState(false);
  const [localSettings, setLocalSettings] = useState<RiskSettings | null>(null);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const settings = localSettings ?? riskSettings;
  const syncLocal = (patch: Partial<RiskSettings>) => {
    setLocalSettings((prev) => ({
      ...(prev ?? (riskSettings as RiskSettings)),
      ...patch,
    }));
  };

  const handleEmergencyStop = async () => {
    setShowEmergencyDialog(false);
    try {
      await emergencyStop.mutateAsync();
      toast.error("⛔ Emergency Stop Activated", {
        description: "All trading has been halted immediately.",
        duration: 6000,
      });
    } catch {
      toast.error("Failed to trigger emergency stop");
    }
  };

  const handleResume = async () => {
    setShowResumeDialog(false);
    try {
      await resumeTrading.mutateAsync();
      toast.success("✅ Trading Resumed", {
        description: "The AI trading engine is now active.",
      });
    } catch {
      toast.error("Failed to resume trading");
    }
  };

  const handleSaveSettings = async () => {
    if (!settings) return;
    try {
      await updateSettings.mutateAsync(settings as RiskSettings);
      setLocalSettings(null);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
      toast.success("Risk settings saved successfully");
    } catch {
      toast.error("Failed to save risk settings");
    }
  };

  const riskPct = riskStatus?.riskScore ?? 0;
  const dailyLossPct = riskStatus?.dailyLossPercent ?? 0;
  const consecutiveLosses = Number(riskStatus?.consecutiveLosses ?? 0);
  const maxConsecutive = Number(settings?.maxConsecutiveLosses ?? 3);
  const maxDailyLoss = settings?.maxDailyLossPercent ?? 5;
  const isEmergencyStopped = riskStatus?.isPaused ?? false;
  const isPaused = riskStatus?.isPaused ?? false;

  const tradingStatusLabel = isEmergencyStopped
    ? "EMERGENCY STOP"
    : isPaused
      ? "PAUSED"
      : "ACTIVE";

  const tradingStatusColor = isEmergencyStopped
    ? "#ef4444"
    : isPaused
      ? "#eab308"
      : "#22c55e";

  const dailyLossColor =
    dailyLossPct < maxDailyLoss * 0.5
      ? "#22c55e"
      : dailyLossPct < maxDailyLoss * 0.8
        ? "#eab308"
        : "#ef4444";

  return (
    <Layout>
      <div className="p-6 space-y-6" data-ocid="risk.page">
        {/* ── EMERGENCY STOP BANNER ─────────────────────────────────────── */}
        {isPaused && (
          <div
            className="relative flex items-center gap-4 p-4 rounded-xl border overflow-hidden"
            style={{
              background: isEmergencyStopped
                ? "rgba(239,68,68,0.12)"
                : "rgba(234,179,8,0.10)",
              borderColor: isEmergencyStopped
                ? "rgba(239,68,68,0.5)"
                : "rgba(234,179,8,0.5)",
              boxShadow: isEmergencyStopped
                ? "0 0 24px rgba(239,68,68,0.2)"
                : "0 0 24px rgba(234,179,8,0.15)",
            }}
            data-ocid="risk.status_banner"
          >
            <div
              className="w-3 h-3 rounded-full flex-shrink-0"
              style={{
                background: tradingStatusColor,
                boxShadow: `0 0 12px ${tradingStatusColor}`,
                animation: "pulse 1.5s ease-in-out infinite",
              }}
            />
            <div className="flex-1">
              <div
                className="font-bold font-mono text-sm"
                style={{ color: tradingStatusColor }}
              >
                ⚠ TRADING {tradingStatusLabel} — All autonomous activity halted
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">
                Daily loss: {dailyLossPct.toFixed(2)}% · Consecutive losses:{" "}
                {consecutiveLosses} · Risk score: {riskPct.toFixed(0)}/100
              </div>
            </div>
            {isPaused && (
              <Button
                size="sm"
                onClick={() => setShowResumeDialog(true)}
                disabled={resumeTrading.isPending}
                className="gap-1.5 text-xs"
                style={{
                  background: "rgba(34,197,94,0.2)",
                  color: "#22c55e",
                  border: "1px solid rgba(34,197,94,0.4)",
                }}
                data-ocid="risk.resume_banner_button"
              >
                <Play className="w-3 h-3" />
                Resume
              </Button>
            )}
          </div>
        )}

        {/* ── PAGE HEADER + EMERGENCY BUTTON ───────────────────────────── */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{
                background: "rgba(239,68,68,0.15)",
                border: "1px solid rgba(239,68,68,0.3)",
              }}
            >
              <ShieldAlert className="w-5 h-5" style={{ color: "#ef4444" }} />
            </div>
            <div>
              <h1 className="text-xl font-bold font-mono">
                Risk Management Engine
              </h1>
              <p className="text-xs text-muted-foreground mt-0.5">
                Capital protection &amp; autonomous risk controls
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Trading Status Badge */}
            <div
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-mono font-bold"
              style={{
                background: `${tradingStatusColor}18`,
                border: `1px solid ${tradingStatusColor}40`,
                color: tradingStatusColor,
              }}
              data-ocid="risk.trading_status"
            >
              <div
                className="w-2 h-2 rounded-full"
                style={{
                  background: tradingStatusColor,
                  animation: isPaused
                    ? "pulse 1.5s ease-in-out infinite"
                    : "none",
                }}
              />
              {tradingStatusLabel}
            </div>

            {isPaused && (
              <Button
                size="sm"
                onClick={() => setShowResumeDialog(true)}
                disabled={resumeTrading.isPending}
                className="gap-1.5 text-xs"
                style={{
                  background: "rgba(34,197,94,0.15)",
                  color: "#22c55e",
                  border: "1px solid rgba(34,197,94,0.4)",
                }}
                data-ocid="risk.resume_button"
              >
                <Play className="w-3 h-3" />
                Resume Trading
              </Button>
            )}

            {/* EMERGENCY STOP */}
            <button
              type="button"
              onClick={() => setShowEmergencyDialog(true)}
              disabled={emergencyStop.isPending || isPaused}
              data-ocid="risk.emergency_stop_button"
              className="relative flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold font-mono text-sm uppercase tracking-wide transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              style={{
                background: isPaused
                  ? "rgba(239,68,68,0.1)"
                  : "rgba(239,68,68,0.2)",
                border: "2px solid rgba(239,68,68,0.7)",
                color: "#fca5a5",
                boxShadow: isPaused
                  ? "none"
                  : "0 0 20px rgba(239,68,68,0.4), inset 0 0 20px rgba(239,68,68,0.05)",
              }}
            >
              <StopCircle className="w-4 h-4" style={{ color: "#ef4444" }} />
              Emergency Stop
            </button>
          </div>
        </div>

        {/* ── TOP STATS ROW ────────────────────────────────────────────── */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            {
              label: "Daily Loss Today",
              value: `${dailyLossPct.toFixed(2)}%`,
              sub: `of ${maxDailyLoss}% limit`,
              icon: TrendingDown,
              color:
                dailyLossPct > maxDailyLoss * 0.8
                  ? "#ef4444"
                  : dailyLossPct > maxDailyLoss * 0.5
                    ? "#eab308"
                    : "#22c55e",
              ocid: "risk.daily_loss_stat",
            },
            {
              label: "Consecutive Losses",
              value: `${consecutiveLosses} / ${maxConsecutive}`,
              sub: "before auto-pause",
              icon: AlertTriangle,
              color:
                consecutiveLosses >= maxConsecutive
                  ? "#ef4444"
                  : consecutiveLosses >= maxConsecutive - 1
                    ? "#eab308"
                    : "#06b6d4",
              ocid: "risk.consecutive_losses_stat",
            },
            {
              label: "Overall Risk Score",
              value: `${riskPct.toFixed(0)} / 100`,
              sub:
                riskPct < 30
                  ? "Low risk"
                  : riskPct < 60
                    ? "Moderate"
                    : "High risk",
              icon: Activity,
              color: riskColor(riskPct),
              ocid: "risk.risk_score_stat",
            },
            {
              label: "Mode",
              value: settings?.enablePaperTrading ? "Paper" : "Live",
              sub: settings?.conservativeMode
                ? "Conservative on"
                : "Normal mode",
              icon: settings?.enablePaperTrading ? ShieldCheck : Cpu,
              color: settings?.enablePaperTrading ? "#06b6d4" : "#a855f7",
              ocid: "risk.mode_stat",
            },
          ].map(({ label, value, sub, icon: Icon, color, ocid }) => (
            <div
              key={label}
              className="glass-panel rounded-xl p-4"
              data-ocid={ocid}
            >
              <div className="flex items-center gap-2 mb-2">
                <Icon className="w-4 h-4" style={{ color }} />
                <span className="text-xs text-muted-foreground font-mono">
                  {label}
                </span>
              </div>
              <div className="font-bold font-mono text-lg" style={{ color }}>
                {value}
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">{sub}</div>
            </div>
          ))}
        </div>

        {/* ── RISK GAUGES + SETTINGS ───────────────────────────────────── */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Left: Gauges */}
          <div className="lg:col-span-2 space-y-4">
            <Card className="glass-panel border-0">
              <CardHeader className="pb-3">
                <CardTitle className="text-xs font-mono uppercase tracking-widest flex items-center gap-2">
                  <Shield className="w-4 h-4" style={{ color: "#06b6d4" }} />
                  Risk Gauges
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Arc gauges row */}
                <div className="grid grid-cols-2 gap-4">
                  <ArcGauge
                    value={riskPct}
                    max={100}
                    label="Overall Risk"
                    color={riskColor(riskPct)}
                  />
                  <ArcGauge
                    value={consecutiveLosses}
                    max={maxConsecutive}
                    label="Consec. Losses"
                    color={
                      consecutiveLosses >= maxConsecutive
                        ? "#ef4444"
                        : "#06b6d4"
                    }
                  />
                </div>

                {/* Bar gauges */}
                <div className="space-y-4">
                  <BarGauge
                    value={dailyLossPct}
                    max={maxDailyLoss}
                    label="Daily Loss vs Limit"
                    unit="%"
                    color={dailyLossColor}
                  />
                  <BarGauge
                    value={riskPct}
                    max={100}
                    label="Portfolio Concentration"
                    unit=""
                    color={riskColor(riskPct)}
                  />
                  <BarGauge
                    value={Math.min(riskPct * 0.8, 100)}
                    max={100}
                    label="Market Volatility Index"
                    unit=""
                    color="#a855f7"
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right: Settings */}
          <div className="lg:col-span-3">
            <Card className="glass-panel border-0">
              <CardHeader className="pb-3">
                <CardTitle className="text-xs font-mono uppercase tracking-widest flex items-center gap-2">
                  <Sliders className="w-4 h-4" style={{ color: "#06b6d4" }} />
                  Risk Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {!settings ? (
                  <p className="text-sm text-muted-foreground">
                    Loading settings...
                  </p>
                ) : (
                  <>
                    {/* Sliders */}
                    <div className="space-y-5">
                      <SettingSlider
                        label="Max Daily Loss Limit"
                        sublabel="Auto-pause triggered when this threshold is reached"
                        value={settings.maxDailyLossPercent}
                        min={0.5}
                        max={20}
                        step={0.5}
                        unit="%"
                        onChange={(v) => syncLocal({ maxDailyLossPercent: v })}
                        ocid="risk.max_daily_loss_input"
                      />
                      <SettingSlider
                        label="Max Position Size"
                        sublabel="Per-trade capital allocation ceiling"
                        value={settings.maxPositionSizePercent}
                        min={0.1}
                        max={10}
                        step={0.1}
                        unit="%"
                        onChange={(v) =>
                          syncLocal({ maxPositionSizePercent: v })
                        }
                        ocid="risk.max_position_size_input"
                      />
                      <SettingSlider
                        label="Max Consecutive Losses"
                        sublabel="AI pauses trading after this many sequential losses"
                        value={Number(settings.maxConsecutiveLosses)}
                        min={1}
                        max={10}
                        step={1}
                        unit=""
                        onChange={(v) =>
                          syncLocal({ maxConsecutiveLosses: BigInt(v) })
                        }
                        ocid="risk.max_consecutive_losses_input"
                      />
                    </div>

                    <Separator
                      style={{ background: "rgba(255,255,255,0.06)" }}
                    />

                    {/* Toggles */}
                    <div className="space-y-4">
                      {[
                        {
                          key: "enablePaperTrading" as keyof RiskSettings,
                          label: "Paper Trading Mode",
                          sub: "Simulate trades with no real capital at risk",
                          icon: ShieldCheck,
                          color: "#06b6d4",
                          ocid: "risk.paper_trading_switch",
                        },
                        {
                          key: "conservativeMode" as keyof RiskSettings,
                          label: "Conservative Mode",
                          sub: "Reduces aggression during uncertainty & volatility spikes",
                          icon: Shield,
                          color: "#22c55e",
                          ocid: "risk.conservative_mode_switch",
                        },
                        {
                          key: "emergencyStopEnabled" as keyof RiskSettings,
                          label: "Auto Emergency Stop",
                          sub: "Automatically halt all trading on critical risk events",
                          icon: AlertOctagon,
                          color: "#ef4444",
                          ocid: "risk.emergency_stop_switch",
                        },
                      ].map(({ key, label, sub, icon: Icon, color, ocid }) => (
                        <div
                          key={key}
                          className="flex items-center justify-between p-3 rounded-lg"
                          style={{ background: "rgba(255,255,255,0.03)" }}
                        >
                          <div className="flex items-center gap-3">
                            <Icon className="w-4 h-4" style={{ color }} />
                            <div>
                              <Label className="text-sm font-medium cursor-pointer">
                                {label}
                              </Label>
                              <p className="text-xs text-muted-foreground mt-0.5">
                                {sub}
                              </p>
                            </div>
                          </div>
                          <Switch
                            checked={settings[key] as boolean}
                            onCheckedChange={(v) => syncLocal({ [key]: v })}
                            data-ocid={ocid}
                          />
                        </div>
                      ))}
                    </div>

                    {/* Save Button */}
                    <div className="flex items-center gap-3 pt-1">
                      <button
                        type="button"
                        onClick={handleSaveSettings}
                        disabled={updateSettings.isPending || !localSettings}
                        data-ocid="risk.save_settings_button"
                        className="flex-1 py-2.5 rounded-lg font-mono font-bold text-sm uppercase tracking-wide transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed"
                        style={{
                          background: localSettings
                            ? "rgba(6,182,212,0.2)"
                            : "rgba(255,255,255,0.04)",
                          border: `1px solid ${localSettings ? "rgba(6,182,212,0.5)" : "rgba(255,255,255,0.1)"}`,
                          color: localSettings
                            ? "#06b6d4"
                            : "rgba(255,255,255,0.3)",
                          boxShadow: localSettings
                            ? "0 0 16px rgba(6,182,212,0.2)"
                            : "none",
                        }}
                      >
                        {updateSettings.isPending
                          ? "Saving..."
                          : "Save Risk Settings"}
                      </button>
                      {saveSuccess && (
                        <div
                          className="flex items-center gap-1.5 text-xs font-mono"
                          style={{ color: "#22c55e" }}
                          data-ocid="risk.settings.success_state"
                        >
                          <CheckCircle className="w-4 h-4" />
                          Saved
                        </div>
                      )}
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* ── RISK RULES ───────────────────────────────────────────────── */}
        <Card className="glass-panel border-0">
          <CardHeader className="pb-3">
            <CardTitle className="text-xs font-mono uppercase tracking-widest flex items-center gap-2">
              <BookOpen className="w-4 h-4" style={{ color: "#a855f7" }} />
              Risk Rule Definitions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {[
                {
                  trigger: "Daily Loss Limit Hit",
                  action: "All trading halts until midnight UTC reset",
                  icon: TrendingDown,
                  color: "#ef4444",
                },
                {
                  trigger: `${maxConsecutive} Consecutive Losses`,
                  action: "AI enters 30-min cooling period before resuming",
                  icon: AlertTriangle,
                  color: "#eab308",
                },
                {
                  trigger: "Risk Score > 80",
                  action:
                    "Position sizing reduced by 50%, conservative mode forced",
                  icon: Activity,
                  color: "#ef4444",
                },
                {
                  trigger: "Volatility Spike Detected",
                  action: "New entries paused until volatility normalizes",
                  icon: Zap,
                  color: "#a855f7",
                },
                {
                  trigger: "Emergency Stop Triggered",
                  action:
                    "All positions closed, engine offline, manual reset required",
                  icon: StopCircle,
                  color: "#ef4444",
                },
                {
                  trigger: "Conservative Mode ON",
                  action:
                    "Max position size halved, only high-confidence signals taken",
                  icon: Shield,
                  color: "#22c55e",
                },
              ].map(({ trigger, action, icon: Icon, color }) => (
                <div
                  key={trigger}
                  className="p-3 rounded-lg space-y-1.5"
                  style={{
                    background: "rgba(255,255,255,0.03)",
                    border: "1px solid rgba(255,255,255,0.06)",
                  }}
                >
                  <div className="flex items-center gap-2">
                    <Icon
                      className="w-3.5 h-3.5 flex-shrink-0"
                      style={{ color }}
                    />
                    <span
                      className="text-xs font-mono font-bold"
                      style={{ color }}
                    >
                      {trigger}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {action}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* ── RISK EVENT LOG ───────────────────────────────────────────── */}
        <Card className="glass-panel border-0">
          <CardHeader className="pb-3">
            <CardTitle className="text-xs font-mono uppercase tracking-widest flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" style={{ color: "#06b6d4" }} />
              Risk Event Log
              {riskEvents && riskEvents.length > 0 && (
                <Badge
                  variant="outline"
                  className="ml-auto text-xs font-mono"
                  style={{
                    borderColor: "rgba(6,182,212,0.3)",
                    color: "#06b6d4",
                  }}
                >
                  {riskEvents.length} events
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!riskEvents || riskEvents.length === 0 ? (
              <div
                className="text-center py-10"
                data-ocid="risk.events.empty_state"
              >
                <CheckCircle
                  className="w-10 h-10 mx-auto mb-3"
                  style={{ color: "#22c55e" }}
                />
                <p className="text-sm font-mono" style={{ color: "#22c55e" }}>
                  No risk events recorded
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  All risk parameters within safe thresholds
                </p>
              </div>
            ) : (
              <div className="space-y-1.5" data-ocid="risk.events.list">
                {riskEvents.map((event, idx) => {
                  const isCritical = event.severity === RiskSeverity.Critical;
                  const isWarning = event.severity === RiskSeverity.Warning;
                  const dotColor = isCritical
                    ? "#ef4444"
                    : isWarning
                      ? "#eab308"
                      : "#06b6d4";
                  const ts = new Date(
                    Number(event.timestamp) / 1_000_000,
                  ).toLocaleTimeString();
                  return (
                    <div
                      key={event.id}
                      className="flex items-start gap-3 p-3 rounded-lg transition-all"
                      style={{
                        background: isCritical
                          ? "rgba(239,68,68,0.06)"
                          : "rgba(255,255,255,0.02)",
                        border: `1px solid ${isCritical ? "rgba(239,68,68,0.2)" : "rgba(255,255,255,0.05)"}`,
                      }}
                      data-ocid={`risk.events.item.${idx + 1}`}
                    >
                      <div
                        className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0"
                        style={{
                          background: dotColor,
                          boxShadow: isCritical
                            ? `0 0 8px ${dotColor}`
                            : "none",
                          animation: isCritical
                            ? "pulse 1.5s ease-in-out infinite"
                            : "none",
                        }}
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span
                            className="text-xs font-mono font-bold"
                            style={{ color: dotColor }}
                          >
                            {String(event.eventType)}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {ts}
                          </span>
                          {isCritical && (
                            <Badge
                              variant="outline"
                              className="text-xs"
                              style={{
                                borderColor: "rgba(239,68,68,0.4)",
                                color: "#ef4444",
                              }}
                            >
                              CRITICAL
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-foreground mt-0.5 break-words">
                          {event.message}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* ── DISCLAIMER ───────────────────────────────────────────────── */}
        <div
          className="p-4 rounded-xl text-xs text-muted-foreground leading-relaxed"
          style={{
            background: "rgba(255,255,255,0.02)",
            border: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <span className="font-bold text-foreground">⚠ Risk Disclaimer: </span>
          Cryptocurrency trading involves substantial risk and may result in
          loss of capital. This software does not guarantee profits.
          AI-generated trades are probabilistic and should be used responsibly.
          Always begin with paper trading before enabling live automation. Past
          performance is not indicative of future results.
        </div>
      </div>

      {/* ── EMERGENCY STOP DIALOG ─────────────────────────────────────── */}
      <Dialog open={showEmergencyDialog} onOpenChange={setShowEmergencyDialog}>
        <DialogContent
          className="border-0"
          style={{
            background: "rgba(10,12,25,0.97)",
            backdropFilter: "blur(32px)",
            border: "1px solid rgba(239,68,68,0.5)",
            boxShadow: "0 0 40px rgba(239,68,68,0.2)",
          }}
          data-ocid="risk.emergency_stop_dialog"
        >
          <DialogHeader>
            <DialogTitle
              className="flex items-center gap-2 font-mono text-lg"
              style={{ color: "#fca5a5" }}
            >
              <StopCircle className="w-5 h-5" style={{ color: "#ef4444" }} />
              Confirm Emergency Stop
            </DialogTitle>
            <DialogDescription className="text-muted-foreground">
              This will immediately halt all active trading activity, close
              pending order queues, and lock the AI engine until manually
              resumed. Are you sure?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 mt-4">
            <Button
              variant="outline"
              onClick={() => setShowEmergencyDialog(false)}
              className="border-border/40"
              data-ocid="risk.emergency_stop.cancel_button"
            >
              Cancel
            </Button>
            <button
              type="button"
              onClick={handleEmergencyStop}
              data-ocid="risk.emergency_stop.confirm_button"
              className="flex items-center gap-2 px-4 py-2 rounded-lg font-mono font-bold text-sm"
              style={{
                background: "rgba(239,68,68,0.25)",
                border: "1px solid rgba(239,68,68,0.6)",
                color: "#fca5a5",
                boxShadow: "0 0 16px rgba(239,68,68,0.3)",
              }}
            >
              <StopCircle className="w-4 h-4" style={{ color: "#ef4444" }} />
              Yes, Trigger Emergency Stop
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── RESUME DIALOG ────────────────────────────────────────────── */}
      <Dialog open={showResumeDialog} onOpenChange={setShowResumeDialog}>
        <DialogContent
          className="border-0"
          style={{
            background: "rgba(10,12,25,0.97)",
            backdropFilter: "blur(32px)",
            border: "1px solid rgba(34,197,94,0.4)",
          }}
          data-ocid="risk.resume_dialog"
        >
          <DialogHeader>
            <DialogTitle
              className="flex items-center gap-2 font-mono text-lg"
              style={{ color: "#86efac" }}
            >
              <Play className="w-5 h-5" style={{ color: "#22c55e" }} />
              Resume Trading
            </DialogTitle>
            <DialogDescription className="text-muted-foreground">
              This will re-activate the AI trading engine and allow it to
              execute trades. Ensure risk conditions are favorable before
              resuming.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 mt-4">
            <Button
              variant="outline"
              onClick={() => setShowResumeDialog(false)}
              className="border-border/40"
              data-ocid="risk.resume.cancel_button"
            >
              Cancel
            </Button>
            <button
              type="button"
              onClick={handleResume}
              data-ocid="risk.resume.confirm_button"
              className="flex items-center gap-2 px-4 py-2 rounded-lg font-mono font-bold text-sm"
              style={{
                background: "rgba(34,197,94,0.2)",
                border: "1px solid rgba(34,197,94,0.5)",
                color: "#86efac",
              }}
            >
              <Play className="w-4 h-4" style={{ color: "#22c55e" }} />
              Yes, Resume Trading
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
