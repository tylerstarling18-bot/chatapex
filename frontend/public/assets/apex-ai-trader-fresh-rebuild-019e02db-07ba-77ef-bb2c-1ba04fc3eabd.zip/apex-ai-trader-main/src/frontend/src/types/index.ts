import type { Variant_Defensive_Observation_TrendFollowing_Scalping_MeanReversion } from "../backend";
// Re-export backend types for use throughout the app
export type {
  AIDecisionLog,
  AITrainingState,
  ArenaResult,
  ArenaSession,
  AssetBalance,
  BacktestResults,
  BacktestSession,
  Candle,
  ConfidenceFactors,
  CorrelationData,
  EquityPoint,
  ExchangeStatus,
  MarketData,
  MarketSnapshot,
  NoTradeDecision,
  OrderRecord,
  Portfolio,
  Position,
  RegimeBreakdown,
  RiskEvent,
  RiskSettings,
  RiskStatus,
  StrategyPerformance,
  StrategyPerformanceByRegime,
  TechnicalIndicators,
  Trade,
  TradeDecision,
  TradeSnapshot,
} from "../backend";

export {
  BacktestStatus,
  MarketCondition,
  NoTradeReason,
  RiskEventType,
  RiskSeverity,
  TradeTag,
  UserRole,
  Variant_Buy_Hold_Sell_Skip as TradeAction,
  Variant_Defensive_Observation_TrendFollowing_Scalping_MeanReversion as StrategyMode,
  Variant_Open_Closed_TakeProfitHit_StopLossHit_Cancelled as TradeStatus,
  Variant_Skipped_Failed_Executed_Pending as ExecutionStatus,
} from "../backend";

// Extended TimeframeSignal type matching MultiframeTypes from backend
export type TimeframeSignalTrend = "Bullish" | "Bearish" | "Neutral";
export type MacdSignalDir = "Bullish" | "Bearish" | "Cross";
export type AITimeframeSignal = {
  timeframe: string;
  trend: TimeframeSignalTrend;
  strength: number;
  rsi: number;
  macdSignal: MacdSignalDir;
  emaAlignment: boolean;
};

// Augmented AIDecisionLog with real confidence factors and multi-timeframe signals.
// The backend computes and stores these; they are present at runtime even if
// bindgen has not regenerated backend.d.ts yet (pre-existing build blocker).
export type AIDecisionLogFull = import("../backend").AIDecisionLog & {
  confidenceFactors: import("../backend").ConfidenceFactors;
  multiTimeframeSignals: AITimeframeSignal[];
};

export type AIStatus = {
  mode: string;
  lastRunTime: bigint;
  nextRunTime: bigint;
  isRunning: boolean;
  cycleCount: bigint;
};

// Frontend-only types (not from backend)
export type TimeframeSignal = {
  timeframe: string;
  trend: "Bullish" | "Bearish" | "Neutral";
  strength: number;
  rsi: number;
  macdSignal: "Bullish" | "Bearish" | "Cross";
  emaAlignment: boolean;
};

export type MultiTimeframeAnalysis = {
  symbol: string;
  shortTermMomentum: number;
  mediumTermTrend: "Up" | "Down" | "Sideways";
  longTermDirection: "Up" | "Down" | "Sideways";
  alignmentScore: number;
  signals: TimeframeSignal[];
  timestamp: bigint;
};

export type ArenaAgent = {
  agentId: string;
  name: string;
  description: string;
  riskMultiplier: number;
  preferredTimeframe: string;
  strategyFocus: Variant_Defensive_Observation_TrendFollowing_Scalping_MeanReversion;
};

// Re-export bot-related types from backend for use throughout the app
export type {
  BotState,
  BotConfig,
  EquitySnapshot,
  ConfidencePoint,
  ActivityItem as LiveActivityItem,
  DataFeedStatus,
  DecisionCycleStats,
  SimulationStats,
  SimulationFidelity,
  PartialExitLevel,
} from "../backend";

export { BotStatus, TradingMode } from "../backend";
