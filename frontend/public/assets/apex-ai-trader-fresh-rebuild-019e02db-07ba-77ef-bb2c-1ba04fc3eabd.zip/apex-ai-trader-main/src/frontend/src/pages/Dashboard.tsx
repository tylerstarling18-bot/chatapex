import { BotStatus } from "@/backend";
import { Layout } from "@/components/Layout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useAIStatus,
  useBotState,
  useEmergencyStop,
  useExecutePendingDecisions,
  useLatestDecisions,
  useLiveActivityFeed,
  useMarketCondition,
  useMarketSnapshot,
  useOpenPositions,
  usePortfolio,
  useRiskEvents,
  useRiskStatus,
  useRunAIAnalysis,
  useTradeHistory,
} from "@/hooks/useQueries";
import { cn } from "@/lib/utils";
import type { RiskEvent } from "@/types";
import { MarketCondition, RiskSeverity, TradeAction } from "@/types";
import { Link } from "@tanstack/react-router";
import {
  Activity,
  AlertTriangle,
  Bot,
  Brain,
  ChevronUp,
  Cpu,
  DollarSign,
  Play,
  RefreshCw,
  ShieldAlert,
  StopCircle,
  TrendingDown,
  TrendingUp,
  Zap,
} from "lucide-react";
import { useMemo } from "react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { toast } from "sonner";

// ─── Helpers ─────────────────────────────────────────────────────────────────

// Bot Status Label Map
const BOT_STATUS_LABELS: Record<string, string> = {
  Running: "RUNNING",
  Paused: "PAUSED",
  Stopped: "STOPPED",
  EmergencyStopped: "E-STOPPED",
};

function botStatusLabel(status: string | undefined): string {
  return BOT_STATUS_LABELS[status ?? ""] ?? status?.toUpperCase() ?? "STOPPED";
}

function timeAgo(ns: bigint): string {
  const msAgo = Date.now() - Number(ns / 1_000_000n);
  if (msAgo < 60_000) return "just now";
  if (msAgo < 3_600_000) return `${Math.floor(msAgo / 60_000)}m ago`;
  if (msAgo < 86_400_000) return `${Math.floor(msAgo / 3_600_000)}h ago`;
  return `${Math.floor(msAgo / 86_400_000)}d ago`;
}

function fmtUSD(n: number, decimals = 2): string {
  return n.toLocaleString("en-US", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

function PnlDisplay({
  value,
  suffix = "",
}: { value: number; suffix?: string }) {
  const pos = value >= 0;
  return (
    <span
      className={cn(
        "font-mono font-semibold",
        pos ? "text-green-400" : "text-red-400",
      )}
    >
      {pos ? "+" : ""}
      {value.toFixed(2)}
      {suffix}
    </span>
  );
}

// ─── Market Condition Badge ───────────────────────────────────────────────────

const CONDITION_CONFIG: Record<string, { label: string; color: string }> = {
  [MarketCondition.StrongBullish]: {
    label: "Strong Bullish",
    color: "#22c55e",
  },
  [MarketCondition.Bullish]: { label: "Bullish", color: "#86efac" },
  [MarketCondition.Neutral]: { label: "Neutral", color: "#94a3b8" },
  [MarketCondition.Ranging]: { label: "Ranging", color: "#eab308" },
  [MarketCondition.WeakBearish]: { label: "Weak Bearish", color: "#f97316" },
  [MarketCondition.StrongBearish]: {
    label: "Strong Bearish",
    color: "#ef4444",
  },
  [MarketCondition.HighVolatility]: {
    label: "High Volatility",
    color: "#a855f7",
  },
  [MarketCondition.ManipulationRisk]: {
    label: "Manipulation Risk",
    color: "#f43f5e",
  },
  [MarketCondition.LowLiquidityDanger]: {
    label: "Low Liquidity",
    color: "#fb923c",
  },
};

function MarketConditionBadge({
  condition,
}: { condition: MarketCondition | null | undefined }) {
  if (!condition)
    return <span className="text-xs font-mono text-muted-foreground">—</span>;
  const cfg = CONDITION_CONFIG[condition];
  return (
    <span
      className="text-xs font-mono font-bold px-2 py-0.5 rounded"
      style={{
        color: cfg?.color ?? "#94a3b8",
        background: `${cfg?.color ?? "#94a3b8"}18`,
        border: `1px solid ${cfg?.color ?? "#94a3b8"}40`,
      }}
    >
      {cfg?.label ?? condition}
    </span>
  );
}

// ─── Risk Score Gauge ─────────────────────────────────────────────────────────

function RiskGauge({ score }: { score: number }) {
  const color = score < 30 ? "#22c55e" : score < 60 ? "#eab308" : "#ef4444";
  const label = score < 30 ? "LOW" : score < 60 ? "MED" : "HIGH";
  return (
    <div className="flex items-center gap-3">
      <div className="relative w-10 h-10">
        <svg
          viewBox="0 0 36 36"
          className="w-full h-full -rotate-90"
          aria-hidden="true"
        >
          <circle
            cx="18"
            cy="18"
            r="14"
            fill="none"
            stroke="rgba(255,255,255,0.08)"
            strokeWidth="3"
          />
          <circle
            cx="18"
            cy="18"
            r="14"
            fill="none"
            stroke={color}
            strokeWidth="3"
            strokeDasharray={`${(score / 100) * 87.96} 87.96`}
            strokeLinecap="round"
          />
        </svg>
        <span
          className="absolute inset-0 flex items-center justify-center text-[9px] font-bold font-mono"
          style={{ color }}
        >
          {Math.round(score)}
        </span>
      </div>
      <div>
        <div className="text-lg font-bold font-mono" style={{ color }}>
          {score.toFixed(0)}%
        </div>
        <div
          className="text-[10px] font-mono tracking-widest"
          style={{ color }}
        >
          {label} RISK
        </div>
      </div>
    </div>
  );
}

// ─── Stat Card ────────────────────────────────────────────────────────────────

function StatCard({
  title,
  value,
  subtitle,
  icon: Icon,
  accent,
  loading,
}: {
  title: string;
  value: React.ReactNode;
  subtitle?: React.ReactNode;
  icon: React.ElementType;
  accent?: string;
  loading?: boolean;
}) {
  return (
    <div className="glass-panel rounded-xl p-5">
      <div className="flex items-start justify-between mb-3">
        <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
          {title}
        </span>
        <Icon
          className="w-4 h-4"
          style={{ color: accent ?? "rgba(148,163,184,0.6)" }}
        />
      </div>
      {loading ? (
        <Skeleton className="h-7 w-28 mb-1" />
      ) : (
        <div className="text-2xl font-bold font-mono text-foreground leading-tight">
          {value}
        </div>
      )}
      {subtitle && (
        <div className="mt-1 text-xs text-muted-foreground">{subtitle}</div>
      )}
    </div>
  );
}

// ─── Decision Action Tag ──────────────────────────────────────────────────────

function ActionTag({ action }: { action: TradeAction }) {
  const cfg = {
    [TradeAction.Buy]: { label: "BUY", color: "#22c55e" },
    [TradeAction.Sell]: { label: "SELL", color: "#ef4444" },
    [TradeAction.Hold]: { label: "HOLD", color: "#06b6d4" },
    [TradeAction.Skip]: { label: "SKIP", color: "#64748b" },
  }[action] ?? { label: action, color: "#64748b" };
  return (
    <span
      className="text-[10px] font-bold font-mono px-1.5 py-0.5 rounded"
      style={{
        color: cfg.color,
        background: `${cfg.color}18`,
        border: `1px solid ${cfg.color}30`,
      }}
    >
      {cfg.label}
    </span>
  );
}

// ─── Risk Event Row ───────────────────────────────────────────────────────────

function RiskEventRow({ event, idx }: { event: RiskEvent; idx: number }) {
  const color =
    event.severity === RiskSeverity.Critical
      ? "#ef4444"
      : event.severity === RiskSeverity.Warning
        ? "#eab308"
        : "#06b6d4";
  return (
    <div
      className="flex items-start gap-3 py-2 border-b last:border-0"
      style={{ borderColor: "rgba(255,255,255,0.06)" }}
      data-ocid={`risk_events.item.${idx}`}
    >
      <div
        className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0"
        style={{ background: color }}
      />
      <div className="flex-1 min-w-0">
        <p className="text-xs font-mono text-foreground truncate">
          {event.message}
        </p>
        <p className="text-[10px] text-muted-foreground mt-0.5">
          {event.eventType.replace(/([A-Z])/g, " $1").trim()} ·{" "}
          {timeAgo(event.timestamp)}
        </p>
      </div>
      <span
        className="text-[10px] font-bold font-mono flex-shrink-0"
        style={{ color }}
      >
        {event.severity.toUpperCase()}
      </span>
    </div>
  );
}

// ─── Custom Recharts tooltip ──────────────────────────────────────────────────

function ChartTooltip({
  active,
  payload,
}: {
  active?: boolean;
  payload?: Array<{ value: number; payload: { label: string } }>;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div
      className="rounded-lg px-3 py-2 text-xs font-mono"
      style={{
        background: "rgba(10,15,30,0.9)",
        border: "1px solid rgba(6,182,212,0.3)",
      }}
    >
      <p className="text-muted-foreground">{payload[0].payload.label}</p>
      <p className="text-cyan-400 font-bold">${fmtUSD(payload[0].value)}</p>
    </div>
  );
}

// ─── Main Dashboard ───────────────────────────────────────────────────────────

export default function Dashboard() {
  const { data: portfolio, isLoading: portfolioLoading } = usePortfolio();
  const { data: aiStatus, isLoading: aiLoading } = useAIStatus();
  const { data: riskStatus } = useRiskStatus();
  const { data: snapshot } = useMarketSnapshot();
  const { data: condition } = useMarketCondition();
  const { data: positions } = useOpenPositions();
  const { data: decisions, isLoading: decisionsLoading } =
    useLatestDecisions(10n);
  const { data: riskEvents } = useRiskEvents(5n);
  const { data: trades } = useTradeHistory(50n);
  const { data: botState } = useBotState();
  const { data: recentActivity = [] } = useLiveActivityFeed(5n);

  const runAI = useRunAIAnalysis();
  const executePending = useExecutePendingDecisions();
  const emergencyStop = useEmergencyStop();

  // Build equity curve from trade history
  const equityCurve = useMemo(() => {
    const base = portfolio?.totalValue ?? 10000;
    if (!trades || trades.length === 0) {
      // Flat baseline
      return Array.from({ length: 8 }, (_, i) => ({
        label: `T-${7 - i}`,
        value: base,
      }));
    }
    const sorted = [...trades]
      .filter((t) => t.pnl !== undefined && t.pnl !== null)
      .sort((a, b) => Number(a.closeTime - b.closeTime));
    let running = base;
    const points = sorted.slice(-24).map((t, _i) => {
      running += t.pnl as number;
      const ts = new Date(Number(t.closeTime / 1_000_000n));
      return {
        label: `${ts.getMonth() + 1}/${ts.getDate()} ${ts.getHours()}:00`,
        value: Math.max(0, running),
      };
    });
    if (points.length < 2) {
      return [
        { label: "Start", value: base },
        { label: "Now", value: base + (portfolio?.totalPnl ?? 0) },
      ];
    }
    return points;
  }, [trades, portfolio]);

  const handleRunAI = async () => {
    try {
      await runAI.mutateAsync();
      toast.success("AI analysis complete — decisions generated");
    } catch {
      toast.error("AI analysis failed");
    }
  };

  const handleExecutePending = async () => {
    try {
      const result = await executePending.mutateAsync();
      toast.success(`Executed ${result.length} pending decisions`);
    } catch {
      toast.error("Failed to execute decisions");
    }
  };

  const handleEmergencyStop = async () => {
    try {
      await emergencyStop.mutateAsync();
      toast.error("⚠️ Emergency stop triggered — all trading halted");
    } catch {
      toast.error("Failed to trigger emergency stop");
    }
  };

  const isAIRunning = aiStatus?.isRunning ?? false;
  const riskScore = riskStatus?.riskScore ?? 0;

  return (
    <Layout>
      <div className="p-5 space-y-5" data-ocid="dashboard.page">
        {/* ── Header ── */}
        <div className="flex items-center justify-between">
          <div>
            <h1
              className="text-lg font-bold font-mono"
              style={{ color: "#06b6d4" }}
            >
              MISSION CONTROL
            </h1>
            <p className="text-xs text-muted-foreground font-mono mt-0.5">
              Apex Intelligence Core · {aiStatus?.mode ?? "Offline"} · Cycle #
              {aiStatus?.cycleCount?.toString() ?? "0"}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              className="gap-1.5 text-xs font-mono"
              style={{ borderColor: "rgba(6,182,212,0.4)", color: "#06b6d4" }}
              onClick={handleRunAI}
              disabled={runAI.isPending}
              data-ocid="dashboard.run_ai_button"
            >
              {runAI.isPending ? (
                <RefreshCw className="w-3 h-3 animate-spin" />
              ) : (
                <Brain className="w-3 h-3" />
              )}
              Run AI
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="gap-1.5 text-xs font-mono"
              style={{ borderColor: "rgba(34,197,94,0.4)", color: "#22c55e" }}
              onClick={handleExecutePending}
              disabled={executePending.isPending}
              data-ocid="dashboard.execute_pending_button"
            >
              {executePending.isPending ? (
                <RefreshCw className="w-3 h-3 animate-spin" />
              ) : (
                <Zap className="w-3 h-3" />
              )}
              Execute
            </Button>
            <Button
              size="sm"
              className="gap-1.5 text-xs font-mono bg-red-500 hover:bg-red-600 text-white border-0"
              onClick={handleEmergencyStop}
              disabled={emergencyStop.isPending}
              data-ocid="dashboard.emergency_stop_button"
            >
              <StopCircle className="w-3 h-3" />
              E-Stop
            </Button>
          </div>
        </div>

        {/* ── ROW 0: Simulator Quick-Access Card ── */}
        <div
          className="rounded-xl p-4 flex items-center gap-4"
          style={{
            background: "rgba(6,182,212,0.05)",
            border: "1px solid rgba(6,182,212,0.2)",
          }}
          data-ocid="dashboard.simulator_card"
        >
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <div
              className={cn(
                "w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",
                botState?.status === BotStatus.Running
                  ? "bg-green-500/15"
                  : "bg-cyan-500/10",
              )}
            >
              <Bot
                className="w-5 h-5"
                style={{
                  color:
                    botState?.status === BotStatus.Running
                      ? "#22c55e"
                      : "#06b6d4",
                }}
              />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold font-mono text-foreground">
                  Trading Simulator
                </span>
                <span
                  className="text-[10px] font-bold font-mono px-1.5 py-0.5 rounded"
                  style={{
                    color:
                      botState?.status === BotStatus.Running
                        ? "#22c55e"
                        : botState?.status === BotStatus.Paused
                          ? "#eab308"
                          : botState?.status === BotStatus.EmergencyStopped
                            ? "#ef4444"
                            : "#64748b",
                    background:
                      botState?.status === BotStatus.Running
                        ? "rgba(34,197,94,0.12)"
                        : "rgba(100,116,139,0.12)",
                    border: `1px solid ${
                      botState?.status === BotStatus.Running
                        ? "rgba(34,197,94,0.25)"
                        : "rgba(100,116,139,0.25)"
                    }`,
                  }}
                >
                  {botStatusLabel(botState?.status)}
                </span>
              </div>
              <div className="flex items-center gap-3 mt-0.5 text-[11px] font-mono text-muted-foreground">
                <span>
                  Equity:{" "}
                  <span className="text-cyan-400">
                    ${fmtUSD(portfolio?.totalValue ?? 0)}
                  </span>
                </span>
                <span>
                  P&L: <PnlDisplay value={portfolio?.totalPnl ?? 0} />
                </span>
                <span>
                  Trades:{" "}
                  <span className="text-foreground">
                    {(portfolio?.totalTrades ?? 0n).toString()}
                  </span>
                </span>
              </div>
            </div>
          </div>

          {/* Live Activity Preview */}
          {recentActivity.length > 0 && (
            <div className="hidden xl:flex flex-col gap-1 min-w-0 flex-1">
              {recentActivity.slice(0, 3).map((item, idx) => (
                <div
                  key={`${item.asset}-${idx}`}
                  className="flex items-center gap-2 text-[10px] font-mono"
                >
                  <span className="text-muted-foreground min-w-[48px]">
                    {(() => {
                      const ms =
                        Date.now() - Number(item.timestamp / 1_000_000n);
                      return ms < 60000
                        ? "just now"
                        : `${Math.floor(ms / 60000)}m ago`;
                    })()}
                  </span>
                  <span style={{ color: "#06b6d4" }} className="font-bold">
                    {item.asset}
                  </span>
                  <span
                    className="font-bold px-1 py-0.5 rounded text-[9px]"
                    style={{
                      color:
                        item.action === "BUY" || item.action === "ENTRY"
                          ? "#22c55e"
                          : item.action === "SELL" || item.action === "EXIT"
                            ? "#ef4444"
                            : "#64748b",
                      background:
                        item.action === "BUY" || item.action === "ENTRY"
                          ? "rgba(34,197,94,0.12)"
                          : item.action === "SELL" || item.action === "EXIT"
                            ? "rgba(239,68,68,0.12)"
                            : "rgba(100,116,139,0.12)",
                    }}
                  >
                    {item.action.toUpperCase()}
                  </span>
                  <span className="text-cyan-400">
                    {(item.confidence * 100).toFixed(0)}%
                  </span>
                  <span className="text-muted-foreground truncate max-w-[200px]">
                    {item.reasoning.slice(0, 60)}…
                  </span>
                </div>
              ))}
            </div>
          )}

          <Link
            to="/simulator"
            data-ocid="dashboard.go_to_simulator_button"
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold font-mono transition-colors flex-shrink-0"
            style={{
              background: "rgba(6,182,212,0.15)",
              border: "1px solid rgba(6,182,212,0.35)",
              color: "#06b6d4",
            }}
          >
            <Bot className="w-3.5 h-3.5" />
            Open Simulator
          </Link>
        </div>

        {/* ── ROW 1: Status cards ── */}
        <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
          {/* AI Engine Status */}
          <div
            className="glass-panel rounded-xl p-5"
            data-ocid="dashboard.ai_status_card"
          >
            <div className="flex items-start justify-between mb-3">
              <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
                AI Engine
              </span>
              <Cpu className="w-4 h-4" style={{ color: "#06b6d4" }} />
            </div>
            {aiLoading ? (
              <Skeleton className="h-6 w-20 mb-1" />
            ) : (
              <div className="flex items-center gap-2">
                <div
                  className={cn(
                    "w-2 h-2 rounded-full",
                    isAIRunning ? "animate-pulse" : "",
                  )}
                  style={{ background: isAIRunning ? "#22c55e" : "#eab308" }}
                />
                <span
                  className="text-xl font-bold font-mono"
                  style={{ color: isAIRunning ? "#22c55e" : "#eab308" }}
                >
                  {isAIRunning ? "ACTIVE" : "STANDBY"}
                </span>
              </div>
            )}
            <div className="mt-1 text-xs text-muted-foreground font-mono">
              Mode:{" "}
              <span style={{ color: "#06b6d4" }}>{aiStatus?.mode ?? "—"}</span>
            </div>
            {riskStatus?.isPaused && (
              <div className="mt-2 flex items-center gap-1 text-[10px] font-mono text-red-400">
                <AlertTriangle className="w-3 h-3" /> TRADING PAUSED
              </div>
            )}
          </div>

          {/* Market Condition */}
          <div
            className="glass-panel rounded-xl p-5"
            data-ocid="dashboard.market_condition_card"
          >
            <div className="flex items-start justify-between mb-3">
              <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
                Market State
              </span>
              <Activity className="w-4 h-4" style={{ color: "#a855f7" }} />
            </div>
            <div className="text-sm font-bold font-mono mb-1">
              <MarketConditionBadge condition={condition} />
            </div>
            <div className="mt-1 text-xs text-muted-foreground font-mono">
              BTC Dom:{" "}
              <span className="text-foreground">
                {snapshot?.btcDominance?.toFixed(1) ?? "—"}%
              </span>
              {snapshot?.fearGreedIndex !== undefined && (
                <>
                  {" "}
                  · F&G:{" "}
                  <span className="text-foreground">
                    {snapshot.fearGreedIndex}
                  </span>
                </>
              )}
            </div>
          </div>

          {/* Portfolio Value */}
          <StatCard
            title="Portfolio Value"
            value={`$${fmtUSD(portfolio?.totalValue ?? 0)}`}
            subtitle={
              portfolio ? (
                <PnlDisplay value={portfolio.dayPnlPercent} suffix="% today" />
              ) : undefined
            }
            icon={DollarSign}
            accent="#06b6d4"
            loading={portfolioLoading}
          />

          {/* Risk Score */}
          <div
            className="glass-panel rounded-xl p-5"
            data-ocid="dashboard.risk_score_card"
          >
            <div className="flex items-start justify-between mb-3">
              <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
                Risk Score
              </span>
              <ShieldAlert className="w-4 h-4 text-muted-foreground" />
            </div>
            <RiskGauge score={riskScore} />
            <div className="mt-1 text-xs text-muted-foreground font-mono">
              Daily loss:{" "}
              <span
                className={
                  riskStatus?.dailyLossPercent &&
                  riskStatus.dailyLossPercent > 3
                    ? "text-red-400"
                    : "text-foreground"
                }
              >
                {(riskStatus?.dailyLossPercent ?? 0).toFixed(2)}%
              </span>
            </div>
          </div>
        </div>

        {/* ── ROW 2: Main content ── */}
        <div className="grid grid-cols-1 xl:grid-cols-10 gap-4">
          {/* LEFT: Live Market Prices 40% */}
          <div
            className="xl:col-span-4 glass-panel rounded-xl"
            data-ocid="dashboard.market_prices_card"
          >
            <div
              className="px-5 pt-4 pb-3 flex items-center justify-between border-b"
              style={{ borderColor: "rgba(6,182,212,0.12)" }}
            >
              <div className="flex items-center gap-2">
                <Activity
                  className="w-3.5 h-3.5"
                  style={{ color: "#06b6d4" }}
                />
                <span
                  className="text-[11px] font-mono uppercase tracking-widest"
                  style={{ color: "#06b6d4" }}
                >
                  Live Markets
                </span>
              </div>
              {snapshot && (
                <span className="text-[10px] font-mono text-muted-foreground">
                  {snapshot.markets.length} tracked
                </span>
              )}
            </div>
            <div className="px-5 py-3">
              {/* Header row */}
              <div className="grid grid-cols-4 gap-2 mb-2">
                {["Symbol", "Price", "24h %", "Volume"].map((h) => (
                  <span
                    key={h}
                    className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground"
                  >
                    {h}
                  </span>
                ))}
              </div>
              {!snapshot ? (
                <div className="space-y-2">
                  {Array.from({ length: 7 }, (_, i) => `sk-mkt-${i}`).map(
                    (k) => (
                      <Skeleton key={k} className="h-7 w-full" />
                    ),
                  )}
                </div>
              ) : (
                <div className="space-y-1" data-ocid="dashboard.market_list">
                  {snapshot.markets.slice(0, 10).map((m, idx) => (
                    <div
                      key={m.symbol}
                      className="grid grid-cols-4 gap-2 py-1.5 border-b last:border-0 items-center"
                      style={{ borderColor: "rgba(255,255,255,0.05)" }}
                      data-ocid={`market.item.${idx + 1}`}
                    >
                      <span
                        className="text-xs font-mono font-bold"
                        style={{ color: "#e2e8f0" }}
                      >
                        {m.symbol}
                      </span>
                      <span className="text-xs font-mono">
                        ${fmtUSD(m.price, m.price < 1 ? 4 : 2)}
                      </span>
                      <span
                        className="text-xs font-mono font-semibold flex items-center gap-0.5"
                        style={{
                          color: m.change24h >= 0 ? "#22c55e" : "#ef4444",
                        }}
                      >
                        {m.change24h >= 0 ? (
                          <ChevronUp className="w-3 h-3" />
                        ) : (
                          <TrendingDown className="w-3 h-3" />
                        )}
                        {Math.abs(m.change24h).toFixed(2)}%
                      </span>
                      <span className="text-[10px] font-mono text-muted-foreground">
                        {m.volume24h >= 1e9
                          ? `$${(m.volume24h / 1e9).toFixed(1)}B`
                          : m.volume24h >= 1e6
                            ? `$${(m.volume24h / 1e6).toFixed(0)}M`
                            : `$${(m.volume24h / 1e3).toFixed(0)}K`}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* CENTER: AI Decision Feed 30% */}
          <div
            className="xl:col-span-3 glass-panel rounded-xl"
            data-ocid="dashboard.decisions_card"
          >
            <div
              className="px-5 pt-4 pb-3 flex items-center justify-between border-b"
              style={{ borderColor: "rgba(6,182,212,0.12)" }}
            >
              <div className="flex items-center gap-2">
                <Brain className="w-3.5 h-3.5" style={{ color: "#a855f7" }} />
                <span
                  className="text-[11px] font-mono uppercase tracking-widest"
                  style={{ color: "#a855f7" }}
                >
                  AI Decisions
                </span>
              </div>
              {decisions && (
                <Badge
                  variant="outline"
                  className="text-[10px] font-mono"
                  style={{
                    borderColor: "rgba(168,85,247,0.3)",
                    color: "#a855f7",
                  }}
                >
                  {decisions.length} recent
                </Badge>
              )}
            </div>
            <div className="px-5 py-3">
              {decisionsLoading ? (
                <div className="space-y-2">
                  {Array.from({ length: 5 }, (_, i) => `sk-dec-${i}`).map(
                    (k) => (
                      <Skeleton key={k} className="h-12 w-full" />
                    ),
                  )}
                </div>
              ) : !decisions || decisions.length === 0 ? (
                <div
                  className="flex flex-col items-center justify-center py-10"
                  data-ocid="decisions.empty_state"
                >
                  <Brain
                    className="w-10 h-10 mb-3"
                    style={{ color: "rgba(168,85,247,0.3)" }}
                  />
                  <p className="text-sm text-muted-foreground font-mono text-center">
                    No decisions yet
                  </p>
                  <p className="text-xs text-muted-foreground font-mono text-center mt-1">
                    Click Run AI to start analysis
                  </p>
                </div>
              ) : (
                <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                  {decisions.map((log, idx) => (
                    <div
                      key={log.decision.id}
                      className="p-3 rounded-lg flex gap-3 items-start"
                      style={{
                        background: "rgba(255,255,255,0.03)",
                        border: "1px solid rgba(255,255,255,0.06)",
                      }}
                      data-ocid={`decisions.item.${idx + 1}`}
                    >
                      <div className="flex-shrink-0 mt-0.5">
                        <ActionTag action={log.decision.action} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-0.5">
                          <span className="text-xs font-mono font-bold text-foreground">
                            {log.decision.symbol}
                          </span>
                          <span className="text-[10px] font-mono text-muted-foreground ml-auto">
                            {(log.decision.confidence * 100).toFixed(0)}% conf
                          </span>
                        </div>
                        <p className="text-[10px] text-muted-foreground leading-relaxed line-clamp-2">
                          {log.decision.reasoning}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* RIGHT: Open Positions 30% */}
          <div
            className="xl:col-span-3 glass-panel rounded-xl"
            data-ocid="dashboard.positions_card"
          >
            <div
              className="px-5 pt-4 pb-3 flex items-center justify-between border-b"
              style={{ borderColor: "rgba(6,182,212,0.12)" }}
            >
              <div className="flex items-center gap-2">
                <TrendingUp
                  className="w-3.5 h-3.5"
                  style={{ color: "#22c55e" }}
                />
                <span
                  className="text-[11px] font-mono uppercase tracking-widest"
                  style={{ color: "#22c55e" }}
                >
                  Positions
                </span>
              </div>
              {positions && positions.length > 0 && (
                <Badge
                  variant="outline"
                  className="text-[10px] font-mono"
                  style={{
                    borderColor: "rgba(34,197,94,0.3)",
                    color: "#22c55e",
                  }}
                >
                  {positions.length} open
                </Badge>
              )}
            </div>
            <div className="px-5 py-3">
              {!positions || positions.length === 0 ? (
                <div
                  className="flex flex-col items-center justify-center py-10"
                  data-ocid="positions.empty_state"
                >
                  <Play
                    className="w-8 h-8 mb-3"
                    style={{ color: "rgba(34,197,94,0.25)" }}
                  />
                  <p className="text-sm text-muted-foreground font-mono">
                    No open positions
                  </p>
                  <p className="text-xs text-muted-foreground font-mono mt-1">
                    Paper trading mode active
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {positions.map((pos, idx) => (
                    <div
                      key={pos.symbol}
                      className="p-3 rounded-lg"
                      style={{
                        background: "rgba(255,255,255,0.03)",
                        border: "1px solid rgba(255,255,255,0.06)",
                      }}
                      data-ocid={`positions.item.${idx + 1}`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-mono font-bold">
                          {pos.symbol}
                        </span>
                        <PnlDisplay
                          value={pos.unrealizedPnlPercent}
                          suffix="%"
                        />
                      </div>
                      <div className="flex items-center justify-between mt-1">
                        <span className="text-[10px] font-mono text-muted-foreground">
                          {pos.quantity.toFixed(4)} @ $
                          {fmtUSD(pos.averageEntryPrice)}
                        </span>
                        <span
                          className="text-xs font-mono"
                          style={{
                            color:
                              pos.unrealizedPnl >= 0 ? "#22c55e" : "#ef4444",
                          }}
                        >
                          {pos.unrealizedPnl >= 0 ? "+" : ""}$
                          {fmtUSD(pos.unrealizedPnl)}
                        </span>
                      </div>
                      <div
                        className="mt-1.5 h-1 rounded-full overflow-hidden"
                        style={{ background: "rgba(255,255,255,0.08)" }}
                      >
                        <div
                          className="h-full rounded-full transition-all"
                          style={{
                            width: `${Math.min(100, Math.abs(pos.unrealizedPnlPercent) * 10)}%`,
                            background:
                              pos.unrealizedPnl >= 0 ? "#22c55e" : "#ef4444",
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* ── ROW 3: Chart + Risk Events ── */}
        <div className="grid grid-cols-1 xl:grid-cols-5 gap-4">
          {/* Portfolio Equity Chart 60% */}
          <div
            className="xl:col-span-3 glass-panel rounded-xl"
            data-ocid="dashboard.equity_chart_card"
          >
            <div
              className="px-5 pt-4 pb-3 flex items-center justify-between border-b"
              style={{ borderColor: "rgba(6,182,212,0.12)" }}
            >
              <div>
                <div className="flex items-center gap-2">
                  <TrendingUp
                    className="w-3.5 h-3.5"
                    style={{ color: "#06b6d4" }}
                  />
                  <span
                    className="text-[11px] font-mono uppercase tracking-widest"
                    style={{ color: "#06b6d4" }}
                  >
                    Portfolio Performance
                  </span>
                </div>
                {portfolio && (
                  <p className="text-[10px] font-mono text-muted-foreground mt-0.5">
                    24h P&L: <PnlDisplay value={portfolio.dayPnl} /> ($
                    {fmtUSD(portfolio.dayPnl)})
                  </p>
                )}
              </div>
              <div className="text-right">
                <div
                  className="text-lg font-bold font-mono"
                  style={{ color: "#06b6d4" }}
                >
                  ${fmtUSD(portfolio?.totalValue ?? 0)}
                </div>
                <div className="text-[10px] font-mono text-muted-foreground">
                  <PnlDisplay
                    value={portfolio?.totalPnlPercent ?? 0}
                    suffix="% all-time"
                  />
                </div>
              </div>
            </div>
            <div className="px-5 py-4">
              <ResponsiveContainer width="100%" height={200}>
                <LineChart
                  data={equityCurve}
                  margin={{ top: 4, right: 4, left: 0, bottom: 0 }}
                >
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="rgba(255,255,255,0.04)"
                  />
                  <XAxis
                    dataKey="label"
                    tick={{
                      fontSize: 9,
                      fontFamily: "monospace",
                      fill: "rgba(148,163,184,0.5)",
                    }}
                    axisLine={false}
                    tickLine={false}
                    interval="preserveStartEnd"
                  />
                  <YAxis
                    tick={{
                      fontSize: 9,
                      fontFamily: "monospace",
                      fill: "rgba(148,163,184,0.5)",
                    }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(v: number) => `$${(v / 1000).toFixed(0)}k`}
                    width={44}
                  />
                  <Tooltip content={<ChartTooltip />} />
                  <Line
                    type="monotone"
                    dataKey="value"
                    stroke="#06b6d4"
                    strokeWidth={2}
                    dot={false}
                    activeDot={{ r: 4, fill: "#06b6d4", strokeWidth: 0 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Risk Events 40% */}
          <div
            className="xl:col-span-2 glass-panel rounded-xl flex flex-col"
            data-ocid="dashboard.risk_events_card"
          >
            <div
              className="px-5 pt-4 pb-3 flex items-center justify-between border-b"
              style={{ borderColor: "rgba(239,68,68,0.2)" }}
            >
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
                <span className="text-[11px] font-mono uppercase tracking-widest text-red-400">
                  Risk Events
                </span>
              </div>
              <Button
                size="sm"
                className="h-7 px-3 text-[10px] font-bold font-mono gap-1 bg-red-500 hover:bg-red-600 text-white border-0"
                onClick={handleEmergencyStop}
                disabled={emergencyStop.isPending}
                data-ocid="dashboard.risk_emergency_stop_button"
              >
                <StopCircle className="w-3 h-3" />
                EMERGENCY STOP
              </Button>
            </div>
            <div className="px-5 py-3 flex-1">
              {/* Risk summary */}
              <div className="grid grid-cols-2 gap-2 mb-4">
                <div
                  className="rounded-lg p-2.5"
                  style={{
                    background: "rgba(255,255,255,0.03)",
                    border: "1px solid rgba(255,255,255,0.06)",
                  }}
                >
                  <p className="text-[10px] font-mono text-muted-foreground">
                    Consecutive Losses
                  </p>
                  <p
                    className="text-lg font-bold font-mono"
                    style={{
                      color:
                        (riskStatus?.consecutiveLosses ?? 0n) > 2n
                          ? "#ef4444"
                          : "#e2e8f0",
                    }}
                  >
                    {riskStatus?.consecutiveLosses?.toString() ?? "0"}
                  </p>
                </div>
                <div
                  className="rounded-lg p-2.5"
                  style={{
                    background: "rgba(255,255,255,0.03)",
                    border: "1px solid rgba(255,255,255,0.06)",
                  }}
                >
                  <p className="text-[10px] font-mono text-muted-foreground">
                    Daily Loss
                  </p>
                  <p
                    className="text-lg font-bold font-mono"
                    style={{
                      color:
                        (riskStatus?.dailyLossPercent ?? 0) > 3
                          ? "#ef4444"
                          : (riskStatus?.dailyLossPercent ?? 0) > 1
                            ? "#eab308"
                            : "#e2e8f0",
                    }}
                  >
                    {(riskStatus?.dailyLossPercent ?? 0).toFixed(2)}%
                  </p>
                </div>
              </div>

              {/* Events list */}
              {!riskEvents || riskEvents.length === 0 ? (
                <div
                  className="flex flex-col items-center justify-center py-6"
                  data-ocid="risk_events.empty_state"
                >
                  <ShieldAlert
                    className="w-8 h-8 mb-2"
                    style={{ color: "rgba(34,197,94,0.3)" }}
                  />
                  <p className="text-xs font-mono text-muted-foreground">
                    No risk events — system healthy
                  </p>
                </div>
              ) : (
                <div>
                  {riskEvents.map((evt, idx) => (
                    <RiskEventRow key={evt.id} event={evt} idx={idx + 1} />
                  ))}
                </div>
              )}
            </div>

            {/* Disclaimer */}
            <div
              className="px-5 py-3 border-t"
              style={{ borderColor: "rgba(255,255,255,0.06)" }}
            >
              <p className="text-[9px] font-mono text-muted-foreground leading-relaxed">
                ⚠️ Cryptocurrency trading involves substantial risk. AI-generated
                trades are probabilistic. Always begin with paper trading.
              </p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
