import { BotStatus } from "@/backend";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAIStatus, useBotState, useRiskStatus } from "@/hooks/useQueries";
import { cn } from "@/lib/utils";
import { useInternetIdentity } from "@caffeineai/core-infrastructure";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  Activity,
  BarChart3,
  BookOpen,
  Bot,
  Brain,
  CandlestickChart,
  ChevronRight,
  Cpu,
  FlaskConical,
  LayoutDashboard,
  LogIn,
  LogOut,
  Menu,
  Plug,
  Shield,
  Trophy,
  X,
  Zap,
} from "lucide-react";
import { useState } from "react";
// ─── Bot Status Label Map ────────────────────────────────────────────────────

const BOT_STATUS_LABELS: Record<string, string> = {
  Running: "RUNNING",
  Paused: "PAUSED",
  Stopped: "STOPPED",
  EmergencyStopped: "E-STOPPED",
};

function botStatusLabel(status: string | undefined): string {
  return BOT_STATUS_LABELS[status ?? ""] ?? status?.toUpperCase() ?? "STOPPED";
}

const NAV_ITEMS = [
  { label: "Simulator", path: "/simulator", icon: Bot, group: "core" },
  { label: "Dashboard", path: "/", icon: LayoutDashboard, group: "core" },
  { label: "AI Intelligence", path: "/ai", icon: Brain, group: "core" },
  { label: "Trading", path: "/trading", icon: Activity, group: "core" },
  { label: "Portfolio", path: "/portfolio", icon: BarChart3, group: "core" },
  { label: "Risk Engine", path: "/risk", icon: Shield, group: "core" },
  { label: "Backtesting", path: "/backtest", icon: BookOpen, group: "core" },
  {
    label: "AI Training",
    path: "/training",
    icon: FlaskConical,
    group: "core",
  },
  { label: "Chart", path: "/chart", icon: CandlestickChart, group: "advanced" },
  { label: "Competition", path: "/arena", icon: Trophy, group: "advanced" },
  { label: "Exchanges", path: "/exchange", icon: Plug, group: "advanced" },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { isAuthenticated, login, clear: logout } = useInternetIdentity();
  const { data: aiStatus } = useAIStatus();
  const { data: riskStatus } = useRiskStatus();
  const { data: botState } = useBotState();
  const routerState = useRouterState();
  const currentPath = routerState.location.pathname;

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 flex flex-col border-r border-border transition-smooth",
          "bg-card",
          sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
        )}
      >
        {/* Logo */}
        <div className="h-16 flex items-center gap-3 px-5 border-b border-border">
          <div className="w-8 h-8 rounded-lg bg-cyan-500 flex items-center justify-center shadow-glow">
            <Cpu className="w-4 h-4 text-background" />
          </div>
          <div className="min-w-0">
            <div className="text-sm font-bold text-foreground font-mono tracking-wide truncate">
              APEX AI
            </div>
            <div className="text-xs text-muted-foreground truncate">
              Intelligence Core
            </div>
          </div>
          <button
            type="button"
            className="ml-auto lg:hidden text-muted-foreground hover:text-foreground"
            onClick={() => setSidebarOpen(false)}
            aria-label="Close menu"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* AI Status Indicator */}
        <div className="px-4 py-3 border-b border-border">
          <div className="glass-panel rounded-lg p-3">
            <div className="flex items-center gap-2 mb-1">
              <div
                className={cn(
                  "w-2 h-2 rounded-full",
                  aiStatus?.isRunning
                    ? "bg-green-400 animate-pulse"
                    : "bg-yellow-500",
                )}
              />
              <span className="text-xs font-mono text-muted-foreground uppercase tracking-wider">
                Apex Intelligence
              </span>
            </div>
            <div className="text-xs font-mono">
              <span className="text-muted-foreground">Mode: </span>
              <span className="text-cyan-400">
                {aiStatus?.mode ?? "Offline"}
              </span>
            </div>
            {riskStatus?.isPaused && (
              <Badge variant="destructive" className="mt-1 text-xs">
                TRADING PAUSED
              </Badge>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-4 px-3 overflow-y-auto">
          <div className="space-y-1">
            {NAV_ITEMS.filter((i) => i.group === "core").map((item) => {
              const Icon = item.icon;
              const active =
                currentPath === item.path ||
                (item.path !== "/" && currentPath.startsWith(item.path));
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  data-ocid={`nav.${item.label.toLowerCase().replace(/ /g, "_")}.link`}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-smooth group",
                    active
                      ? "bg-cyan-500/10 text-cyan-400 border border-cyan-500/20"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted/40",
                  )}
                  onClick={() => setSidebarOpen(false)}
                >
                  <Icon
                    className={cn(
                      "w-4 h-4 flex-shrink-0",
                      active ? "text-cyan-400" : "",
                    )}
                  />
                  <span className="truncate">{item.label}</span>
                  {active && (
                    <ChevronRight className="w-3 h-3 ml-auto text-cyan-400" />
                  )}
                </Link>
              );
            })}
          </div>

          {/* Advanced section */}
          <div className="mt-4">
            <div className="px-3 pb-2">
              <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground/50">
                Advanced
              </span>
            </div>
            <div className="space-y-1">
              {NAV_ITEMS.filter((i) => i.group === "advanced").map((item) => {
                const Icon = item.icon;
                const active =
                  currentPath === item.path ||
                  (item.path !== "/" && currentPath.startsWith(item.path));
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    data-ocid={`nav.${item.label.toLowerCase().replace(/ /g, "_")}.link`}
                    className={cn(
                      "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-smooth group",
                      active
                        ? "bg-cyan-500/10 text-cyan-400 border border-cyan-500/20"
                        : "text-muted-foreground hover:text-foreground hover:bg-muted/40",
                    )}
                    onClick={() => setSidebarOpen(false)}
                  >
                    <Icon
                      className={cn(
                        "w-4 h-4 flex-shrink-0",
                        active ? "text-cyan-400" : "",
                      )}
                    />
                    <span className="truncate">{item.label}</span>
                    {active && (
                      <ChevronRight className="w-3 h-3 ml-auto text-cyan-400" />
                    )}
                  </Link>
                );
              })}
            </div>
          </div>
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-border">
          {isAuthenticated ? (
            <Button
              variant="outline"
              size="sm"
              className="w-full gap-2"
              onClick={() => logout()}
              data-ocid="nav.logout_button"
            >
              <LogOut className="w-3 h-3" />
              Sign Out
            </Button>
          ) : (
            <Button
              size="sm"
              className="w-full gap-2 bg-cyan-500 hover:bg-cyan-400 text-background"
              onClick={() => login()}
              data-ocid="nav.login_button"
            >
              <LogIn className="w-3 h-3" />
              Connect Identity
            </Button>
          )}
          <p className="text-xs text-muted-foreground text-center mt-3">
            © {new Date().getFullYear()}. Built with{" "}
            <a
              href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(typeof window !== "undefined" ? window.location.hostname : "")}`}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-foreground transition-colors"
            >
              caffeine.ai
            </a>
          </p>
        </div>
      </aside>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <button
          type="button"
          className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm lg:hidden"
          onClick={() => setSidebarOpen(false)}
          aria-label="Close sidebar"
        />
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col lg:ml-64 min-w-0">
        {/* Top bar */}
        <header className="h-16 flex items-center gap-4 px-6 border-b border-border bg-card sticky top-0 z-30">
          <button
            type="button"
            className="lg:hidden text-muted-foreground hover:text-foreground"
            onClick={() => setSidebarOpen(true)}
            aria-label="Open menu"
            data-ocid="nav.menu_button"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-cyan-400" />
            <span className="text-sm font-mono text-muted-foreground">
              APEX AI TRADER{" "}
              <span className="text-xs text-muted-foreground/60">v1.0</span>
            </span>
          </div>
          <div className="ml-auto flex items-center gap-3">
            {/* Bot Status Indicator */}
            <Link
              to="/simulator"
              className="flex items-center gap-1.5 px-2 py-1 rounded-lg hover:bg-muted/40 transition-colors"
              data-ocid="nav.bot_status_indicator"
            >
              <div
                className={cn(
                  "w-2 h-2 rounded-full flex-shrink-0",
                  botState?.status === BotStatus.Running ? "animate-pulse" : "",
                )}
                style={{
                  background:
                    botState?.status === BotStatus.Running
                      ? "#22c55e"
                      : botState?.status === BotStatus.Paused
                        ? "#eab308"
                        : botState?.status === BotStatus.EmergencyStopped
                          ? "#ef4444"
                          : "#64748b",
                }}
              />
              <span className="text-[10px] font-mono text-muted-foreground">
                BOT:{" "}
                <span
                  style={{
                    color:
                      botState?.status === BotStatus.Running
                        ? "#22c55e"
                        : botState?.status === BotStatus.Paused
                          ? "#eab308"
                          : botState?.status === BotStatus.EmergencyStopped
                            ? "#ef4444"
                            : "#64748b",
                  }}
                >
                  {botStatusLabel(botState?.status)}
                </span>
              </span>
            </Link>
            <Badge
              variant="outline"
              className="text-xs font-mono border-yellow-500/40 text-yellow-400"
            >
              PAPER TRADING
            </Badge>
            {riskStatus?.isPaused ? (
              <Badge variant="destructive" className="text-xs animate-pulse">
                PAUSED
              </Badge>
            ) : (
              <Badge
                variant="outline"
                className="text-xs font-mono border-green-500/40 text-green-400"
              >
                LIVE
              </Badge>
            )}
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-auto">{children}</main>
      </div>
    </div>
  );
}
