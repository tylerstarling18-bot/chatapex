import { Layout } from "@/components/Layout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useAIStatus,
  useLatestDecisions,
  useMarketCondition,
  useMarketMemory,
  useMarketSnapshot,
  useNoTradeLog,
  useRunAIAnalysis,
  useStrategyPerformances,
  useTopSetups,
} from "@/hooks/useQueries";
import { cn } from "@/lib/utils";
import { MarketCondition, NoTradeReason, TradeAction } from "@/types";
import type {
  AIDecisionLogFull,
  AITimeframeSignal,
  ConfidenceFactors,
  StrategyPerformanceByRegime,
} from "@/types";
import {
  Activity,
  Brain,
  ChevronDown,
  ChevronUp,
  Play,
  RefreshCw,
  TrendingDown,
  TrendingUp,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const CONDITION_LABELS: Record<string, { label: string; color: string }> = {
  [MarketCondition.StrongBullish]: {
    label: "Strong Bullish",
    color: "text-green-400",
  },
  [MarketCondition.Bullish]: { label: "Bullish", color: "text-green-400" },
  [MarketCondition.Neutral]: {
    label: "Neutral",
    color: "text-muted-foreground",
  },
  [MarketCondition.Ranging]: { label: "Ranging", color: "text-yellow-400" },
  [MarketCondition.WeakBearish]: {
    label: "Weak Bearish",
    color: "text-orange-400",
  },
  [MarketCondition.StrongBearish]: {
    label: "Strong Bearish",
    color: "text-red-400",
  },
  [MarketCondition.HighVolatility]: {
    label: "High Volatility",
    color: "text-purple-400",
  },
  [MarketCondition.ManipulationRisk]: {
    label: "Manipulation Risk",
    color: "text-red-400",
  },
  [MarketCondition.LowLiquidityDanger]: {
    label: "Low Liquidity",
    color: "text-orange-400",
  },
};

const NO_TRADE_REASON_COLORS: Record<string, string> = {
  [NoTradeReason.VolatilityTooHigh]:
    "border-red-500/40 text-red-400 bg-red-500/10",
  [NoTradeReason.LowConfidence]:
    "border-yellow-500/40 text-yellow-400 bg-yellow-500/10",
  [NoTradeReason.OvertradingFlag]:
    "border-orange-500/40 text-orange-400 bg-orange-500/10",
  [NoTradeReason.RegimeMismatch]:
    "border-purple-500/40 text-purple-400 bg-purple-500/10",
  [NoTradeReason.CorrelationLimit]:
    "border-blue-500/40 text-blue-400 bg-blue-500/10",
  [NoTradeReason.LiquidityTooLow]:
    "border-orange-500/40 text-orange-400 bg-orange-500/10",
  [NoTradeReason.DrawdownProtection]:
    "border-red-500/40 text-red-400 bg-red-500/10",
  [NoTradeReason.ExistingPosition]:
    "border-muted-foreground/40 text-muted-foreground bg-muted/10",
};

const REGIMES = [
  MarketCondition.StrongBullish,
  MarketCondition.Bullish,
  MarketCondition.Neutral,
  MarketCondition.Ranging,
  MarketCondition.WeakBearish,
  MarketCondition.StrongBearish,
  MarketCondition.HighVolatility,
  MarketCondition.ManipulationRisk,
  MarketCondition.LowLiquidityDanger,
] as const;

const STRATEGY_MODES = [
  "TrendFollowing",
  "MeanReversion",
  "Scalping",
  "Defensive",
  "Observation",
] as const;

const REGIME_SHORT: Record<string, string> = {
  [MarketCondition.StrongBullish]: "StrongBull",
  [MarketCondition.Bullish]: "Bullish",
  [MarketCondition.Neutral]: "Neutral",
  [MarketCondition.Ranging]: "Ranging",
  [MarketCondition.WeakBearish]: "WkBearish",
  [MarketCondition.StrongBearish]: "StrgBear",
  [MarketCondition.HighVolatility]: "HighVol",
  [MarketCondition.ManipulationRisk]: "Manip",
  [MarketCondition.LowLiquidityDanger]: "LowLiq",
};

const TIMEFRAMES = ["1m", "5m", "15m", "1h", "4h", "1d"] as const;

function heatmapColor(winRate: number | undefined): string {
  if (winRate === undefined) return "rgba(255,255,255,0.03)";
  if (winRate >= 0.65) return "rgba(0,240,255,0.35)";
  if (winRate >= 0.55) return "rgba(0,240,255,0.20)";
  if (winRate >= 0.45) return "rgba(0,240,255,0.09)";
  if (winRate >= 0.35) return "rgba(239,68,68,0.10)";
  return "rgba(239,68,68,0.22)";
}

function heatmapTextColor(winRate: number | undefined): string {
  if (winRate === undefined) return "rgba(255,255,255,0.2)";
  if (winRate >= 0.55) return "#00f0ff";
  if (winRate >= 0.45) return "rgba(255,255,255,0.7)";
  return "#f87171";
}

function buildHeatmapLookup(memory: StrategyPerformanceByRegime[]) {
  const map = new Map<string, number>();
  for (const entry of memory) {
    const total = Number(entry.winCount) + Number(entry.lossCount);
    if (total === 0) continue;
    const wr = Number(entry.winCount) / total;
    map.set(`${entry.strategyMode}:${entry.marketCondition}`, wr);
  }
  return map;
}

function ConfidenceBar({
  label,
  value,
  accent = false,
}: {
  label: string;
  value: number;
  accent?: boolean;
}) {
  const pct = Math.min(Math.max(value * 100, 0), 100);
  return (
    <div>
      <div className="flex justify-between text-xs mb-1">
        <span className="text-muted-foreground">{label}</span>
        <span
          className={
            accent ? "text-cyan-400 font-mono" : "text-foreground font-mono"
          }
        >
          {pct.toFixed(0)}%
        </span>
      </div>
      <div
        className="h-1.5 rounded-full overflow-hidden"
        style={{ background: "rgba(255,255,255,0.07)" }}
      >
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{
            width: `${pct}%`,
            background: accent
              ? "#00f0ff"
              : pct >= 60
                ? "#4ade80"
                : pct >= 40
                  ? "#facc15"
                  : "#f87171",
            boxShadow: accent ? "0 0 6px rgba(0,240,255,0.5)" : undefined,
          }}
        />
      </div>
    </div>
  );
}

function ConfidenceBreakdown({ factors }: { factors: ConfidenceFactors }) {
  return (
    <div className="space-y-2.5">
      <ConfidenceBar label="Trend Alignment" value={factors.trendAlignment} />
      <ConfidenceBar label="Momentum" value={factors.momentum} />
      <ConfidenceBar
        label="Volatility Quality"
        value={factors.volatilityQuality}
      />
      <ConfidenceBar label="Liquidity" value={factors.liquidity} />
      <ConfidenceBar
        label="Historical Performance"
        value={factors.historicalSetupPerformance}
      />
      <ConfidenceBar label="Market Structure" value={factors.marketStructure} />
      <ConfidenceBar
        label="Regime Confidence"
        value={factors.regimeConfidence}
      />
      <div className="pt-2 border-t border-border/20">
        <ConfidenceBar label="Total Score" value={factors.total} accent />
      </div>
    </div>
  );
}

function MultiTimeframeIndicator({
  signals,
  symbol: _symbol,
}: { signals: AITimeframeSignal[]; symbol: string }) {
  const trendColors = {
    Bullish: {
      bg: "rgba(74,222,128,0.15)",
      border: "rgba(74,222,128,0.4)",
      text: "#4ade80",
    },
    Bearish: {
      bg: "rgba(239,68,68,0.15)",
      border: "rgba(239,68,68,0.4)",
      text: "#f87171",
    },
    Neutral: {
      bg: "rgba(250,204,21,0.10)",
      border: "rgba(250,204,21,0.35)",
      text: "#facc15",
    },
  };

  // If no real signals yet, show loading placeholders
  const displaySignals =
    signals.length > 0
      ? signals
      : TIMEFRAMES.map((tf) => ({
          tf,
          trend: "Neutral" as const,
          strength: 0,
          rsi: 50,
          macdSignal: "Cross" as const,
          emaAlignment: false,
          timeframe: tf,
        }));

  const bullCount = displaySignals.filter((t) => t.trend === "Bullish").length;
  const alignment =
    bullCount >= 4
      ? "Aligned Bullish"
      : bullCount <= 2
        ? "Aligned Bearish"
        : "Mixed";

  return (
    <div>
      <div className="flex items-center gap-2 flex-wrap">
        {displaySignals.map(({ timeframe, trend }) => {
          const c =
            trendColors[trend as keyof typeof trendColors] ??
            trendColors.Neutral;
          return (
            <div
              key={timeframe}
              className="px-3 py-1.5 rounded-md text-xs font-mono font-semibold flex flex-col items-center gap-0.5"
              style={{
                background: c.bg,
                border: `1px solid ${c.border}`,
                color: c.text,
              }}
            >
              <span>{timeframe}</span>
              <span className="text-[10px] opacity-80">{trend.charAt(0)}</span>
            </div>
          );
        })}
        <div className="ml-auto text-xs font-mono text-muted-foreground">
          Alignment:{" "}
          <span
            className={cn(
              "font-semibold",
              alignment === "Aligned Bullish"
                ? "text-green-400"
                : alignment === "Aligned Bearish"
                  ? "text-red-400"
                  : "text-yellow-400",
            )}
          >
            {alignment}
          </span>
        </div>
      </div>
    </div>
  );
}

function BehavioralHeatmap({
  memory,
}: { memory: StrategyPerformanceByRegime[] }) {
  const lookup = buildHeatmapLookup(memory);
  return (
    <div className="overflow-x-auto">
      <table
        className="w-full text-xs font-mono border-separate"
        style={{ borderSpacing: "2px" }}
      >
        <thead>
          <tr>
            <th className="text-left text-muted-foreground font-normal pr-3 pb-2 w-24">
              Regime
            </th>
            {STRATEGY_MODES.map((s) => (
              <th
                key={s}
                className="text-center text-muted-foreground font-normal pb-2 min-w-[80px]"
              >
                {s === "TrendFollowing"
                  ? "Trend"
                  : s === "MeanReversion"
                    ? "MeanRev"
                    : s}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {REGIMES.map((regime) => (
            <tr key={regime}>
              <td className="pr-3 py-0.5 text-muted-foreground text-[10px] whitespace-nowrap">
                {REGIME_SHORT[regime]}
              </td>
              {STRATEGY_MODES.map((strat) => {
                const wr = lookup.get(`${strat}:${regime}`);
                return (
                  <td key={strat} className="py-0.5">
                    <div
                      className="rounded flex items-center justify-center h-7 transition-all"
                      style={{ background: heatmapColor(wr) }}
                    >
                      <span
                        style={{
                          color: heatmapTextColor(wr),
                          fontSize: "10px",
                        }}
                      >
                        {wr !== undefined ? `${(wr * 100).toFixed(0)}%` : "—"}
                      </span>
                    </div>
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
      <div className="flex items-center gap-4 mt-3 text-[10px] font-mono text-muted-foreground">
        <div className="flex items-center gap-1.5">
          <div
            className="w-3 h-3 rounded"
            style={{ background: "rgba(0,240,255,0.35)" }}
          />
          <span>≥ 65% WR</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div
            className="w-3 h-3 rounded"
            style={{ background: "rgba(0,240,255,0.20)" }}
          />
          <span>≥ 55% WR</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div
            className="w-3 h-3 rounded"
            style={{ background: "rgba(239,68,68,0.22)" }}
          />
          <span>&lt; 35% WR</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div
            className="w-3 h-3 rounded"
            style={{ background: "rgba(255,255,255,0.03)" }}
          />
          <span>No data</span>
        </div>
      </div>
    </div>
  );
}

export default function AIIntelligence() {
  const { data: aiStatus } = useAIStatus();
  const { data: condition } = useMarketCondition();
  const { data: snapshot } = useMarketSnapshot();
  const { data: decisions, isLoading: decisionsLoading } = useLatestDecisions(
    20n,
  ) as { data: AIDecisionLogFull[] | undefined; isLoading: boolean };
  const { data: strategies } = useStrategyPerformances();
  const { data: noTradeLog } = useNoTradeLog();
  const { data: marketMemory } = useMarketMemory();
  const { data: topSetups } = useTopSetups();
  const runAI = useRunAIAnalysis();
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [showConfidence, setShowConfidence] = useState(false);

  const handleRunAI = async () => {
    try {
      await runAI.mutateAsync();
      toast.success("AI analysis completed");
    } catch {
      toast.error("Analysis failed");
    }
  };

  const conditionInfo = condition
    ? (CONDITION_LABELS[condition] ?? {
        label: condition,
        color: "text-muted-foreground",
      })
    : null;

  // Find the most recent trade decision with confidence factors (from top setups / decisions)
  const latestDecision = decisions?.[0];
  const latestSymbol = latestDecision?.decision.symbol ?? "BTC";

  // Use real confidence factors from the latest AIDecisionLog (computed by the AI engine).
  // Falls back to a safe zero-fill if the decision hasn't loaded yet.
  const latestConf = latestDecision?.decision.confidence ?? 0;
  const confidenceFactors: ConfidenceFactors | null =
    latestDecision?.confidenceFactors ?? null;
  const latestMTFSignals: AITimeframeSignal[] =
    latestDecision?.multiTimeframeSignals ?? [];

  // Build top/worst setups from topSetups data
  const sortedSetups = [...(topSetups ?? [])]
    .filter((s) => Number(s.winCount) + Number(s.lossCount) >= 1)
    .sort((a, b) => {
      const aTotal = Number(a.winCount) + Number(a.lossCount);
      const bTotal = Number(b.winCount) + Number(b.lossCount);
      const aWr = aTotal > 0 ? Number(a.winCount) / aTotal : 0;
      const bWr = bTotal > 0 ? Number(b.winCount) / bTotal : 0;
      return bWr - aWr;
    });
  const bestSetups = sortedSetups.slice(0, 5);
  const worstSetups = [...sortedSetups].reverse().slice(0, 5);

  return (
    <Layout>
      <div className="p-6 space-y-6" data-ocid="ai.page">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold font-mono">
              Apex Intelligence Core
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              AI market analysis engine & decision log
            </p>
          </div>
          <Button
            size="sm"
            className="gap-2 bg-cyan-500 hover:bg-cyan-400 text-background"
            onClick={handleRunAI}
            disabled={runAI.isPending}
            data-ocid="ai.run_analysis_button"
          >
            {runAI.isPending ? (
              <RefreshCw className="w-3 h-3 animate-spin" />
            ) : (
              <Play className="w-3 h-3" />
            )}
            Run Analysis
          </Button>
        </div>

        {/* Status cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card className="glass-panel border-0">
            <CardContent className="p-4">
              <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-2">
                AI Status
              </div>
              <div className="flex items-center gap-2">
                <div
                  className={cn(
                    "w-2.5 h-2.5 rounded-full",
                    aiStatus?.isRunning
                      ? "bg-green-400 animate-pulse"
                      : "bg-yellow-500",
                  )}
                />
                <span className="font-mono font-semibold">
                  {aiStatus?.isRunning ? "Active" : "Standby"}
                </span>
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Mode:{" "}
                <span className="text-cyan-400">{aiStatus?.mode ?? "—"}</span>
              </div>
            </CardContent>
          </Card>
          <Card className="glass-panel border-0">
            <CardContent className="p-4">
              <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-2">
                Market Condition
              </div>
              {conditionInfo ? (
                <div
                  className={cn("font-mono font-semibold", conditionInfo.color)}
                >
                  {conditionInfo.label}
                </div>
              ) : (
                <div className="text-muted-foreground font-mono">
                  Loading...
                </div>
              )}
            </CardContent>
          </Card>
          <Card className="glass-panel border-0">
            <CardContent className="p-4">
              <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-2">
                Markets Tracked
              </div>
              <div className="font-mono font-semibold text-foreground">
                {snapshot?.markets.length ?? 0}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                BTC Dom: {(snapshot?.btcDominance ?? 0).toFixed(1)}%
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Multi-Timeframe Alignment */}
        <Card
          className="border-0"
          style={{
            background: "rgba(0,240,255,0.03)",
            border: "1px solid rgba(0,240,255,0.1)",
          }}
        >
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" />
              Multi-Timeframe Alignment — {latestSymbol}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <MultiTimeframeIndicator
              signals={latestMTFSignals}
              symbol={latestSymbol}
            />
          </CardContent>
        </Card>

        {/* 7-Factor Confidence Breakdown */}
        {latestDecision && (
          <Card
            className="border-0"
            style={{
              background: "rgba(0,240,255,0.03)",
              border: "1px solid rgba(0,240,255,0.12)",
            }}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
                  <Brain className="w-4 h-4 text-cyan-400" />
                  7-Factor Confidence Breakdown
                  <span className="text-xs font-normal text-muted-foreground">
                    {latestDecision.decision.symbol}
                  </span>
                </CardTitle>
                <div className="flex items-center gap-3">
                  <div
                    className="text-2xl font-bold font-mono"
                    style={{
                      color:
                        latestConf >= 0.65
                          ? "#00f0ff"
                          : latestConf >= 0.5
                            ? "#facc15"
                            : "#f87171",
                    }}
                  >
                    {(latestConf * 100).toFixed(0)}%
                  </div>
                  <button
                    type="button"
                    className="text-xs text-muted-foreground hover:text-cyan-400 transition-colors font-mono"
                    onClick={() => setShowConfidence((v) => !v)}
                    data-ocid="ai.confidence.toggle"
                  >
                    {showConfidence ? "Hide" : "Show"} Details
                  </button>
                </div>
              </div>
            </CardHeader>
            {showConfidence && confidenceFactors && (
              <CardContent>
                <ConfidenceBreakdown factors={confidenceFactors} />
              </CardContent>
            )}
            {showConfidence && !confidenceFactors && (
              <CardContent>
                <p className="text-xs text-muted-foreground py-2">
                  Run AI analysis to populate factor breakdown.
                </p>
              </CardContent>
            )}
          </Card>
        )}

        {/* Strategy Performance */}
        {strategies && strategies.length > 0 && (
          <Card className="glass-panel border-0">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-mono uppercase tracking-wider">
                Strategy Performance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {strategies.map((s) => (
                  <div
                    key={s.strategyMode}
                    className="flex items-center gap-4 p-3 rounded-lg bg-muted/10 border border-border/20"
                    data-ocid={`strategies.item.${strategies.indexOf(s) + 1}`}
                  >
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-mono font-medium">
                        {s.strategyMode}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {Number(s.totalTrades)} trades
                      </div>
                    </div>
                    <div className="text-sm font-mono text-right">
                      <div
                        className={cn(
                          s.winRate >= 0.5 ? "text-green-400" : "text-red-400",
                        )}
                      >
                        {(s.winRate * 100).toFixed(1)}% WR
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {s.totalPnl >= 0 ? "+" : ""}
                        {s.totalPnl.toFixed(2)} PnL
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Behavioral Analytics Heatmap */}
        <Card
          className="border-0"
          style={{
            background: "rgba(10,14,26,0.7)",
            border: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" />
              Behavioral Analytics — Win Rate by Regime & Strategy
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!marketMemory || marketMemory.length === 0 ? (
              <div
                className="text-center py-8"
                data-ocid="ai.heatmap.empty_state"
              >
                <Activity className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">
                  No market memory yet — run AI analysis to begin learning
                </p>
              </div>
            ) : (
              <BehavioralHeatmap memory={marketMemory} />
            )}
          </CardContent>
        </Card>

        {/* Market Memory — Top & Worst Setups */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card
            className="border-0"
            style={{
              background: "rgba(74,222,128,0.03)",
              border: "1px solid rgba(74,222,128,0.12)",
            }}
          >
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-green-400" />
                Top Learnings
              </CardTitle>
            </CardHeader>
            <CardContent>
              {bestSetups.length === 0 ? (
                <p
                  className="text-sm text-muted-foreground text-center py-4"
                  data-ocid="ai.top_setups.empty_state"
                >
                  No setups learned yet
                </p>
              ) : (
                <div className="space-y-2">
                  {bestSetups.map((s, i) => {
                    const total = Number(s.winCount) + Number(s.lossCount);
                    const wr = total > 0 ? Number(s.winCount) / total : 0;
                    return (
                      <div
                        key={`${s.strategyMode}-${s.marketCondition}`}
                        className="p-3 rounded-lg text-xs font-mono"
                        style={{
                          background: "rgba(74,222,128,0.06)",
                          border: "1px solid rgba(74,222,128,0.15)",
                        }}
                        data-ocid={`ai.top_setups.item.${i + 1}`}
                      >
                        <div className="flex justify-between items-center">
                          <span className="font-semibold text-green-400">
                            {s.strategyMode} in{" "}
                            {REGIME_SHORT[s.marketCondition]}
                          </span>
                          <span className="text-green-400 font-bold">
                            {(wr * 100).toFixed(0)}% WR
                          </span>
                        </div>
                        <span className="text-muted-foreground">
                          {total} trades · avg P&L {s.avgPnl.toFixed(2)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          <Card
            className="border-0"
            style={{
              background: "rgba(239,68,68,0.03)",
              border: "1px solid rgba(239,68,68,0.12)",
            }}
          >
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
                <TrendingDown className="w-4 h-4 text-red-400" />
                Worst Setups
              </CardTitle>
            </CardHeader>
            <CardContent>
              {worstSetups.length === 0 ? (
                <p
                  className="text-sm text-muted-foreground text-center py-4"
                  data-ocid="ai.worst_setups.empty_state"
                >
                  No setups learned yet
                </p>
              ) : (
                <div className="space-y-2">
                  {worstSetups.map((s, i) => {
                    const total = Number(s.winCount) + Number(s.lossCount);
                    const wr = total > 0 ? Number(s.winCount) / total : 0;
                    return (
                      <div
                        key={`${s.strategyMode}-${s.marketCondition}-worst`}
                        className="p-3 rounded-lg text-xs font-mono"
                        style={{
                          background: "rgba(239,68,68,0.06)",
                          border: "1px solid rgba(239,68,68,0.15)",
                        }}
                        data-ocid={`ai.worst_setups.item.${i + 1}`}
                      >
                        <div className="flex justify-between items-center">
                          <span className="font-semibold text-red-400">
                            {s.strategyMode} in{" "}
                            {REGIME_SHORT[s.marketCondition]}
                          </span>
                          <span className="text-red-400 font-bold">
                            {(wr * 100).toFixed(0)}% WR
                          </span>
                        </div>
                        <span className="text-muted-foreground">
                          {total} trades · avg P&L {s.avgPnl.toFixed(2)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* No-Trade Log */}
        <Card
          className="border-0"
          style={{
            background: "rgba(10,14,26,0.6)",
            border: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
              <Activity className="w-4 h-4 text-yellow-400" />
              No-Trade Decision Log
              <span className="text-xs font-normal text-muted-foreground">
                (last 20)
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!noTradeLog || noTradeLog.length === 0 ? (
              <div
                className="text-center py-8"
                data-ocid="ai.no_trade.empty_state"
              >
                <Activity className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">
                  No skipped trades yet — the AI hasn't passed on any setups
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs font-mono">
                  <thead>
                    <tr className="border-b border-border/30">
                      {[
                        "Symbol",
                        "Reason",
                        "Confidence",
                        "Threshold",
                        "Regime",
                        "Time",
                      ].map((h) => (
                        <th
                          key={h}
                          className="pb-2 text-left text-muted-foreground font-normal pr-4"
                        >
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {noTradeLog.slice(0, 20).map((nt, idx) => (
                      <tr
                        key={`${nt.symbol}-${Number(nt.timestamp)}`}
                        className="border-b border-border/15 hover:bg-white/[0.02] transition-colors"
                        data-ocid={`ai.no_trade.item.${idx + 1}`}
                      >
                        <td className="py-2.5 pr-4 font-semibold text-foreground">
                          {nt.symbol}
                        </td>
                        <td className="py-2.5 pr-4">
                          <span
                            className={cn(
                              "px-2 py-0.5 rounded text-[10px] border",
                              NO_TRADE_REASON_COLORS[nt.reason] ??
                                "border-border/40 text-muted-foreground",
                            )}
                          >
                            {nt.reason}
                          </span>
                        </td>
                        <td className="py-2.5 pr-4 text-cyan-400">
                          {(nt.confidenceAtTime * 100).toFixed(0)}%
                        </td>
                        <td className="py-2.5 pr-4 text-muted-foreground">
                          {(nt.thresholdAtTime * 100).toFixed(0)}%
                        </td>
                        <td className="py-2.5 pr-4">
                          <span
                            className={cn(
                              "text-[10px]",
                              CONDITION_LABELS[nt.marketRegime]?.color ??
                                "text-muted-foreground",
                            )}
                          >
                            {CONDITION_LABELS[nt.marketRegime]?.label ??
                              nt.marketRegime}
                          </span>
                        </td>
                        <td className="py-2.5 text-muted-foreground">
                          {new Date(
                            Number(nt.timestamp / 1_000_000n),
                          ).toLocaleTimeString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Decision Log */}
        <Card className="glass-panel border-0">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
              <Brain className="w-4 h-4 text-cyan-400" />
              AI Decision Log
            </CardTitle>
          </CardHeader>
          <CardContent>
            {decisionsLoading ? (
              <div className="space-y-2">
                {Array.from({ length: 5 }, (_, i) => `sk-dec-${i}`).map((k) => (
                  <Skeleton key={k} className="h-14 w-full" />
                ))}
              </div>
            ) : !decisions || decisions.length === 0 ? (
              <div
                className="text-center py-10"
                data-ocid="ai.decisions.empty_state"
              >
                <Brain className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">
                  No decisions yet — trigger an AI analysis run
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {decisions.map((log, idx) => {
                  const expanded = expandedId === log.decision.id;
                  return (
                    <div
                      key={log.decision.id}
                      className="rounded-lg border border-border/30 overflow-hidden"
                      data-ocid={`ai.decisions.item.${idx + 1}`}
                    >
                      <button
                        type="button"
                        className="w-full flex items-center gap-3 p-3 text-left hover:bg-muted/10 transition-colors"
                        onClick={() =>
                          setExpandedId(expanded ? null : log.decision.id)
                        }
                      >
                        <div
                          className={cn(
                            "w-7 h-7 rounded flex items-center justify-center flex-shrink-0",
                            log.decision.action === TradeAction.Buy
                              ? "bg-green-500/10"
                              : log.decision.action === TradeAction.Sell
                                ? "bg-red-500/10"
                                : "bg-muted/20",
                          )}
                        >
                          {log.decision.action === TradeAction.Buy ? (
                            <TrendingUp className="w-3.5 h-3.5 text-green-400" />
                          ) : log.decision.action === TradeAction.Sell ? (
                            <TrendingDown className="w-3.5 h-3.5 text-red-400" />
                          ) : (
                            <Activity className="w-3.5 h-3.5 text-muted-foreground" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-medium text-sm">
                              {log.decision.symbol}
                            </span>
                            <Badge
                              variant="outline"
                              className={cn(
                                "text-xs",
                                log.decision.action === TradeAction.Buy
                                  ? "border-green-500/30 text-green-400"
                                  : log.decision.action === TradeAction.Sell
                                    ? "border-red-500/30 text-red-400"
                                    : "border-muted-foreground/30",
                              )}
                            >
                              {log.decision.action}
                            </Badge>
                            <span className="text-xs text-muted-foreground">
                              {(log.decision.confidence * 100).toFixed(0)}%
                              confidence
                            </span>
                          </div>
                          <p className="text-xs text-muted-foreground truncate mt-0.5">
                            {log.decision.reasoning}
                          </p>
                        </div>
                        {expanded ? (
                          <ChevronUp className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                        )}
                      </button>
                      {expanded && (
                        <div className="px-3 pb-3 bg-muted/5 border-t border-border/20">
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3">
                            {(
                              [
                                [
                                  "Entry Price",
                                  `$${log.decision.entryPrice.toFixed(4)}`,
                                ],
                                [
                                  "Stop Loss",
                                  `$${log.decision.stopLoss.toFixed(4)}`,
                                ],
                                [
                                  "Risk/Reward",
                                  `${log.decision.riskReward.toFixed(2)}x`,
                                ],
                                ["Strategy", log.decision.strategyMode],
                              ] as [string, string][]
                            ).map(([label, val]) => (
                              <div
                                key={label}
                                className="bg-muted/10 rounded p-2"
                              >
                                <div className="text-xs text-muted-foreground">
                                  {label}
                                </div>
                                <div className="text-sm font-mono mt-0.5">
                                  {val}
                                </div>
                              </div>
                            ))}
                          </div>
                          <div className="mt-3 grid grid-cols-3 sm:grid-cols-6 gap-2">
                            {Object.entries(log.decision.indicators).map(
                              ([key, val]) => (
                                <div key={key} className="text-center">
                                  <div className="text-xs text-muted-foreground uppercase">
                                    {key}
                                  </div>
                                  <div className="text-xs font-mono mt-0.5">
                                    {typeof val === "number"
                                      ? val.toFixed(2)
                                      : String(val)}
                                  </div>
                                </div>
                              ),
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
