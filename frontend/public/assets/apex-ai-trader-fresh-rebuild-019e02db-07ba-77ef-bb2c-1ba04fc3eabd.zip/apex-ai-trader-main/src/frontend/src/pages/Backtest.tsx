import { Layout } from "@/components/Layout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useBacktestSessions, useStartBacktest } from "@/hooks/useQueries";
import { cn } from "@/lib/utils";
import type { BacktestSession } from "@/types";
import { BacktestStatus, TradeAction } from "@/types";
import {
  Activity,
  BookOpen,
  CheckCircle,
  ChevronRight,
  Play,
  TrendingDown,
  TrendingUp,
  XCircle,
} from "lucide-react";
import { useState } from "react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { toast } from "sonner";

const SYMBOLS = ["BTC", "ETH", "BNB", "SOL", "ADA", "AVAX", "LINK", "DOT"];
const PERIODS = [
  { label: "7 days", days: 7 },
  { label: "14 days", days: 14 },
  { label: "30 days", days: 30 },
  { label: "90 days", days: 90 },
];

function formatDate(ts: bigint) {
  return new Date(Number(ts / 1_000_000n)).toLocaleDateString();
}

function StatCard({
  label,
  value,
  positive,
  neutral,
}: {
  label: string;
  value: string;
  positive?: boolean;
  neutral?: boolean;
}) {
  const color = neutral
    ? "text-foreground"
    : positive
      ? "text-green-400"
      : "text-red-400";
  return (
    <div
      className="rounded-lg p-4 border border-border"
      style={{ background: "rgba(0,240,255,0.03)" }}
    >
      <div className="text-xs font-mono uppercase text-muted-foreground mb-1">
        {label}
      </div>
      <div className={cn("text-xl font-bold font-mono", color)}>{value}</div>
    </div>
  );
}

type CustomTooltipProps = {
  active?: boolean;
  payload?: Array<{ value: number }>;
  label?: string;
};

function EquityTooltip({ active, payload, label }: CustomTooltipProps) {
  if (!active || !payload?.length) return null;
  return (
    <div
      className="rounded-lg px-3 py-2 text-xs font-mono border border-cyan-500/30"
      style={{ background: "rgba(10,14,26,0.95)" }}
    >
      <p className="text-muted-foreground mb-0.5">{label}</p>
      <p className="text-cyan-400">${payload[0].value.toLocaleString()}</p>
    </div>
  );
}

function ResultsPanel({ session }: { session: BacktestSession }) {
  const r = session.results;
  if (!r) {
    return (
      <div className="text-center py-8 text-muted-foreground text-sm font-mono">
        No results yet — session may still be running
      </div>
    );
  }

  const equityData = r.equityCurve.map((pt, i) => ({
    idx: i,
    date: new Date(Number(pt.timestamp / 1_000_000n)).toLocaleDateString(
      "en-US",
      { month: "short", day: "numeric" },
    ),
    value: Math.round(pt.value),
  }));

  return (
    <div className="space-y-4">
      {/* Summary Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <StatCard
          label="Final Balance"
          value={`$${r.finalBalance.toLocaleString(undefined, { maximumFractionDigits: 0 })}`}
          positive={r.finalBalance >= session.initialBalance}
          neutral={r.finalBalance === session.initialBalance}
        />
        <StatCard
          label="Total Return"
          value={`${r.totalReturn >= 0 ? "+" : ""}${r.totalReturn.toFixed(2)}%`}
          positive={r.totalReturn >= 0}
        />
        <StatCard
          label="Max Drawdown"
          value={`-${r.maxDrawdown.toFixed(2)}%`}
          positive={false}
        />
        <StatCard
          label="Win Rate"
          value={`${(r.winRate * 100).toFixed(1)}%`}
          positive={r.winRate >= 0.55}
        />
        <StatCard
          label="Total Trades"
          value={Number(r.totalTrades).toString()}
          neutral
        />
        <StatCard
          label="Sharpe Ratio"
          value={r.sharpeRatio !== undefined ? r.sharpeRatio.toFixed(2) : "N/A"}
          positive={(r.sharpeRatio ?? 0) >= 1}
          neutral={r.sharpeRatio === undefined}
        />
      </div>

      {/* Equity Curve */}
      {equityData.length > 1 && (
        <div
          className="rounded-xl p-4 border border-border"
          style={{ background: "rgba(0,240,255,0.03)" }}
        >
          <div className="text-xs font-mono uppercase text-muted-foreground mb-4 flex items-center gap-2">
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
            Equity Curve
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart
              data={equityData}
              margin={{ top: 4, right: 8, left: 8, bottom: 4 }}
            >
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="rgba(255,255,255,0.05)"
              />
              <XAxis
                dataKey="date"
                tick={{ fontSize: 10, fill: "rgba(255,255,255,0.35)" }}
                axisLine={false}
                tickLine={false}
                interval="preserveStartEnd"
              />
              <YAxis
                tick={{ fontSize: 10, fill: "rgba(255,255,255,0.35)" }}
                axisLine={false}
                tickLine={false}
                tickFormatter={(v: number) => `$${(v / 1000).toFixed(0)}k`}
                width={48}
              />
              <Tooltip content={<EquityTooltip />} />
              <Line
                type="monotone"
                dataKey="value"
                stroke="#00f0ff"
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4, fill: "#00f0ff" }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Trade History */}
      <div
        className="rounded-xl border border-border overflow-hidden"
        style={{ background: "rgba(0,0,0,0.2)" }}
      >
        <div className="px-4 py-3 border-b border-border/40 text-xs font-mono uppercase text-muted-foreground">
          Trade History ({Number(r.totalTrades)} trades)
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono">
            <thead>
              <tr className="border-b border-border/40">
                {["Symbol", "Action", "Entry", "Exit", "P&L", "Status"].map(
                  (h) => (
                    <th
                      key={h}
                      className="px-4 py-2 text-left text-muted-foreground font-normal"
                    >
                      {h}
                    </th>
                  ),
                )}
              </tr>
            </thead>
            <tbody>
              {r.trades.slice(0, 50).map((t, idx) => (
                <tr
                  key={t.id}
                  className="border-b border-border/20 hover:bg-white/[0.02] transition-colors"
                  data-ocid={`backtest.results.trade.${idx + 1}`}
                >
                  <td className="px-4 py-2 text-cyan-300">{t.symbol}</td>
                  <td className="px-4 py-2">
                    <span
                      className={cn(
                        "px-1.5 py-0.5 rounded text-xs",
                        t.action === TradeAction.Buy
                          ? "text-green-400"
                          : t.action === TradeAction.Sell
                            ? "text-red-400"
                            : "text-muted-foreground",
                      )}
                    >
                      {t.action}
                    </span>
                  </td>
                  <td className="px-4 py-2 text-right">
                    ${t.entryPrice.toFixed(2)}
                  </td>
                  <td className="px-4 py-2 text-right">
                    {t.exitPrice !== undefined
                      ? `$${t.exitPrice.toFixed(2)}`
                      : "—"}
                  </td>
                  <td
                    className={cn(
                      "px-4 py-2 text-right",
                      (t.pnl ?? 0) >= 0 ? "text-green-400" : "text-red-400",
                    )}
                  >
                    {t.pnl !== undefined
                      ? `${t.pnl >= 0 ? "+" : ""}$${t.pnl.toFixed(2)}`
                      : "—"}
                  </td>
                  <td className="px-4 py-2">
                    <span
                      className={cn(
                        "text-xs",
                        t.status === "TakeProfitHit"
                          ? "text-green-400"
                          : t.status === "StopLossHit"
                            ? "text-red-400"
                            : t.status === "Closed"
                              ? "text-cyan-400"
                              : "text-muted-foreground",
                      )}
                    >
                      {t.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {Number(r.totalTrades) > 50 && (
            <div className="px-4 py-3 text-xs text-muted-foreground text-center border-t border-border/20">
              Showing first 50 of {Number(r.totalTrades)} trades
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Backtest() {
  const { data: sessions, isLoading } = useBacktestSessions();
  const startBacktest = useStartBacktest();

  const [name, setName] = useState("BTC Bull Run Analysis");
  const [selectedSymbols, setSelectedSymbols] = useState<string[]>([
    "BTC",
    "ETH",
  ]);
  const [periodDays, setPeriodDays] = useState("30");
  const [initialBalance, setInitialBalance] = useState(100000);
  const [selectedSession, setSelectedSession] =
    useState<BacktestSession | null>(null);

  const toggleSymbol = (sym: string) => {
    setSelectedSymbols((prev) =>
      prev.includes(sym) ? prev.filter((s) => s !== sym) : [...prev, sym],
    );
  };

  const handleStart = async () => {
    if (!selectedSymbols.length) {
      toast.error("Select at least one symbol");
      return;
    }
    const days = Number(periodDays);
    const now = BigInt(Date.now()) * 1_000_000n;
    const startDate = now - BigInt(days * 24 * 60 * 60) * 1_000_000_000n;
    try {
      const result = await startBacktest.mutateAsync({
        name,
        symbols: selectedSymbols,
        startDate,
        endDate: now,
        initialBalance,
      });
      setSelectedSession(result);
      toast.success("Backtest started successfully");
    } catch {
      toast.error("Failed to start backtest");
    }
  };

  return (
    <Layout>
      <div className="p-6 space-y-6" data-ocid="backtest.page">
        {/* Header */}
        <div>
          <h1 className="text-xl font-bold font-mono flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-cyan-400" />
            Backtesting Engine
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Replay historical markets and evaluate Apex Intelligence Core
            strategy performance
          </p>
        </div>

        {/* New Backtest Form */}
        <Card
          className="border-0"
          style={{
            background: "rgba(0,240,255,0.04)",
            border: "1px solid rgba(0,240,255,0.12)",
          }}
        >
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
              <Play className="w-4 h-4 text-cyan-400" />
              New Backtest Session
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Session Name */}
              <div className="space-y-2">
                <Label
                  htmlFor="bt-name"
                  className="text-xs font-mono uppercase text-muted-foreground"
                >
                  Session Name
                </Label>
                <Input
                  id="bt-name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. BTC Bull Run 2024"
                  className="font-mono"
                  data-ocid="backtest.name_input"
                />
              </div>
              {/* Initial Balance */}
              <div className="space-y-2">
                <Label
                  htmlFor="bt-balance"
                  className="text-xs font-mono uppercase text-muted-foreground"
                >
                  Initial Balance (USD)
                </Label>
                <Input
                  id="bt-balance"
                  type="number"
                  value={initialBalance}
                  onChange={(e) => setInitialBalance(Number(e.target.value))}
                  className="font-mono"
                  min={1000}
                  data-ocid="backtest.balance_input"
                />
              </div>
            </div>

            {/* Symbol Selection */}
            <div className="space-y-2">
              <Label className="text-xs font-mono uppercase text-muted-foreground">
                Symbols to Test
              </Label>
              <div className="flex flex-wrap gap-3">
                {SYMBOLS.map((sym) => (
                  <label
                    key={sym}
                    htmlFor={`sym-${sym}`}
                    className="flex items-center gap-2 cursor-pointer select-none"
                  >
                    <Checkbox
                      id={`sym-${sym}`}
                      checked={selectedSymbols.includes(sym)}
                      onCheckedChange={() => toggleSymbol(sym)}
                      data-ocid={`backtest.symbol.${sym.toLowerCase()}`}
                    />
                    <span className="text-sm font-mono">{sym}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Period + Run */}
            <div className="flex flex-col sm:flex-row gap-4 items-end">
              <div className="space-y-2 w-full sm:w-48">
                <Label className="text-xs font-mono uppercase text-muted-foreground">
                  Time Period
                </Label>
                <Select value={periodDays} onValueChange={setPeriodDays}>
                  <SelectTrigger
                    className="font-mono"
                    data-ocid="backtest.period_select"
                  >
                    <SelectValue placeholder="Select period" />
                  </SelectTrigger>
                  <SelectContent>
                    {PERIODS.map((p) => (
                      <SelectItem
                        key={p.days}
                        value={p.days.toString()}
                        className="font-mono"
                      >
                        {p.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button
                className="gap-2 font-mono shrink-0"
                style={{
                  background: startBacktest.isPending
                    ? "rgba(0,240,255,0.15)"
                    : "rgba(0,240,255,0.2)",
                  border: "1px solid rgba(0,240,255,0.4)",
                  color: "#00f0ff",
                }}
                onClick={handleStart}
                disabled={
                  startBacktest.isPending ||
                  !name.trim() ||
                  selectedSymbols.length === 0
                }
                data-ocid="backtest.start_button"
              >
                {startBacktest.isPending ? (
                  <>
                    <span className="animate-spin inline-block w-3.5 h-3.5 border-2 border-cyan-400/30 border-t-cyan-400 rounded-full" />
                    Running AI Backtest...
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5" />
                    Run Backtest
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Selected Session Results */}
        {selectedSession && (
          <Card
            className="border-0"
            style={{
              background: "rgba(0,240,255,0.02)",
              border: "1px solid rgba(0,240,255,0.15)",
            }}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  Results: {selectedSession.name}
                </CardTitle>
                <Badge
                  variant="outline"
                  className={cn(
                    "text-xs font-mono",
                    selectedSession.status === BacktestStatus.Completed
                      ? "border-green-500/30 text-green-400"
                      : selectedSession.status === BacktestStatus.Running
                        ? "border-cyan-500/30 text-cyan-400"
                        : "border-red-500/30 text-red-400",
                  )}
                >
                  {selectedSession.status}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground mt-1 font-mono">
                {selectedSession.symbols.join(", ")} · $
                {selectedSession.initialBalance.toLocaleString()} initial ·{" "}
                {formatDate(selectedSession.startDate)} →{" "}
                {formatDate(selectedSession.endDate)}
              </p>
            </CardHeader>
            <CardContent>
              <ResultsPanel session={selectedSession} />
            </CardContent>
          </Card>
        )}

        {/* Session History */}
        <Card
          className="border-0"
          style={{
            background: "rgba(10,14,26,0.6)",
            border: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono uppercase tracking-wider">
              Session History
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-2">
                {Array.from({ length: 3 }, (_, i) => `sk-bt-${i}`).map((k) => (
                  <Skeleton key={k} className="h-16 w-full" />
                ))}
              </div>
            ) : !sessions || sessions.length === 0 ? (
              <div
                className="text-center py-8"
                data-ocid="backtest.empty_state"
              >
                <BookOpen className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">
                  No backtest sessions yet — configure and run one above
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {sessions.map((s, idx) => (
                  <button
                    type="button"
                    key={s.id}
                    className={cn(
                      "w-full text-left p-4 rounded-lg border transition-all cursor-pointer",
                      selectedSession?.id === s.id
                        ? "border-cyan-500/40"
                        : "border-border/20 hover:border-border/40",
                    )}
                    style={{
                      background:
                        selectedSession?.id === s.id
                          ? "rgba(0,240,255,0.06)"
                          : "rgba(255,255,255,0.02)",
                    }}
                    onClick={() =>
                      setSelectedSession(
                        selectedSession?.id === s.id ? null : s,
                      )
                    }
                    data-ocid={`backtest.sessions.item.${idx + 1}`}
                  >
                    <div className="flex items-center justify-between gap-4">
                      <div className="min-w-0 flex items-center gap-3">
                        {selectedSession?.id === s.id ? (
                          <ChevronRight className="w-3.5 h-3.5 text-cyan-400 shrink-0 rotate-90" />
                        ) : (
                          <ChevronRight className="w-3.5 h-3.5 text-muted-foreground/40 shrink-0" />
                        )}
                        <div className="min-w-0">
                          <div className="font-mono font-medium truncate text-sm">
                            {s.name}
                          </div>
                          <div className="text-xs text-muted-foreground mt-0.5">
                            {s.symbols.join(", ")} · $
                            {s.initialBalance.toLocaleString()} ·{" "}
                            {formatDate(s.startDate)}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 shrink-0">
                        {s.results && (
                          <div className="flex items-center gap-1.5 text-xs font-mono">
                            {s.results.totalReturn >= 0 ? (
                              <TrendingUp className="w-3.5 h-3.5 text-green-400" />
                            ) : (
                              <TrendingDown className="w-3.5 h-3.5 text-red-400" />
                            )}
                            <span
                              className={
                                s.results.totalReturn >= 0
                                  ? "text-green-400"
                                  : "text-red-400"
                              }
                            >
                              {s.results.totalReturn >= 0 ? "+" : ""}
                              {s.results.totalReturn.toFixed(2)}%
                            </span>
                          </div>
                        )}
                        <Badge
                          variant="outline"
                          className={cn(
                            "text-xs",
                            s.status === BacktestStatus.Completed
                              ? "border-green-500/30 text-green-400"
                              : s.status === BacktestStatus.Running
                                ? "border-cyan-500/30 text-cyan-400 animate-pulse"
                                : "border-red-500/30 text-red-400",
                          )}
                        >
                          {s.status}
                        </Badge>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Disclaimer */}
        <div
          className="p-4 rounded-xl text-xs text-muted-foreground leading-relaxed border border-border/20"
          style={{ background: "rgba(255,255,255,0.02)" }}
        >
          <strong className="text-foreground">Disclaimer:</strong> Backtesting
          results are based on historical data and do not guarantee future
          performance. Cryptocurrency trading involves substantial risk. Always
          validate strategies with paper trading before enabling live
          automation.
        </div>
      </div>
    </Layout>
  );
}
