import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useInternetIdentity } from "@caffeineai/core-infrastructure";
import { Brain, Cpu, Lock, Shield, Zap } from "lucide-react";

const FEATURES = [
  {
    icon: Brain,
    label: "AI Intelligence Core",
    desc: "Autonomous market analysis & decision engine",
  },
  {
    icon: Zap,
    label: "Autonomous Paper Trading",
    desc: "Real-time trades powered by live market data",
  },
  {
    icon: Shield,
    label: "Risk Management AI",
    desc: "Capital protection with smart position sizing",
  },
  {
    icon: Cpu,
    label: "AI Training Environment",
    desc: "Self-improving strategies via historical replay",
  },
];

export function LoginScreen() {
  const { login, loginStatus } = useInternetIdentity();

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 items-center justify-center mb-4 shadow-glow">
            <Cpu className="w-8 h-8 text-cyan-400" />
          </div>
          <h1 className="text-2xl font-bold font-mono text-foreground tracking-wide">
            APEX AI TRADER
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Intelligence Core — Autonomous Crypto Trading
          </p>
          <Badge
            variant="outline"
            className="mt-2 text-xs font-mono border-yellow-500/30 text-yellow-400"
          >
            PAPER TRADING MODE
          </Badge>
        </div>

        {/* Features */}
        <div className="space-y-3 mb-8">
          {FEATURES.map((f) => {
            const Icon = f.icon;
            return (
              <div
                key={f.label}
                className="glass-panel rounded-xl p-4 flex items-start gap-3"
              >
                <div className="w-8 h-8 rounded-lg bg-cyan-500/10 flex items-center justify-center flex-shrink-0">
                  <Icon className="w-4 h-4 text-cyan-400" />
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-foreground">
                    {f.label}
                  </div>
                  <div className="text-xs text-muted-foreground">{f.desc}</div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Login */}
        <Button
          size="lg"
          className="w-full gap-2 bg-cyan-500 hover:bg-cyan-400 text-background font-semibold"
          onClick={() => login()}
          disabled={loginStatus === "logging-in"}
          data-ocid="login.submit_button"
        >
          <Lock className="w-4 h-4" />
          {loginStatus === "logging-in"
            ? "Authenticating..."
            : "Connect with Internet Identity"}
        </Button>

        <p className="text-xs text-muted-foreground text-center mt-4 leading-relaxed">
          Cryptocurrency trading involves substantial risk and may result in
          loss of capital. This software does not guarantee profits.
          AI-generated trades are probabilistic and should be used responsibly.
          Always begin with paper trading before enabling live automation.
        </p>
      </div>
    </div>
  );
}
