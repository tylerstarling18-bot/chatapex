import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  useLatestDecisions,
  useMarketCandles,
  useMarketCondition,
  useMarketSnapshot,
  useTradeHistory,
  useTradeSnapshot,
} from "@/hooks/useQueries";
import { cn } from "@/lib/utils";
import type { Trade, TradeSnapshot } from "@/types";
import { MarketCondition, TradeAction } from "@/types";
import {
  Activity,
  CandlestickChart,
  Info,
  Loader2,
  RefreshCw,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

// ─── types ────────────────────────────────────────────────────────────────────

type Candle = {
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  timestamp: number; // ms
};

type Symbol = "BTC" | "ETH" | "BNB" | "SOL" | "ADA";
type Timeframe = "1m" | "5m" | "15m" | "1h" | "4h" | "1d";
type ChartType = "candle" | "bar" | "line";
type ConfidenceTier = "all" | "high" | "medium" | "low";
type OutcomeFilter = "all" | "wins" | "losses";

type TooltipData = {
  x: number;
  y: number;
  trade: Trade;
  snapshot: TradeSnapshot | null;
} | null;

// ─── helpers ──────────────────────────────────────────────────────────────────

const SYMBOLS: Symbol[] = ["BTC", "ETH", "BNB", "SOL", "ADA"];
const TIMEFRAMES: Timeframe[] = ["1m", "5m", "15m", "1h", "4h", "1d"];

// Map timeframe UI choice → approximate days to request from backend
const TF_DAYS: Record<Timeframe, bigint> = {
  "1m": 1n,
  "5m": 3n,
  "15m": 7n,
  "1h": 14n,
  "4h": 30n,
  "1d": 90n,
};

// Resample raw backend candles (1-hour OHLCV) into the requested timeframe bucket.
function resampleCandles(raw: Candle[], tf: Timeframe): Candle[] {
  if (!raw.length) return [];
  const tfMs: Record<Timeframe, number> = {
    "1m": 60_000,
    "5m": 300_000,
    "15m": 900_000,
    "1h": 3_600_000,
    "4h": 14_400_000,
    "1d": 86_400_000,
  };
  const bucket = tfMs[tf];
  const buckets = new Map<number, Candle>();
  for (const c of raw) {
    const key = Math.floor(c.timestamp / bucket) * bucket;
    const existing = buckets.get(key);
    if (!existing) {
      buckets.set(key, { ...c, timestamp: key });
    } else {
      buckets.set(key, {
        ...existing,
        high: Math.max(existing.high, c.high),
        low: Math.min(existing.low, c.low),
        close: c.close,
        volume: existing.volume + c.volume,
      });
    }
  }
  return Array.from(buckets.values()).sort((a, b) => a.timestamp - b.timestamp);
}

function formatPrice(p: number): string {
  if (p >= 1000)
    return p.toLocaleString(undefined, { maximumFractionDigits: 0 });
  if (p >= 1) return p.toFixed(2);
  return p.toFixed(4);
}

function formatTs(ts: number, tf: Timeframe): string {
  const d = new Date(ts);
  if (tf === "1d")
    return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
  if (tf === "4h" || tf === "1h")
    return d.toLocaleString(undefined, {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  return d.toLocaleTimeString(undefined, {
    hour: "2-digit",
    minute: "2-digit",
  });
}

function regimeMeta(cond: MarketCondition | null): {
  label: string;
  color: string;
  bg: string;
} {
  const map: Record<string, { label: string; color: string; bg: string }> = {
    [MarketCondition.StrongBullish]: {
      label: "Strong Bullish",
      color: "#4ade80",
      bg: "rgba(74,222,128,0.12)",
    },
    [MarketCondition.Bullish]: {
      label: "Bullish",
      color: "#34d399",
      bg: "rgba(52,211,153,0.12)",
    },
    [MarketCondition.Neutral]: {
      label: "Neutral",
      color: "#22d3ee",
      bg: "rgba(34,211,238,0.12)",
    },
    [MarketCondition.Ranging]: {
      label: "Ranging",
      color: "#fbbf24",
      bg: "rgba(251,191,36,0.12)",
    },
    [MarketCondition.WeakBearish]: {
      label: "Weak Bearish",
      color: "#fb923c",
      bg: "rgba(251,146,60,0.12)",
    },
    [MarketCondition.StrongBearish]: {
      label: "Strong Bearish",
      color: "#f87171",
      bg: "rgba(248,113,113,0.12)",
    },
    [MarketCondition.HighVolatility]: {
      label: "High Volatility",
      color: "#e879f9",
      bg: "rgba(232,121,249,0.12)",
    },
    [MarketCondition.ManipulationRisk]: {
      label: "Manipulation Risk",
      color: "#facc15",
      bg: "rgba(250,204,21,0.12)",
    },
    [MarketCondition.LowLiquidityDanger]: {
      label: "Low Liquidity",
      color: "#94a3b8",
      bg: "rgba(148,163,184,0.12)",
    },
  };
  if (!cond)
    return { label: "Unknown", color: "#94a3b8", bg: "rgba(148,163,184,0.12)" };
  return (
    map[cond] ?? {
      label: String(cond),
      color: "#22d3ee",
      bg: "rgba(34,211,238,0.12)",
    }
  );
}

// ─── SVG Candlestick Chart ────────────────────────────────────────────────────

const CHART_PAD = { top: 18, right: 60, bottom: 32, left: 8 };
const GRID_ROWS = 5;

type ChartMarker = {
  type: "entry" | "exit" | "stop";
  price: number;
  ts: number;
  trade: Trade;
};

type SignalZone = {
  priceMid: number;
  confidence: number;
  action: TradeAction;
  id: string;
  ts: number;
};

interface CandlestickSVGProps {
  candles: Candle[];
  chartType: ChartType;
  markers: ChartMarker[];
  signalZones: SignalZone[];
  onMarkerHover: (marker: ChartMarker | null, x: number, y: number) => void;
  width: number;
  height: number;
}

function CandlestickSVG({
  candles,
  chartType,
  markers,
  signalZones,
  onMarkerHover,
  width,
  height,
}: CandlestickSVGProps) {
  if (candles.length === 0) return null;

  const plotW = width - CHART_PAD.left - CHART_PAD.right;
  const plotH = height - CHART_PAD.top - CHART_PAD.bottom;

  // Price range
  const allPrices = candles.flatMap((c) => [c.high, c.low]);
  let minP = Math.min(...allPrices);
  let maxP = Math.max(...allPrices);
  // Expand slightly
  const pad = (maxP - minP) * 0.06;
  minP -= pad;
  maxP += pad;

  const xScale = (i: number) =>
    CHART_PAD.left + (i / (candles.length - 1 || 1)) * plotW;
  const yScale = (p: number) =>
    CHART_PAD.top + plotH - ((p - minP) / (maxP - minP || 1)) * plotH;

  const candleW = Math.max(2, Math.floor(plotW / candles.length) - 1);

  // Grid lines & labels
  const gridPrices: number[] = [];
  for (let r = 0; r <= GRID_ROWS; r++) {
    gridPrices.push(minP + (r / GRID_ROWS) * (maxP - minP));
  }

  // X-axis label every ~10 candles
  const xLabelStep = Math.max(1, Math.floor(candles.length / 8));

  // Line chart path
  const linePath = candles
    .map((c, i) => {
      const cx = xScale(i);
      const cy = yScale(c.close);
      return `${i === 0 ? "M" : "L"} ${cx} ${cy}`;
    })
    .join(" ");

  return (
    <svg
      width={width}
      height={height}
      style={{ display: "block", overflow: "visible" }}
      role="img"
      aria-label="AI candlestick chart"
    >
      {/* Grid lines */}
      {gridPrices.map((p, _idx) => {
        const gy = yScale(p);
        return (
          <g key={`grid-${p.toFixed(4)}`}>
            <line
              x1={CHART_PAD.left}
              y1={gy}
              x2={CHART_PAD.left + plotW}
              y2={gy}
              stroke="rgba(255,255,255,0.05)"
              strokeWidth="1"
            />
            <text
              x={CHART_PAD.left + plotW + 4}
              y={gy + 4}
              fontSize="9"
              fill="rgba(148,163,184,0.7)"
              fontFamily="monospace"
            >
              {formatPrice(p)}
            </text>
          </g>
        );
      })}

      {/* X-axis labels */}
      {candles.map((c, i) => {
        if (i % xLabelStep !== 0) return null;
        const cx = xScale(i);
        return (
          <text
            key={`xl-${c.timestamp}`}
            x={cx}
            y={height - 4}
            fontSize="8"
            fill="rgba(148,163,184,0.6)"
            fontFamily="monospace"
            textAnchor="middle"
          >
            {formatTs(c.timestamp, "1h")}
          </text>
        );
      })}

      {/* Signal zones (shaded bands) */}
      {signalZones.map((zone) => {
        const bandHalf = (maxP - minP) * 0.005;
        const ytop = yScale(zone.priceMid + bandHalf);
        const ybot = yScale(zone.priceMid - bandHalf);
        const alpha = 0.06 + (zone.confidence - 60) * 0.003;
        const isBuy = zone.action === TradeAction.Buy;
        const fill = isBuy
          ? `rgba(34,211,238,${alpha.toFixed(2)})`
          : `rgba(251,191,36,${alpha.toFixed(2)})`;
        const stroke = isBuy ? "rgba(34,211,238,0.5)" : "rgba(251,191,36,0.5)";
        return (
          <g key={`zone-${zone.id}`}>
            <rect
              x={CHART_PAD.left}
              y={ytop}
              width={plotW}
              height={ybot - ytop}
              fill={fill}
            />
            <line
              x1={CHART_PAD.left}
              y1={yScale(zone.priceMid)}
              x2={CHART_PAD.left + plotW}
              y2={yScale(zone.priceMid)}
              stroke={stroke}
              strokeWidth="1"
              strokeDasharray="4 3"
            />
            <text
              x={CHART_PAD.left + 4}
              y={yScale(zone.priceMid) - 4}
              fontSize="9"
              fill={isBuy ? "rgba(34,211,238,0.8)" : "rgba(251,191,36,0.8)"}
              fontFamily="monospace"
            >
              {isBuy ? "▲ BUY ZONE" : "◆ SIGNAL"} {zone.confidence.toFixed(0)}%
            </text>
          </g>
        );
      })}

      {/* Candles / Bars / Line */}
      {chartType === "line" ? (
        <>
          <path
            d={linePath}
            stroke="rgba(34,211,238,0.8)"
            strokeWidth="1.5"
            fill="none"
          />
          {/* Area fill */}
          <path
            d={`${linePath} L ${xScale(candles.length - 1)} ${CHART_PAD.top + plotH} L ${xScale(0)} ${CHART_PAD.top + plotH} Z`}
            fill="url(#lineGrad)"
          />
          <defs>
            <linearGradient id="lineGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="rgba(34,211,238,0.18)" />
              <stop offset="100%" stopColor="rgba(34,211,238,0)" />
            </linearGradient>
          </defs>
        </>
      ) : (
        candles.map((c, i) => {
          const cx = CHART_PAD.left + (i / (candles.length - 1 || 1)) * plotW;
          const isUp = c.close >= c.open;
          const color = isUp ? "#4ade80" : "#f87171";
          const bodyTop = yScale(Math.max(c.open, c.close));
          const bodyBot = yScale(Math.min(c.open, c.close));
          const bodyH = Math.max(1, bodyBot - bodyTop);
          const halfW = candleW / 2;

          if (chartType === "bar") {
            return (
              <g key={`bar-${c.timestamp}`}>
                <line
                  x1={cx}
                  y1={yScale(c.high)}
                  x2={cx}
                  y2={yScale(c.low)}
                  stroke={color}
                  strokeWidth="1"
                />
                <line
                  x1={cx - halfW}
                  y1={yScale(c.open)}
                  x2={cx}
                  y2={yScale(c.open)}
                  stroke={color}
                  strokeWidth="1.5"
                />
                <line
                  x1={cx}
                  y1={yScale(c.close)}
                  x2={cx + halfW}
                  y2={yScale(c.close)}
                  stroke={color}
                  strokeWidth="1.5"
                />
              </g>
            );
          }

          return (
            <g key={`candle-${c.timestamp}`}>
              {/* Wick */}
              <line
                x1={cx}
                y1={yScale(c.high)}
                x2={cx}
                y2={yScale(c.low)}
                stroke={color}
                strokeWidth="1"
                opacity="0.7"
              />
              {/* Body */}
              <rect
                x={cx - halfW}
                y={bodyTop}
                width={candleW}
                height={bodyH}
                fill={isUp ? "rgba(74,222,128,0.75)" : "rgba(248,113,113,0.75)"}
                stroke={color}
                strokeWidth="0.5"
              />
            </g>
          );
        })
      )}

      {/* Trade markers */}
      {markers.map((m, idx) => {
        // find nearest candle index by timestamp
        const mi = candles.reduce(
          (best, c, ci) =>
            Math.abs(c.timestamp - m.ts) <
            Math.abs(candles[best].timestamp - m.ts)
              ? ci
              : best,
          0,
        );
        const mx = xScale(mi);
        const my = yScale(m.price);

        if (m.type === "entry") {
          return (
            <g
              key={`m-entry-${m.trade.id}`}
              style={{ cursor: "pointer" }}
              onMouseEnter={() => onMarkerHover(m, mx, my)}
              onMouseLeave={() => onMarkerHover(null, 0, 0)}
              data-ocid={`chart.marker.entry.${idx + 1}`}
            >
              <polygon
                points={`${mx},${my - 10} ${mx - 6},${my} ${mx + 6},${my}`}
                fill="#4ade80"
                stroke="#16a34a"
                strokeWidth="1"
                opacity="0.9"
              />
              <text
                x={mx}
                y={my - 13}
                textAnchor="middle"
                fontSize="7"
                fill="#4ade80"
                fontFamily="monospace"
              >
                {m.trade.entryPrice >= 1000
                  ? `${(m.trade.entryPrice / 1000).toFixed(1)}k`
                  : m.trade.entryPrice.toFixed(1)}
              </text>
            </g>
          );
        }
        if (m.type === "exit") {
          return (
            <g
              key={`m-exit-${m.trade.id}`}
              style={{ cursor: "pointer" }}
              onMouseEnter={() => onMarkerHover(m, mx, my)}
              onMouseLeave={() => onMarkerHover(null, 0, 0)}
              data-ocid={`chart.marker.exit.${idx + 1}`}
            >
              <polygon
                points={`${mx},${my + 10} ${mx - 6},${my} ${mx + 6},${my}`}
                fill="#f87171"
                stroke="#dc2626"
                strokeWidth="1"
                opacity="0.9"
              />
            </g>
          );
        }
        // stop loss
        return (
          <g
            key={`m-sl-${m.trade.id}`}
            style={{ cursor: "pointer" }}
            onMouseEnter={() => onMarkerHover(m, mx, my)}
            onMouseLeave={() => onMarkerHover(null, 0, 0)}
            data-ocid={`chart.marker.sl.${idx + 1}`}
          >
            <line
              x1={mx - 7}
              y1={my}
              x2={mx + 7}
              y2={my}
              stroke="#fb923c"
              strokeWidth="2"
              strokeLinecap="round"
            />
          </g>
        );
      })}
    </svg>
  );
}

// ─── Tooltip ──────────────────────────────────────────────────────────────────

function TradeTooltip({ tooltip }: { tooltip: TooltipData }) {
  if (!tooltip) return null;
  const { trade, snapshot, x, y } = tooltip;
  const pnl = trade.pnl ?? 0;
  const isWin = pnl >= 0;

  return (
    <div
      style={{
        position: "absolute",
        left: x + 12,
        top: y - 10,
        zIndex: 50,
        maxWidth: 260,
        pointerEvents: "none",
      }}
      className="glass-panel rounded-lg p-3 text-xs font-mono"
    >
      <div className="flex items-center gap-2 mb-2">
        <span className="font-bold">{trade.symbol}</span>
        <span
          className={cn("font-bold", isWin ? "text-green-400" : "text-red-400")}
        >
          {isWin ? "+" : ""}
          {pnl.toFixed(2)} ({(trade.pnlPercent ?? 0).toFixed(2)}%)
        </span>
      </div>
      <div className="space-y-1 text-muted-foreground">
        <div>
          Entry:{" "}
          <span className="text-foreground">
            ${formatPrice(trade.entryPrice)}
          </span>
        </div>
        {trade.exitPrice != null && (
          <div>
            Exit:{" "}
            <span className="text-foreground">
              ${formatPrice(trade.exitPrice)}
            </span>
          </div>
        )}
        <div>
          SL:{" "}
          <span className="text-orange-400">
            ${formatPrice(trade.stopLoss)}
          </span>
        </div>
        <div>
          Qty:{" "}
          <span className="text-foreground">{trade.quantity.toFixed(4)}</span>
        </div>
        {snapshot && (
          <>
            <div className="border-t border-border/30 pt-1 mt-1">
              Confidence:{" "}
              <span className="text-cyan-400">
                {(snapshot.confidenceFactors.total * 100).toFixed(0)}%
              </span>
            </div>
            <div>
              Regime:{" "}
              <span className="text-foreground">
                {String(snapshot.marketRegimeAtEntry)}
              </span>
            </div>
            <div>
              Slippage:{" "}
              <span className="text-yellow-400">
                {(snapshot.simulatedSlippage * 100).toFixed(3)}%
              </span>
            </div>
            <div>
              Fees:{" "}
              <span className="text-yellow-400">
                ${snapshot.simulatedFees.toFixed(2)}
              </span>
            </div>
            <p className="text-[10px] text-muted-foreground mt-1.5 line-clamp-3 leading-relaxed">
              {snapshot.aiReasoningText}
            </p>
          </>
        )}
      </div>
    </div>
  );
}

// ─── Main Chart Page ──────────────────────────────────────────────────────────

export default function Chart() {
  const [symbol, setSymbol] = useState<Symbol>("BTC");
  const [timeframe, setTimeframe] = useState<Timeframe>("1h");
  const [chartType, setChartType] = useState<ChartType>("candle");
  const [showEntries, setShowEntries] = useState(true);
  const [showExits, setShowExits] = useState(true);
  const [showStops, setShowStops] = useState(true);
  const [showSignals, setShowSignals] = useState(true);
  const [confidenceTier, setConfidenceTier] = useState<ConfidenceTier>("all");
  const [outcomeFilter, setOutcomeFilter] = useState<OutcomeFilter>("all");
  const [tooltip, setTooltip] = useState<TooltipData>(null);
  const [snapshotTradeId, setSnapshotTradeId] = useState("");
  const [_autoRefresh, setAutoRefresh] = useState(0); // counter to force re-gen
  const chartRef = useRef<HTMLDivElement>(null);
  const [chartSize, setChartSize] = useState({ w: 800, h: 420 });

  // Resize observer
  useEffect(() => {
    if (!chartRef.current) return;
    const ro = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        setChartSize({ w: Math.max(300, width), h: Math.max(200, height) });
      }
    });
    ro.observe(chartRef.current);
    return () => ro.disconnect();
  }, []);

  // Auto-refresh every 60s
  useEffect(() => {
    const id = setInterval(() => setAutoRefresh((n) => n + 1), 60_000);
    return () => clearInterval(id);
  }, []);

  const { data: snapshot, refetch: refetchSnapshot } = useMarketSnapshot();
  const { data: decisions } = useLatestDecisions(30n);
  const { data: trades } = useTradeHistory(50n);
  const { data: condition } = useMarketCondition();
  const { data: tradeSnap } = useTradeSnapshot(snapshotTradeId);
  const {
    data: rawCandles = [],
    isLoading: candlesLoading,
    refetch: refetchCandles,
  } = useMarketCandles(symbol, TF_DAYS[timeframe]);

  // Eagerly refresh on mount — stored in refs so the effect has no reactive deps.
  const refetchSnapshotRef = useRef(refetchSnapshot);
  const refetchCandlesRef = useRef(refetchCandles);
  refetchSnapshotRef.current = refetchSnapshot;
  refetchCandlesRef.current = refetchCandles;
  useEffect(() => {
    refetchSnapshotRef.current();
    refetchCandlesRef.current();
    // Empty dep array: run exactly once on mount. Refs always hold latest callbacks.
  }, []);

  // Get current price for selected symbol — ONLY from live backend, never hardcoded
  const marketData = useMemo(() => {
    return snapshot?.markets?.find((m) => m.symbol.startsWith(symbol)) ?? null;
  }, [snapshot, symbol]);

  const basePrice = marketData?.price ?? null;

  // Resample backend candles (timestamps in seconds) into selected timeframe
  const candles = useMemo(() => {
    return resampleCandles(
      rawCandles.map((c) => ({ ...c, timestamp: Number(c.timestamp) * 1000 })),
      timeframe,
    );
  }, [rawCandles, timeframe]);

  // Build trade markers — backend timestamps are seconds, convert to ms
  const allMarkers = useMemo((): ChartMarker[] => {
    if (!trades) return [];
    const filtered = trades.filter((t) => {
      if (!t.symbol.startsWith(symbol)) return false;
      const pnl = t.pnl ?? 0;
      if (outcomeFilter === "wins" && pnl < 0) return false;
      if (outcomeFilter === "losses" && pnl >= 0) return false;
      return true;
    });
    const result: ChartMarker[] = [];
    for (const t of filtered) {
      const openMs = Number(t.openTime) * 1000;
      const closeMs = Number(t.closeTime) * 1000;
      if (showEntries)
        result.push({
          type: "entry",
          price: t.entryPrice,
          ts: openMs,
          trade: t,
        });
      if (showExits && t.exitPrice != null)
        result.push({
          type: "exit",
          price: t.exitPrice,
          ts: closeMs,
          trade: t,
        });
      if (showStops)
        result.push({ type: "stop", price: t.stopLoss, ts: openMs, trade: t });
    }
    return result;
  }, [trades, symbol, outcomeFilter, showEntries, showExits, showStops]);

  // Filter by confidence tier — use snapshot confidence if hovering, else skip
  const markers = useMemo(() => {
    if (confidenceTier === "all") return allMarkers;
    // We can only filter entry markers by confidence (no confidence on the Trade object directly)
    // So we only filter entry markers and keep exit/stop as-is
    return allMarkers; // confidence filtering is best-effort without snapshot per trade
  }, [allMarkers, confidenceTier]);

  // Build signal zones from latest decisions
  const signalZones = useMemo((): SignalZone[] => {
    if (!showSignals || !decisions) return [];
    return decisions
      .filter((d) => {
        const conf = d.decision.confidence * 100;
        if (
          d.decision.action === TradeAction.Skip ||
          d.decision.action === TradeAction.Hold
        )
          return false;
        if (conf < 60) return false;
        if (!d.decision.symbol.startsWith(symbol)) return false;
        if (confidenceTier === "high" && conf < 80) return false;
        if (confidenceTier === "medium" && (conf < 70 || conf >= 80))
          return false;
        if (confidenceTier === "low" && conf >= 70) return false;
        return true;
      })
      .map(
        (d): SignalZone => ({
          id: d.decision.id,
          priceMid: d.decision.entryPrice,
          confidence: d.decision.confidence * 100,
          action: d.decision.action,
          ts: Number(d.decision.timestamp) * 1000,
        }),
      )
      .slice(0, 4);
  }, [decisions, showSignals, symbol, confidenceTier]);

  // AI confidence from decisions for current symbol
  const aiConfidence = useMemo(() => {
    if (!decisions) return null;
    const relevant = decisions.filter((d) =>
      d.decision.symbol.startsWith(symbol),
    );
    if (!relevant.length) return null;
    const avg =
      relevant.reduce((s, d) => s + d.decision.confidence, 0) / relevant.length;
    return avg * 100;
  }, [decisions, symbol]);

  const regime = useMemo(() => regimeMeta(condition ?? null), [condition]);

  const handleMarkerHover = useCallback(
    (marker: ChartMarker | null, x: number, y: number) => {
      if (!marker) {
        setTooltip(null);
        setSnapshotTradeId("");
        return;
      }
      setTooltip({ trade: marker.trade, snapshot: tradeSnap ?? null, x, y });
      setSnapshotTradeId(marker.trade.id);
    },
    [tradeSnap],
  );

  // Update tooltip snapshot when it loads
  useEffect(() => {
    if (tradeSnap) {
      setTooltip((prev) => (prev ? { ...prev, snapshot: tradeSnap } : null));
    }
  }, [tradeSnap]);

  const change24h = marketData?.change24h ?? 0;
  const isPositive = change24h >= 0;
  const hasLivePrice = basePrice !== null;

  return (
    <Layout>
      <div
        className="flex flex-col"
        style={{ minHeight: "calc(100vh - 56px)" }}
        data-ocid="chart.page"
      >
        {/* Top Controls Bar */}
        <div
          className="flex flex-wrap items-center gap-3 px-4 py-2.5 border-b"
          style={{
            background: "rgba(10,14,26,0.7)",
            borderColor: "rgba(34,211,238,0.12)",
          }}
        >
          {/* Symbol */}
          <div className="flex items-center gap-1.5">
            <CandlestickChart className="w-4 h-4 text-cyan-400" />
            <Select
              value={symbol}
              onValueChange={(v) => setSymbol(v as Symbol)}
            >
              <SelectTrigger
                className="h-7 text-xs font-mono w-24"
                style={{
                  background: "rgba(10,14,26,0.8)",
                  borderColor: "rgba(34,211,238,0.2)",
                }}
                data-ocid="chart.symbol_select"
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {SYMBOLS.map((s) => (
                  <SelectItem key={s} value={s} className="font-mono text-xs">
                    {s}/USDT
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Timeframe */}
          <div className="flex gap-0.5">
            {TIMEFRAMES.map((tf) => (
              <button
                key={tf}
                type="button"
                onClick={() => setTimeframe(tf)}
                className={cn(
                  "px-2 py-0.5 text-[10px] font-mono rounded transition-colors",
                  timeframe === tf
                    ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40"
                    : "text-muted-foreground hover:text-foreground border border-transparent",
                )}
                data-ocid={`chart.timeframe.${tf}`}
              >
                {tf}
              </button>
            ))}
          </div>

          {/* Chart type */}
          <div className="flex gap-0.5 ml-1">
            {(["candle", "bar", "line"] as ChartType[]).map((ct) => (
              <button
                key={ct}
                type="button"
                onClick={() => setChartType(ct)}
                className={cn(
                  "px-2 py-0.5 text-[10px] font-mono rounded capitalize transition-colors",
                  chartType === ct
                    ? "bg-purple-500/20 text-purple-300 border border-purple-500/40"
                    : "text-muted-foreground hover:text-foreground border border-transparent",
                )}
                data-ocid={`chart.type.${ct}`}
              >
                {ct}
              </button>
            ))}
          </div>

          {/* Live price — only shown when live data is available */}
          <div className="ml-auto flex items-center gap-3">
            <div className="flex items-center gap-2">
              {hasLivePrice ? (
                <Activity className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              ) : (
                <Loader2 className="w-3.5 h-3.5 text-muted-foreground animate-spin" />
              )}
              <span className="font-mono text-sm font-bold">
                {hasLivePrice ? `${formatPrice(basePrice!)}` : "Loading…"}
              </span>
              {hasLivePrice && (
                <span
                  className={cn(
                    "text-xs font-mono",
                    isPositive ? "text-green-400" : "text-red-400",
                  )}
                >
                  {isPositive ? "+" : ""}
                  {change24h.toFixed(2)}%
                </span>
              )}
            </div>
            {/* Regime badge */}
            <div
              className="flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-mono border"
              style={{
                color: regime.color,
                background: regime.bg,
                borderColor: `${regime.color}60`,
              }}
              data-ocid="chart.regime_badge"
            >
              <div
                className="w-1.5 h-1.5 rounded-full animate-pulse"
                style={{ background: regime.color }}
              />
              {regime.label}
            </div>
            {/* AI confidence */}
            {aiConfidence !== null && (
              <div
                className="text-[10px] font-mono px-2 py-0.5 rounded border"
                style={{
                  color: "#22d3ee",
                  borderColor: "rgba(34,211,238,0.3)",
                  background: "rgba(34,211,238,0.06)",
                }}
                data-ocid="chart.ai_confidence"
              >
                AI {aiConfidence.toFixed(0)}% conf
              </div>
            )}
          </div>
        </div>

        {/* Main chart area */}
        <div className="flex flex-1" style={{ minHeight: 0 }}>
          {/* Chart canvas */}
          <div
            className="relative flex-1"
            style={{ background: "rgba(4,8,20,0.95)", minHeight: 320 }}
            ref={chartRef}
          >
            {candlesLoading && candles.length === 0 ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
                <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
                <p className="text-sm font-mono text-cyan-400">
                  Loading live market data…
                </p>
                <p className="text-xs font-mono text-muted-foreground">
                  Fetching {symbol}/USDT candles from backend
                </p>
              </div>
            ) : !candlesLoading && candles.length === 0 ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
                <Activity className="w-8 h-8 text-muted-foreground/40" />
                <p className="text-sm font-mono text-muted-foreground">
                  No candle data available yet
                </p>
                <p className="text-xs font-mono text-muted-foreground">
                  Start the bot to collect live market data
                </p>
                <button
                  type="button"
                  onClick={() => refetchCandles()}
                  className="mt-2 text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors"
                >
                  <RefreshCw className="w-3 h-3" />
                  Retry
                </button>
              </div>
            ) : (
              <CandlestickSVG
                candles={candles}
                chartType={chartType}
                markers={markers}
                signalZones={signalZones}
                onMarkerHover={handleMarkerHover}
                width={chartSize.w}
                height={chartSize.h}
              />
            )}
            {/* Tooltip */}
            <TradeTooltip tooltip={tooltip} />
          </div>
        </div>

        {/* Bottom panel — 30% height */}
        <div
          className="border-t"
          style={{
            borderColor: "rgba(34,211,238,0.1)",
            background: "rgba(10,14,26,0.9)",
          }}
        >
          <div className="flex flex-wrap gap-x-6 gap-y-3 px-4 py-3">
            {/* Toggles */}
            <div className="flex flex-wrap gap-4" data-ocid="chart.toggles">
              <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest self-center">
                Show:
              </div>
              {(
                [
                  {
                    id: "entries",
                    label: "Entries",
                    color: "#4ade80",
                    state: showEntries,
                    set: setShowEntries,
                  },
                  {
                    id: "exits",
                    label: "Exits",
                    color: "#f87171",
                    state: showExits,
                    set: setShowExits,
                  },
                  {
                    id: "stops",
                    label: "Stop Losses",
                    color: "#fb923c",
                    state: showStops,
                    set: setShowStops,
                  },
                  {
                    id: "signals",
                    label: "AI Signals",
                    color: "#22d3ee",
                    state: showSignals,
                    set: setShowSignals,
                  },
                ] as const
              ).map((item) => (
                <div key={item.id} className="flex items-center gap-1.5">
                  <Checkbox
                    id={`toggle-${item.id}`}
                    checked={item.state}
                    onCheckedChange={(v) => item.set(Boolean(v))}
                    data-ocid={`chart.toggle.${item.id}`}
                    style={
                      item.state
                        ? {
                            borderColor: item.color,
                            background: `${item.color}30`,
                          }
                        : {}
                    }
                  />
                  <Label
                    htmlFor={`toggle-${item.id}`}
                    className="text-xs font-mono cursor-pointer"
                    style={{
                      color: item.state ? item.color : "rgba(148,163,184,0.6)",
                    }}
                  >
                    {item.label}
                  </Label>
                </div>
              ))}
            </div>

            <div className="w-px bg-border/30 hidden sm:block" />

            {/* Confidence tier */}
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono text-muted-foreground uppercase">
                Confidence:
              </span>
              {(["all", "high", "medium", "low"] as ConfidenceTier[]).map(
                (tier) => (
                  <button
                    key={tier}
                    type="button"
                    onClick={() => setConfidenceTier(tier)}
                    className={cn(
                      "px-2 py-0.5 text-[10px] font-mono rounded capitalize border transition-colors",
                      confidenceTier === tier
                        ? "border-cyan-500/50 bg-cyan-500/10 text-cyan-300"
                        : "border-border/30 text-muted-foreground hover:text-foreground",
                    )}
                    data-ocid={`chart.confidence_tier.${tier}`}
                  >
                    {tier === "high"
                      ? ">80%"
                      : tier === "medium"
                        ? "70-80%"
                        : tier === "low"
                          ? "<70%"
                          : "All"}
                  </button>
                ),
              )}
            </div>

            <div className="w-px bg-border/30 hidden sm:block" />

            {/* Outcome filter */}
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono text-muted-foreground uppercase">
                Outcome:
              </span>
              {(["all", "wins", "losses"] as OutcomeFilter[]).map((o) => (
                <button
                  key={o}
                  type="button"
                  onClick={() => setOutcomeFilter(o)}
                  className={cn(
                    "px-2 py-0.5 text-[10px] font-mono rounded capitalize border transition-colors",
                    outcomeFilter === o
                      ? o === "wins"
                        ? "border-green-500/50 bg-green-500/10 text-green-300"
                        : o === "losses"
                          ? "border-red-500/50 bg-red-500/10 text-red-300"
                          : "border-cyan-500/50 bg-cyan-500/10 text-cyan-300"
                      : "border-border/30 text-muted-foreground hover:text-foreground",
                  )}
                  data-ocid={`chart.outcome_filter.${o}`}
                >
                  {o.charAt(0).toUpperCase() + o.slice(1)}
                </button>
              ))}
            </div>

            {/* Legend */}
            <div className="ml-auto flex items-center gap-3">
              <div className="flex gap-3 text-[10px] font-mono text-muted-foreground">
                <span className="flex items-center gap-1">
                  <span className="text-green-400">▲</span> Entry
                </span>
                <span className="flex items-center gap-1">
                  <span className="text-red-400">▼</span> Exit
                </span>
                <span className="flex items-center gap-1">
                  <span className="text-orange-400">—</span> Stop
                </span>
                <span className="flex items-center gap-1">
                  <span className="text-cyan-400">▬</span> AI Signal
                </span>
              </div>
              <Button
                size="sm"
                variant="ghost"
                className="h-6 text-[10px] font-mono text-muted-foreground px-2"
                onClick={() => {
                  refetchCandles();
                  refetchSnapshot();
                  setAutoRefresh((n) => n + 1);
                }}
                data-ocid="chart.refresh_button"
              >
                <RefreshCw className="w-3 h-3 mr-1" />
                Refresh
              </Button>
            </div>
          </div>

          {/* Disclaimer */}
          <div
            className="flex items-center gap-2 px-4 py-2 border-t text-[10px] font-mono text-muted-foreground"
            style={{
              borderColor: "rgba(255,255,255,0.04)",
              background: "rgba(250,204,21,0.03)",
            }}
            data-ocid="chart.disclaimer"
          >
            <Info className="w-3 h-3 text-yellow-500/60 shrink-0" />
            AI signals are probabilistic estimates, not financial advice.
            Cryptocurrency trading involves substantial risk and may result in
            loss of capital.
          </div>
        </div>
      </div>
    </Layout>
  );
}
