import { useTradeSnapshot } from "@/hooks/useQueries";
import { cn } from "@/lib/utils";
import type { Trade, TradeSnapshot } from "@/types";
import { MarketCondition, TradeAction, TradeStatus, TradeTag } from "@/types";
import {
  Activity,
  AlertCircle,
  ArrowDownLeft,
  ArrowUpRight,
  Clock,
  DollarSign,
  Loader2,
  TrendingDown,
  TrendingUp,
  X,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";

// ─── Trade tag config ───────────────────────────────────────────────────────

const TAG_CONFIG: Record<
  TradeTag,
  {
    label: string;
    color: string;
    bg: string;
    sentiment: "good" | "bad" | "neutral";
  }
> = {
  [TradeTag.TextbookWin]: {
    label: "Textbook Win",
    color: "#22c55e",
    bg: "rgba(34,197,94,0.12)",
    sentiment: "good",
  },
  [TradeTag.TightStop]: {
    label: "Tight Stop",
    color: "#22c55e",
    bg: "rgba(34,197,94,0.12)",
    sentiment: "good",
  },
  [TradeTag.GoodDiscipline]: {
    label: "Good Discipline",
    color: "#22c55e",
    bg: "rgba(34,197,94,0.12)",
    sentiment: "good",
  },
  [TradeTag.GoodScaling]: {
    label: "Good Scaling",
    color: "#22c55e",
    bg: "rgba(34,197,94,0.12)",
    sentiment: "good",
  },
  [TradeTag.PrematureExit]: {
    label: "Premature Exit",
    color: "#ef4444",
    bg: "rgba(239,68,68,0.12)",
    sentiment: "bad",
  },
  [TradeTag.OvertradeLoss]: {
    label: "Overtrade Loss",
    color: "#ef4444",
    bg: "rgba(239,68,68,0.12)",
    sentiment: "bad",
  },
  [TradeTag.RegimeMismatch]: {
    label: "Regime Mismatch",
    color: "#f59e0b",
    bg: "rgba(245,158,11,0.12)",
    sentiment: "neutral",
  },
};

// ─── Market condition label map ──────────────────────────────────────────────

const REGIME_COLOR: Record<MarketCondition, string> = {
  [MarketCondition.StrongBullish]: "#22c55e",
  [MarketCondition.Bullish]: "#86efac",
  [MarketCondition.Neutral]: "#94a3b8",
  [MarketCondition.Ranging]: "#facc15",
  [MarketCondition.WeakBearish]: "#f97316",
  [MarketCondition.StrongBearish]: "#ef4444",
  [MarketCondition.HighVolatility]: "#a855f7",
  [MarketCondition.ManipulationRisk]: "#ec4899",
  [MarketCondition.LowLiquidityDanger]: "#f59e0b",
};

const REGIME_LABEL: Record<MarketCondition, string> = {
  [MarketCondition.StrongBullish]: "Strong Bullish",
  [MarketCondition.Bullish]: "Bullish",
  [MarketCondition.Neutral]: "Neutral",
  [MarketCondition.Ranging]: "Ranging",
  [MarketCondition.WeakBearish]: "Weak Bearish",
  [MarketCondition.StrongBearish]: "Strong Bearish",
  [MarketCondition.HighVolatility]: "High Volatility",
  [MarketCondition.ManipulationRisk]: "Manipulation Risk",
  [MarketCondition.LowLiquidityDanger]: "Low Liquidity",
};

// ─── Helpers ─────────────────────────────────────────────────────────────────

function calcDuration(open: bigint, close: bigint): string {
  const ms = Number(close - open) / 1_000_000;
  if (ms < 0 || close === 0n) return "—";
  const secs = Math.floor(ms / 1000);
  if (secs < 60) return `${secs}s`;
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m`;
  return `${Math.floor(mins / 60)}h ${mins % 60}m`;
}

function tradeResult(trade: Trade): { label: string; color: string } {
  if (trade.status === TradeStatus.Open)
    return { label: "OPEN", color: "#22d3ee" };
  if ((trade.pnl ?? 0) > 0) return { label: "WIN", color: "#22c55e" };
  if ((trade.pnl ?? 0) < 0) return { label: "LOSS", color: "#ef4444" };
  return { label: "BREAK EVEN", color: "#94a3b8" };
}

function buildImprovement(snapshot: TradeSnapshot): string {
  const hasPrematureExit = snapshot.tags.includes(TradeTag.PrematureExit);
  const hasOvertrade = snapshot.tags.includes(TradeTag.OvertradeLoss);
  const hasRegimeMismatch = snapshot.tags.includes(TradeTag.RegimeMismatch);
  const isVolatile =
    snapshot.marketRegimeAtEntry === MarketCondition.HighVolatility ||
    snapshot.marketRegimeAtEntry === MarketCondition.ManipulationRisk;

  if (hasPrematureExit)
    return "Allow trades more room — the exit was earlier than optimal. Consider wider TP targets aligned with key resistance.";
  if (hasOvertrade)
    return "Avoid chasing setups in rapid succession. Let market conditions reset before re-entry to reduce overtrading risk.";
  if (hasRegimeMismatch)
    return "This strategy underperforms in the current regime. Wait for regime alignment before deploying this setup.";
  if (isVolatile)
    return "Consider tightening stop loss in high volatility regimes and reducing position size by 30-50%.";
  if (snapshot.confidenceFactors.total < 0.6)
    return "Low confidence setups have poor expectancy. Wait for all 7 factors to align above 60% before entry.";
  return "Good execution overall. Continue reinforcing this setup pattern in similar regime conditions.";
}

// ─── Mini snapshot SVG chart ─────────────────────────────────────────────────

function SnapshotChart({ trade }: { trade: Trade }) {
  const entry = trade.entryPrice;
  const exit =
    trade.exitPrice ??
    entry * (1 + (trade.action === TradeAction.Buy ? 0.01 : -0.01));
  const sl = trade.stopLoss;
  const tp = trade.takeProfit;

  // Build a synthetic 24-point price line between entry and exit with slight noise
  const points: number[] = [];
  const count = 24;
  for (let i = 0; i <= count; i++) {
    const t = i / count;
    const base = entry + (exit - entry) * t;
    const noise =
      (Math.sin(i * 2.5) * 0.003 + Math.cos(i * 1.7) * 0.002) * entry;
    points.push(base + noise);
  }

  const allPrices = [...points, sl, ...(tp != null ? [tp] : [])];
  const minP = Math.min(...allPrices) * 0.9985;
  const maxP = Math.max(...allPrices) * 1.0015;
  const range = maxP - minP || 1;

  const W = 480;
  const H = 96;
  const pad = { l: 8, r: 8, t: 8, b: 8 };
  const iw = W - pad.l - pad.r;
  const ih = H - pad.t - pad.b;

  const toX = (i: number) => pad.l + (i / count) * iw;
  const toY = (p: number) => pad.t + ih - ((p - minP) / range) * ih;

  const pathD = points
    .map(
      (p, i) =>
        `${i === 0 ? "M" : "L"} ${toX(i).toFixed(1)} ${toY(p).toFixed(1)}`,
    )
    .join(" ");

  const entryX = toX(0);
  const exitX = toX(count);
  const entryY = toY(entry);
  const exitY = toY(exit);
  const slY = toY(sl);
  const tpY = tp != null ? toY(tp) : null;
  const isWin = exit > entry;

  return (
    <div
      className="w-full rounded-lg overflow-hidden relative"
      style={{
        background: "rgba(0,0,0,0.3)",
        border: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      <svg
        viewBox={`0 0 ${W} ${H}`}
        className="w-full"
        style={{ height: 96 }}
        aria-label="Trade price chart"
        role="img"
      >
        {/* Stop loss line */}
        <line
          x1={pad.l}
          y1={slY}
          x2={W - pad.r}
          y2={slY}
          stroke="rgba(251,146,60,0.5)"
          strokeWidth={1}
          strokeDasharray="3,3"
        />
        {/* Take profit line */}
        {tpY != null && (
          <line
            x1={pad.l}
            y1={tpY}
            x2={W - pad.r}
            y2={tpY}
            stroke="rgba(34,197,94,0.5)"
            strokeWidth={1}
            strokeDasharray="3,3"
          />
        )}
        {/* Price line */}
        <path
          d={pathD}
          fill="none"
          stroke={isWin ? "#22c55e" : "#ef4444"}
          strokeWidth={1.5}
          opacity={0.9}
        />
        {/* Entry triangle (pointing up, green) */}
        <polygon
          points={`${entryX},${entryY - 10} ${entryX - 5},${entryY} ${entryX + 5},${entryY}`}
          fill="#22c55e"
        />
        {/* Exit triangle (pointing down, red) */}
        <polygon
          points={`${exitX},${exitY + 10} ${exitX - 5},${exitY} ${exitX + 5},${exitY}`}
          fill="#ef4444"
        />
        {/* Labels */}
        <text
          x={pad.l + 2}
          y={slY - 3}
          fill="rgba(251,146,60,0.8)"
          fontSize={7}
          fontFamily="monospace"
        >
          SL
        </text>
        {tpY != null && (
          <text
            x={pad.l + 2}
            y={tpY + 9}
            fill="rgba(34,197,94,0.8)"
            fontSize={7}
            fontFamily="monospace"
          >
            TP
          </text>
        )}
      </svg>
      <div className="flex items-center justify-between px-2 pb-1 text-xs font-mono text-muted-foreground">
        <span>Entry ${entry.toFixed(2)}</span>
        <span>SL ${sl.toFixed(2)}</span>
        {tp != null && <span>TP ${tp.toFixed(2)}</span>}
        <span style={{ color: isWin ? "#22c55e" : "#ef4444" }}>
          Exit ${exit.toFixed(2)}
        </span>
      </div>
    </div>
  );
}

// ─── Confidence bar row ───────────────────────────────────────────────────────

function ConfBar({ label, value }: { label: string; value: number }) {
  const pct = Math.round(Math.min(100, Math.max(0, value * 100)));
  const color = pct >= 70 ? "#22c55e" : pct >= 45 ? "#eab308" : "#ef4444";
  return (
    <div className="mb-2">
      <div className="flex justify-between items-center mb-0.5">
        <span className="text-xs font-mono text-muted-foreground">{label}</span>
        <span className="text-xs font-mono font-semibold" style={{ color }}>
          {pct}%
        </span>
      </div>
      <div
        className="h-1.5 rounded-full"
        style={{ background: "rgba(255,255,255,0.07)" }}
      >
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${pct}%`, background: color }}
        />
      </div>
    </div>
  );
}

// ─── Snapshot body ────────────────────────────────────────────────────────────

function SnapshotBody({
  trade,
  snapshot,
}: { trade: Trade; snapshot: TradeSnapshot }) {
  const { confidenceFactors: cf } = snapshot;
  const improvement = buildImprovement(snapshot);
  const regimeColor = REGIME_COLOR[snapshot.marketRegimeAtEntry] ?? "#94a3b8";
  const regimeLabel =
    REGIME_LABEL[snapshot.marketRegimeAtEntry] ??
    String(snapshot.marketRegimeAtEntry);

  const totalImpact =
    snapshot.simulatedSlippage +
    snapshot.simulatedSpread +
    snapshot.simulatedFees;

  return (
    <div className="space-y-4">
      {/* Snapshot chart */}
      <div>
        <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-2">
          Price Replay
        </div>
        <SnapshotChart trade={trade} />
      </div>

      {/* Confidence breakdown */}
      <div
        className="rounded-xl p-4"
        style={{
          background: "rgba(255,255,255,0.03)",
          border: "1px solid rgba(255,255,255,0.07)",
        }}
      >
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
            7-Factor Confidence
          </span>
          <span
            className="text-sm font-mono font-bold"
            style={{
              color:
                cf.total >= 0.7
                  ? "#22c55e"
                  : cf.total >= 0.5
                    ? "#eab308"
                    : "#ef4444",
            }}
          >
            {Math.round(cf.total * 100)}%
          </span>
        </div>
        <ConfBar label="Trend Alignment" value={cf.trendAlignment} />
        <ConfBar label="Momentum" value={cf.momentum} />
        <ConfBar label="Volatility Quality" value={cf.volatilityQuality} />
        <ConfBar label="Liquidity" value={cf.liquidity} />
        <ConfBar
          label="Historical Performance"
          value={cf.historicalSetupPerformance}
        />
        <ConfBar label="Market Structure" value={cf.marketStructure} />
        <ConfBar label="Regime Confidence" value={cf.regimeConfidence} />
      </div>

      {/* AI Reasoning */}
      <div
        className="rounded-xl p-4"
        style={{
          background: "rgba(6,182,212,0.04)",
          border: "1px solid rgba(6,182,212,0.12)",
        }}
      >
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
            AI Reasoning
          </span>
          <span
            className="text-xs font-mono font-semibold px-2 py-0.5 rounded-full"
            style={{
              background: `${regimeColor}18`,
              color: regimeColor,
              border: `1px solid ${regimeColor}40`,
            }}
          >
            {regimeLabel}
          </span>
        </div>
        <p className="text-sm font-mono leading-relaxed text-foreground opacity-90">
          {snapshot.aiReasoningText}
        </p>
      </div>

      {/* Trade costs */}
      <div
        className="rounded-xl p-4"
        style={{
          background: "rgba(255,255,255,0.03)",
          border: "1px solid rgba(255,255,255,0.07)",
        }}
      >
        <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-3">
          Simulated Trade Costs
        </div>
        <table className="w-full">
          <tbody>
            {[
              { label: "Slippage", value: snapshot.simulatedSlippage },
              { label: "Spread", value: snapshot.simulatedSpread },
              { label: "Fees", value: snapshot.simulatedFees },
            ].map(({ label, value }) => (
              <tr key={label}>
                <td className="py-1 text-xs font-mono text-muted-foreground">
                  {label}
                </td>
                <td
                  className="py-1 text-xs font-mono text-right"
                  style={{ color: "#f87171" }}
                >
                  -{value.toFixed(3)}%
                </td>
              </tr>
            ))}
            <tr style={{ borderTop: "1px solid rgba(255,255,255,0.07)" }}>
              <td className="pt-2 text-xs font-mono font-semibold">
                Total Impact
              </td>
              <td
                className="pt-2 text-xs font-mono font-bold text-right"
                style={{ color: "#f87171" }}
              >
                -{totalImpact.toFixed(3)}%
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Trade tags */}
      {snapshot.tags.length > 0 && (
        <div>
          <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-2">
            Trade Tags
          </div>
          <div className="flex flex-wrap gap-2">
            {snapshot.tags.map((tag) => {
              const cfg = TAG_CONFIG[tag];
              return (
                <span
                  key={tag}
                  className="text-xs font-mono font-semibold px-2.5 py-1 rounded-full"
                  style={{
                    background: cfg.bg,
                    color: cfg.color,
                    border: `1px solid ${cfg.color}40`,
                  }}
                >
                  {cfg.label}
                </span>
              );
            })}
          </div>
        </div>
      )}

      {/* Suggested improvement */}
      <div
        className="rounded-xl p-4"
        style={{
          background: "rgba(234,179,8,0.04)",
          border: "1px solid rgba(234,179,8,0.15)",
        }}
      >
        <div className="flex items-start gap-2">
          <AlertCircle
            className="w-4 h-4 shrink-0 mt-0.5"
            style={{ color: "#facc15" }}
          />
          <div>
            <div
              className="text-xs font-mono font-semibold mb-1"
              style={{ color: "#facc15" }}
            >
              Suggested Improvement
            </div>
            <p className="text-xs font-mono leading-relaxed text-muted-foreground">
              {improvement}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Modal ────────────────────────────────────────────────────────────────────

interface Props {
  trade: Trade | null;
  onClose: () => void;
}

export function TradeReplayModal({ trade, onClose }: Props) {
  const tradeId = trade?.id ?? "";
  const { data: snapshot, isLoading, isError } = useTradeSnapshot(tradeId);

  if (!trade) return null;

  const res = tradeResult(trade);
  const pnl = trade.pnl ?? 0;
  const pnlPct = trade.pnlPercent ?? 0;
  const duration = calcDuration(trade.openTime, trade.closeTime);
  const isLong = trade.action === TradeAction.Buy;

  return (
    <AnimatePresence>
      <motion.div
        key="replay-backdrop"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4"
        style={{ background: "rgba(0,0,0,0.75)", backdropFilter: "blur(8px)" }}
        onClick={(e) => e.target === e.currentTarget && onClose()}
        data-ocid="replay.dialog"
      >
        <motion.div
          key="replay-panel"
          initial={{ opacity: 0, scale: 0.97, y: 16 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.97, y: 16 }}
          transition={{ duration: 0.2 }}
          className="relative w-full max-w-2xl max-h-[90vh] flex flex-col rounded-2xl overflow-hidden"
          style={{
            background: "rgba(10,15,30,0.97)",
            border: "1px solid rgba(6,182,212,0.2)",
            boxShadow:
              "0 0 60px rgba(6,182,212,0.08), 0 25px 60px rgba(0,0,0,0.7)",
          }}
        >
          {/* Header */}
          <div
            className="shrink-0 px-6 py-4 flex items-start justify-between gap-4"
            style={{ borderBottom: "1px solid rgba(6,182,212,0.12)" }}
          >
            <div className="flex items-center gap-4 min-w-0">
              <div
                className="flex items-center justify-center w-9 h-9 rounded-xl shrink-0"
                style={{
                  background: isLong
                    ? "rgba(34,197,94,0.12)"
                    : "rgba(239,68,68,0.12)",
                  border: `1px solid ${isLong ? "rgba(34,197,94,0.3)" : "rgba(239,68,68,0.3)"}`,
                }}
              >
                {isLong ? (
                  <ArrowUpRight
                    className="w-5 h-5"
                    style={{ color: "#22c55e" }}
                  />
                ) : (
                  <TrendingDown
                    className="w-5 h-5"
                    style={{ color: "#ef4444" }}
                  />
                )}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-lg font-mono font-bold text-cyan-300">
                    {trade.symbol}
                  </span>
                  <span
                    className="text-xs font-mono font-bold px-2 py-0.5 rounded"
                    style={{
                      background: isLong
                        ? "rgba(34,197,94,0.15)"
                        : "rgba(239,68,68,0.15)",
                      color: isLong ? "#22c55e" : "#ef4444",
                    }}
                  >
                    {isLong ? "LONG" : "SHORT"}
                  </span>
                  <span
                    className="text-xs font-mono font-bold px-2 py-0.5 rounded"
                    style={{
                      background: `${res.color}18`,
                      color: res.color,
                      border: `1px solid ${res.color}40`,
                    }}
                  >
                    {res.label}
                  </span>
                </div>
                <div className="flex items-center gap-4 mt-1 flex-wrap">
                  <span className="text-xs font-mono text-muted-foreground">
                    Entry ${trade.entryPrice.toFixed(2)}
                  </span>
                  {trade.exitPrice != null && (
                    <span className="text-xs font-mono text-muted-foreground">
                      Exit ${trade.exitPrice.toFixed(2)}
                    </span>
                  )}
                  <span className="text-xs font-mono flex items-center gap-1 text-muted-foreground">
                    <Clock className="w-3 h-3" />
                    {duration}
                  </span>
                </div>
              </div>
            </div>
            <div className="shrink-0 text-right">
              <div
                className="text-lg font-mono font-bold"
                style={{ color: pnl >= 0 ? "#22c55e" : "#ef4444" }}
              >
                {pnl >= 0 ? "+" : ""}${pnl.toFixed(2)}
              </div>
              <div
                className="text-xs font-mono"
                style={{ color: pnlPct >= 0 ? "#22c55e" : "#ef4444" }}
              >
                {pnlPct >= 0 ? "+" : ""}
                {pnlPct.toFixed(2)}%
              </div>
            </div>
            <button
              type="button"
              className="shrink-0 flex items-center justify-center w-8 h-8 rounded-lg transition-colors hover:bg-white/10"
              style={{ color: "#94a3b8" }}
              onClick={onClose}
              aria-label="Close replay"
              data-ocid="replay.close_button"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto p-6">
            {isLoading ? (
              <div
                className="flex flex-col items-center justify-center py-20 gap-4"
                data-ocid="replay.loading_state"
              >
                <Loader2
                  className="w-8 h-8 animate-spin"
                  style={{ color: "#06b6d4" }}
                />
                <p className="text-sm font-mono text-muted-foreground">
                  Loading trade snapshot…
                </p>
              </div>
            ) : isError || !snapshot ? (
              <div
                className="flex flex-col items-center justify-center py-20 gap-4 text-center"
                data-ocid="replay.error_state"
              >
                <Activity className="w-8 h-8 text-muted-foreground" />
                <div>
                  <p className="font-mono font-semibold text-muted-foreground">
                    Snapshot Not Available
                  </p>
                  <p className="text-xs font-mono text-muted-foreground mt-1">
                    Snapshot data is not available for this trade. It may have
                    been created before snapshot tracking was enabled.
                  </p>
                </div>
              </div>
            ) : (
              <SnapshotBody trade={trade} snapshot={snapshot} />
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// ─── Tag badges for table row ─────────────────────────────────────────────────

export function TradeTagBadges({ tags }: { tags: TradeTag[] }) {
  const shown = tags.slice(0, 2);
  return (
    <div className="flex items-center gap-1 flex-wrap">
      {shown.map((tag) => {
        const cfg = TAG_CONFIG[tag];
        return (
          <span
            key={tag}
            className="text-xs font-mono px-1.5 py-0.5 rounded whitespace-nowrap"
            style={{ background: cfg.bg, color: cfg.color }}
          >
            {cfg.label}
          </span>
        );
      })}
    </div>
  );
}
