import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { AIDecisionLog } from "@/types";
import {
  ExecutionStatus,
  MarketCondition,
  StrategyMode,
  TradeAction,
} from "@/types";
import { Brain } from "lucide-react";

interface Props {
  log: AIDecisionLog | null;
}

function indicatorBar(value: number, min = 0, max = 100) {
  const pct = Math.min(100, Math.max(0, ((value - min) / (max - min)) * 100));
  const hue = pct < 30 ? "#ef4444" : pct < 60 ? "#eab308" : "#22c55e";
  return { pct, hue };
}

const CONDITION_LABELS: Record<
  MarketCondition,
  { label: string; color: string }
> = {
  [MarketCondition.StrongBullish]: {
    label: "Strong Bullish",
    color: "#22c55e",
  },
  [MarketCondition.Bullish]: { label: "Bullish", color: "#86efac" },
  [MarketCondition.Neutral]: { label: "Neutral", color: "#94a3b8" },
  [MarketCondition.Ranging]: { label: "Ranging", color: "#facc15" },
  [MarketCondition.WeakBearish]: { label: "Weak Bearish", color: "#f97316" },
  [MarketCondition.StrongBearish]: {
    label: "Strong Bearish",
    color: "#ef4444",
  },
  [MarketCondition.HighVolatility]: {
    label: "High Volatility",
    color: "#a855f7",
  },
  [MarketCondition.ManipulationRisk]: {
    label: "Manipulation Risk",
    color: "#ec4899",
  },
  [MarketCondition.LowLiquidityDanger]: {
    label: "Low Liquidity",
    color: "#f59e0b",
  },
};

const STRATEGY_LABELS: Record<string, string> = {
  [StrategyMode.TrendFollowing]: "Trend Following",
  [StrategyMode.MeanReversion]: "Mean Reversion",
  [StrategyMode.Scalping]: "Scalping",
  [StrategyMode.Defensive]: "Defensive",
  [StrategyMode.Observation]: "Observation",
};

interface IndicatorRowProps {
  label: string;
  value: number;
  min?: number;
  max?: number;
  unit?: string;
  raw?: boolean;
}

function IndicatorRow({
  label,
  value,
  min = 0,
  max = 100,
  unit = "",
  raw = false,
}: IndicatorRowProps) {
  const { pct, hue } = indicatorBar(value, min, max);
  return (
    <div className="mb-2">
      <div className="flex justify-between items-center mb-0.5">
        <span className="text-xs font-mono text-muted-foreground uppercase tracking-wider">
          {label}
        </span>
        <span
          className="text-xs font-mono font-semibold"
          style={{ color: hue }}
        >
          {raw ? value.toFixed(4) : value.toFixed(2)}
          {unit}
        </span>
      </div>
      <div
        className="h-1.5 w-full rounded-full"
        style={{ background: "rgba(255,255,255,0.08)" }}
      >
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${pct}%`, background: hue }}
        />
      </div>
    </div>
  );
}

export function DecisionReasoningPanel({ log }: Props) {
  if (!log) {
    return (
      <div
        className="glass-panel rounded-xl h-full flex flex-col items-center justify-center gap-4 p-8 text-center"
        data-ocid="reasoning.empty_state"
      >
        <Brain className="w-12 h-12 text-cyan-500 opacity-40" />
        <div>
          <p className="font-mono font-semibold text-muted-foreground">
            Select a Decision
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Click any decision card to view full AI reasoning
          </p>
        </div>
      </div>
    );
  }

  const { decision, skipReason, executionStatus } = log;
  const cond = CONDITION_LABELS[decision.marketCondition] ?? {
    label: decision.marketCondition,
    color: "#94a3b8",
  };
  const confPct = Math.round(decision.confidence * 100);
  const confColor =
    confPct >= 70 ? "#22c55e" : confPct >= 50 ? "#eab308" : "#ef4444";

  return (
    <ScrollArea className="h-full">
      <div
        className="glass-panel rounded-xl p-5 space-y-5"
        data-ocid="reasoning.panel"
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-mono font-bold text-cyan-400">
                {decision.symbol}
              </span>
              <ActionBadge action={decision.action} />
            </div>
            <p className="text-xs text-muted-foreground font-mono mt-1">
              {new Date(
                Number(decision.timestamp) / 1_000_000,
              ).toLocaleString()}
            </p>
          </div>
          <div className="text-right">
            <div
              className="text-2xl font-mono font-bold"
              style={{ color: confColor }}
            >
              {confPct}%
            </div>
            <div className="text-xs text-muted-foreground">Confidence</div>
          </div>
        </div>

        {/* Confidence bar */}
        <div>
          <div className="flex justify-between text-xs font-mono mb-1">
            <span className="text-muted-foreground">Confidence Score</span>
            <span style={{ color: confColor }}>{confPct}%</span>
          </div>
          <div
            className="h-2 rounded-full"
            style={{ background: "rgba(255,255,255,0.08)" }}
          >
            <div
              className="h-full rounded-full transition-all duration-700"
              style={{
                width: `${confPct}%`,
                background:
                  "linear-gradient(90deg, #ef4444 0%, #eab308 50%, #22c55e 100%)",
                clipPath: `inset(0 ${100 - confPct}% 0 0 round 9999px)`,
              }}
            />
          </div>
        </div>

        {/* Market condition + strategy */}
        <div className="grid grid-cols-2 gap-3">
          <div
            className="rounded-lg p-3"
            style={{ background: "rgba(255,255,255,0.04)" }}
          >
            <div className="text-xs text-muted-foreground mb-1 font-mono uppercase">
              Market Condition
            </div>
            <span
              className="text-sm font-semibold font-mono"
              style={{ color: cond.color }}
            >
              {cond.label}
            </span>
          </div>
          <div
            className="rounded-lg p-3"
            style={{ background: "rgba(255,255,255,0.04)" }}
          >
            <div className="text-xs text-muted-foreground mb-1 font-mono uppercase">
              Strategy Mode
            </div>
            <span className="text-sm font-semibold font-mono text-purple-400">
              {STRATEGY_LABELS[decision.strategyMode] ?? decision.strategyMode}
            </span>
          </div>
        </div>

        {/* Trade levels */}
        {decision.action !== TradeAction.Skip &&
          decision.action !== TradeAction.Hold && (
            <div className="grid grid-cols-3 gap-2">
              <div
                className="rounded-lg p-3 text-center"
                style={{ background: "rgba(6,182,212,0.08)" }}
              >
                <div className="text-xs text-muted-foreground mb-1 font-mono">
                  Entry
                </div>
                <div className="font-mono font-bold text-cyan-400 text-sm">
                  ${decision.entryPrice.toFixed(2)}
                </div>
              </div>
              <div
                className="rounded-lg p-3 text-center"
                style={{ background: "rgba(239,68,68,0.08)" }}
              >
                <div className="text-xs text-muted-foreground mb-1 font-mono">
                  Stop Loss
                </div>
                <div className="font-mono font-bold text-red-400 text-sm">
                  ${decision.stopLoss.toFixed(2)}
                </div>
              </div>
              {decision.targetPrice != null && (
                <div
                  className="rounded-lg p-3 text-center"
                  style={{ background: "rgba(34,197,94,0.08)" }}
                >
                  <div className="text-xs text-muted-foreground mb-1 font-mono">
                    Take Profit
                  </div>
                  <div className="font-mono font-bold text-green-400 text-sm">
                    ${decision.targetPrice.toFixed(2)}
                  </div>
                </div>
              )}
            </div>
          )}

        {/* Risk/Reward */}
        {decision.riskReward > 0 && (
          <div
            className="flex items-center gap-3 rounded-lg p-3"
            style={{ background: "rgba(255,255,255,0.04)" }}
          >
            <div className="flex-1">
              <div className="text-xs text-muted-foreground font-mono uppercase">
                Risk / Reward
              </div>
              <div className="text-lg font-mono font-bold text-yellow-400">
                1 : {decision.riskReward.toFixed(2)}
              </div>
            </div>
            <div className="flex-1">
              <div className="text-xs text-muted-foreground font-mono uppercase">
                Execution
              </div>
              <ExecutionBadge status={executionStatus} />
            </div>
          </div>
        )}

        {/* Reasoning */}
        <div>
          <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-2">
            AI Reasoning
          </div>
          <div
            className="rounded-lg p-3 text-sm leading-relaxed font-mono"
            style={{
              background: "rgba(6,182,212,0.05)",
              borderLeft: "2px solid rgba(6,182,212,0.4)",
            }}
          >
            {decision.reasoning}
          </div>
        </div>

        {/* Skip reason */}
        {skipReason && (
          <div>
            <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-2">
              Skip Reason
            </div>
            <div
              className="rounded-lg p-3 text-sm font-mono"
              style={{
                background: "rgba(239,68,68,0.05)",
                borderLeft: "2px solid rgba(239,68,68,0.4)",
              }}
            >
              {skipReason}
            </div>
          </div>
        )}

        {/* Technical Indicators */}
        <div>
          <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-3">
            Technical Indicators
          </div>
          <IndicatorRow label="RSI" value={decision.indicators.rsi} />
          <IndicatorRow
            label="Momentum"
            value={decision.indicators.momentum}
            min={-100}
            max={100}
          />
          <IndicatorRow
            label="Trend Strength"
            value={decision.indicators.trendStrength}
          />
          <IndicatorRow
            label="MACD"
            value={decision.indicators.macd}
            min={-10}
            max={10}
            raw
          />
          <IndicatorRow
            label="MACD Signal"
            value={decision.indicators.macdSignal}
            min={-10}
            max={10}
            raw
          />
          <IndicatorRow
            label="ATR"
            value={decision.indicators.atr}
            min={0}
            max={5000}
            raw
          />
          <div
            className="mt-3 pt-3"
            style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}
          >
            <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-2">
              Price Levels
            </div>
            <div className="grid grid-cols-2 gap-x-4">
              <div className="flex justify-between py-1">
                <span className="text-xs font-mono text-muted-foreground">
                  EMA20
                </span>
                <span className="text-xs font-mono">
                  ${decision.indicators.ema20.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-xs font-mono text-muted-foreground">
                  EMA50
                </span>
                <span className="text-xs font-mono">
                  ${decision.indicators.ema50.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-xs font-mono text-muted-foreground">
                  BB Upper
                </span>
                <span className="text-xs font-mono text-red-400">
                  ${decision.indicators.bollingerUpper.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-xs font-mono text-muted-foreground">
                  BB Mid
                </span>
                <span className="text-xs font-mono">
                  ${decision.indicators.bollingerMid.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-xs font-mono text-muted-foreground">
                  BB Lower
                </span>
                <span className="text-xs font-mono text-green-400">
                  ${decision.indicators.bollingerLower.toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </ScrollArea>
  );
}

export function ActionBadge({ action }: { action: TradeAction }) {
  const configs: Record<
    TradeAction,
    { label: string; style: React.CSSProperties }
  > = {
    [TradeAction.Buy]: {
      label: "BUY",
      style: {
        background: "rgba(6,182,212,0.15)",
        color: "#22d3ee",
        border: "1px solid rgba(6,182,212,0.4)",
      },
    },
    [TradeAction.Sell]: {
      label: "SELL",
      style: {
        background: "rgba(239,68,68,0.15)",
        color: "#f87171",
        border: "1px solid rgba(239,68,68,0.4)",
      },
    },
    [TradeAction.Hold]: {
      label: "HOLD",
      style: {
        background: "rgba(234,179,8,0.15)",
        color: "#facc15",
        border: "1px solid rgba(234,179,8,0.4)",
      },
    },
    [TradeAction.Skip]: {
      label: "SKIP",
      style: {
        background: "rgba(148,163,184,0.1)",
        color: "#94a3b8",
        border: "1px solid rgba(148,163,184,0.3)",
      },
    },
  };
  const cfg = configs[action] ?? configs[TradeAction.Skip];
  return (
    <span
      className="text-xs font-mono font-bold px-2 py-0.5 rounded"
      style={cfg.style}
    >
      {cfg.label}
    </span>
  );
}

export function ExecutionBadge({ status }: { status: ExecutionStatus }) {
  const configs: Record<
    ExecutionStatus,
    { label: string; style: React.CSSProperties }
  > = {
    [ExecutionStatus.Executed]: {
      label: "Executed",
      style: { color: "#22c55e" },
    },
    [ExecutionStatus.Skipped]: {
      label: "Skipped",
      style: { color: "#94a3b8" },
    },
    [ExecutionStatus.Pending]: {
      label: "Pending",
      style: { color: "#facc15" },
    },
    [ExecutionStatus.Failed]: { label: "Failed", style: { color: "#ef4444" } },
  };
  const cfg = configs[status] ?? {
    label: String(status),
    style: { color: "#94a3b8" },
  };
  return (
    <span className="text-sm font-mono font-semibold" style={cfg.style}>
      {cfg.label}
    </span>
  );
}
