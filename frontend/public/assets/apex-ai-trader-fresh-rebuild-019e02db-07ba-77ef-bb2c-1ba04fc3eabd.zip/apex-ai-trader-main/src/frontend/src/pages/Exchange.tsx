import { Layout } from "@/components/Layout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useExchangeBalances,
  useExchangeConnections,
  useExchangeOrderHistory,
  useMarketSnapshot,
  useRemoveExchangeConnection,
  useSaveExchangeConnection,
  useTestExchangeConnection,
} from "@/hooks/useQueries";
import { cn } from "@/lib/utils";
import type { ExchangeStatus } from "@/types";
import {
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Clock,
  Globe,
  Loader2,
  Lock,
  Plug,
  RefreshCw,
  Shield,
  ShieldAlert,
  Trash2,
  TrendingUp,
  XCircle,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

// ─── Constants ───────────────────────────────────────────────────────────────

const SUPPORTED_EXCHANGES = [
  {
    id: "binance",
    label: "Binance",
    ticker: "BNB",
    color: "#f0b90b",
    desc: "World's largest crypto exchange by volume",
  },
  {
    id: "coinbase",
    label: "Coinbase Advanced",
    ticker: "COIN",
    color: "#0052ff",
    desc: "Institutional-grade US regulated exchange",
  },
  {
    id: "kraken",
    label: "Kraken",
    ticker: "KRK",
    color: "#8257e6",
    desc: "High-security European exchange since 2011",
  },
  {
    id: "bybit",
    label: "Bybit",
    ticker: "BYB",
    color: "#f7a600",
    desc: "Derivatives-focused exchange with deep liquidity",
  },
  {
    id: "okx",
    label: "OKX",
    ticker: "OKX",
    color: "#00d4ff",
    desc: "Unified trading platform with advanced order types",
  },
];

const PHASES = [
  {
    phase: 1,
    label: "Read-Only",
    desc: "View balances, prices, order history. No execution.",
    status: "active" as const,
    color: "cyan",
  },
  {
    phase: 2,
    label: "Manual Approval",
    desc: "AI suggests trades — user confirms before execution.",
    status: "coming" as const,
    color: "purple",
  },
  {
    phase: 3,
    label: "Full Autonomy",
    desc: "Fully autonomous trading after AI validates thresholds.",
    status: "planned" as const,
    color: "green",
  },
];

// ─── Helpers ─────────────────────────────────────────────────────────────────

function formatTimestamp(ts: bigint): string {
  if (!ts || ts === 0n) return "Never";
  const ms = Number(ts / 1_000_000n);
  const d = new Date(ms);
  return d.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

// ─── Sub-components ──────────────────────────────────────────────────────────

function ExchangeBalances({ exchangeId }: { exchangeId: string }) {
  const { data: balances, isLoading } = useExchangeBalances(exchangeId);
  if (isLoading) return <Skeleton className="h-24 w-full" />;
  if (!balances || balances.length === 0)
    return (
      <div
        className="text-center py-6 text-xs text-muted-foreground font-mono"
        data-ocid={`exchange.balances.${exchangeId}.empty_state`}
      >
        No balances found. Ensure read-only API keys have portfolio access.
      </div>
    );
  return (
    <div className="space-y-0.5">
      <div className="grid grid-cols-3 text-[9px] font-mono text-muted-foreground uppercase tracking-widest px-2 pb-1">
        <span>Asset</span>
        <span className="text-right">Free</span>
        <span className="text-right">Locked</span>
      </div>
      {balances.map((b) => (
        <div
          key={b.asset}
          className="grid grid-cols-3 text-xs font-mono px-2 py-1.5 rounded"
          style={{ background: "rgba(255,255,255,0.025)" }}
        >
          <span className="text-cyan-400 font-semibold">{b.asset}</span>
          <span className="text-right">{b.free.toFixed(6)}</span>
          {b.locked > 0 ? (
            <span className="text-right text-yellow-400">
              {b.locked.toFixed(6)}
            </span>
          ) : (
            <span className="text-right text-muted-foreground">—</span>
          )}
        </div>
      ))}
    </div>
  );
}

function ExchangeOrderHistory({ exchangeId }: { exchangeId: string }) {
  const { data: orders, isLoading } = useExchangeOrderHistory(exchangeId);
  if (isLoading) return <Skeleton className="h-24 w-full" />;
  if (!orders || orders.length === 0)
    return (
      <div
        className="text-center py-6 text-xs text-muted-foreground font-mono"
        data-ocid={`exchange.orders.${exchangeId}.empty_state`}
      >
        No order history found on this exchange account.
      </div>
    );
  return (
    <div className="space-y-0.5">
      <div className="grid grid-cols-5 text-[9px] font-mono text-muted-foreground uppercase tracking-widest px-2 pb-1">
        <span>Symbol</span>
        <span>Side</span>
        <span className="text-right">Price</span>
        <span className="text-right">Qty</span>
        <span className="text-right">Status</span>
      </div>
      {orders.slice(0, 50).map((o) => (
        <div
          key={o.orderId}
          className="grid grid-cols-5 items-center text-[10px] font-mono px-2 py-1.5 rounded"
          style={{ background: "rgba(255,255,255,0.02)" }}
        >
          <span className="font-semibold">{o.symbol}</span>
          <span
            className={o.side === "buy" ? "text-green-400" : "text-red-400"}
          >
            {o.side.toUpperCase()}
          </span>
          <span className="text-right">${o.price.toFixed(2)}</span>
          <span className="text-right">{o.qty.toFixed(4)}</span>
          <div className="flex justify-end">
            <Badge
              variant="outline"
              className="text-[8px] px-1 py-0 border-border/30"
            >
              {o.status}
            </Badge>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Exchange Card ────────────────────────────────────────────────────────────

function ExchangeCard({
  info,
  status,
}: {
  info: (typeof SUPPORTED_EXCHANGES)[0];
  status?: ExchangeStatus;
}) {
  const [expanded, setExpanded] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [apiKey, setApiKey] = useState("");
  const [apiSecret, setApiSecret] = useState("");
  const [activeTab, setActiveTab] = useState<"balances" | "orders">("balances");

  const save = useSaveExchangeConnection();
  const remove = useRemoveExchangeConnection();
  const test = useTestExchangeConnection();

  const isConnected = status?.connected ?? false;
  const lastTested = status?.lastTestTimestamp ?? 0n;
  const phase = Number(status?.phase ?? 1n);

  const handleSave = async () => {
    if (!apiKey || !apiSecret) {
      toast.error("Both API key and secret are required");
      return;
    }
    try {
      await save.mutateAsync({ exchangeId: info.id, apiKey, apiSecret });
      toast.success(`${info.label} connected in read-only mode`);
      setShowForm(false);
      setApiKey("");
      setApiSecret("");
    } catch {
      toast.error("Failed to save connection");
    }
  };

  const handleTest = async () => {
    try {
      const ok = await test.mutateAsync(info.id);
      if (ok) {
        toast.success(`${info.label} — connection test passed ✓`);
      } else {
        toast.error(`${info.label} — connection test failed`);
      }
    } catch {
      toast.error("Connection test failed");
    }
  };

  const handleRemove = async () => {
    try {
      await remove.mutateAsync(info.id);
      toast.success(`${info.label} disconnected`);
      setExpanded(false);
    } catch {
      toast.error("Failed to remove connection");
    }
  };

  return (
    <Card
      className="border-0 transition-all duration-200"
      style={{
        background: isConnected
          ? "rgba(74,222,128,0.03)"
          : "rgba(10,14,26,0.5)",
        border: isConnected
          ? "1px solid rgba(74,222,128,0.15)"
          : "1px solid rgba(255,255,255,0.07)",
      }}
      data-ocid={`exchange.card.${info.id}`}
    >
      <CardContent className="pt-4 pb-4">
        {/* Header Row */}
        <div className="flex items-start gap-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center text-[10px] font-mono font-bold shrink-0"
            style={{
              background: `${info.color}18`,
              border: `1px solid ${info.color}40`,
              color: info.color,
            }}
          >
            {info.ticker}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-mono font-bold text-sm">{info.label}</span>
              {isConnected ? (
                <>
                  <Badge
                    className="text-[9px] px-1.5 py-0 border-0"
                    style={{
                      background: "rgba(74,222,128,0.15)",
                      color: "#4ade80",
                    }}
                  >
                    <CheckCircle2 className="w-2.5 h-2.5 mr-1" />
                    Connected
                  </Badge>
                  <Badge
                    variant="outline"
                    className="text-[9px] px-1.5 py-0 border-yellow-500/30 text-yellow-400"
                  >
                    Phase {phase}: Read-only
                  </Badge>
                </>
              ) : (
                <Badge
                  className="text-[9px] px-1.5 py-0 border-0"
                  style={{
                    background: "rgba(100,100,120,0.2)",
                    color: "#9ca3af",
                  }}
                >
                  <XCircle className="w-2.5 h-2.5 mr-1" />
                  Not connected
                </Badge>
              )}
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5 font-mono">
              {info.desc}
            </p>
            {isConnected && lastTested > 0n && (
              <div className="flex items-center gap-1 mt-1 text-[9px] text-muted-foreground font-mono">
                <Clock className="w-2.5 h-2.5" />
                Last tested: {formatTimestamp(lastTested)}
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 mt-3 flex-wrap">
          {isConnected ? (
            <>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-7 text-xs gap-1"
                onClick={handleTest}
                disabled={test.isPending}
                data-ocid={`exchange.test_button.${info.id}`}
              >
                {test.isPending ? (
                  <Loader2 className="w-3 h-3 animate-spin" />
                ) : (
                  <RefreshCw className="w-3 h-3" />
                )}
                Test
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-7 text-xs gap-1"
                onClick={() => setExpanded((v) => !v)}
                data-ocid={`exchange.expand_button.${info.id}`}
              >
                {expanded ? (
                  <ChevronUp className="w-3 h-3" />
                ) : (
                  <ChevronDown className="w-3 h-3" />
                )}
                {expanded ? "Hide" : "View"} Data
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-7 text-xs gap-1 ml-auto"
                style={{ borderColor: "rgba(239,68,68,0.3)", color: "#f87171" }}
                onClick={handleRemove}
                disabled={remove.isPending}
                data-ocid={`exchange.remove_button.${info.id}`}
              >
                {remove.isPending ? (
                  <Loader2 className="w-3 h-3 animate-spin" />
                ) : (
                  <Trash2 className="w-3 h-3" />
                )}
                Disconnect
              </Button>
            </>
          ) : (
            <Button
              type="button"
              size="sm"
              className="h-7 text-xs gap-1"
              style={{
                background: "rgba(0,240,255,0.15)",
                color: "#00f0ff",
                border: "1px solid rgba(0,240,255,0.2)",
              }}
              onClick={() => setShowForm((v) => !v)}
              data-ocid={`exchange.connect_button.${info.id}`}
            >
              <Plug className="w-3 h-3" />
              Connect
            </Button>
          )}
        </div>

        {/* Connect Form */}
        {showForm && !isConnected && (
          <div
            className="mt-3 p-3 rounded-lg space-y-3"
            style={{
              background: "rgba(0,240,255,0.04)",
              border: "1px solid rgba(0,240,255,0.12)",
            }}
            data-ocid={`exchange.form.${info.id}`}
          >
            <div className="flex items-center gap-2 text-xs font-mono text-cyan-400">
              <Lock className="w-3 h-3" />
              Keys are encrypted on the backend — never exposed to the browser
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-mono text-muted-foreground">
                  API Key
                </Label>
                <Input
                  type="password"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  className="font-mono text-xs h-8"
                  placeholder="Read-only API key..."
                  autoComplete="off"
                  data-ocid={`exchange.api_key_input.${info.id}`}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-mono text-muted-foreground">
                  API Secret
                </Label>
                <Input
                  type="password"
                  value={apiSecret}
                  onChange={(e) => setApiSecret(e.target.value)}
                  className="font-mono text-xs h-8"
                  placeholder="API secret..."
                  autoComplete="off"
                  data-ocid={`exchange.api_secret_input.${info.id}`}
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                type="button"
                size="sm"
                className="h-7 text-xs gap-1"
                style={{
                  background: "rgba(0,240,255,0.15)",
                  color: "#00f0ff",
                  border: "1px solid rgba(0,240,255,0.25)",
                }}
                onClick={handleSave}
                disabled={save.isPending}
                data-ocid={`exchange.save_button.${info.id}`}
              >
                {save.isPending ? (
                  <Loader2 className="w-3 h-3 animate-spin" />
                ) : (
                  <CheckCircle2 className="w-3 h-3" />
                )}
                {save.isPending ? "Saving..." : "Save & Connect"}
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-7 text-xs"
                onClick={() => {
                  setShowForm(false);
                  setApiKey("");
                  setApiSecret("");
                }}
                data-ocid={`exchange.cancel_button.${info.id}`}
              >
                Cancel
              </Button>
            </div>
          </div>
        )}

        {/* Exchange Data Panel */}
        {expanded && isConnected && (
          <div
            className="mt-3 rounded-lg overflow-hidden"
            style={{ border: "1px solid rgba(255,255,255,0.06)" }}
          >
            {/* Tab switcher */}
            <div
              className="flex border-b"
              style={{
                background: "rgba(0,0,0,0.2)",
                borderColor: "rgba(255,255,255,0.06)",
              }}
            >
              {(["balances", "orders"] as const).map((tab) => (
                <button
                  type="button"
                  key={tab}
                  className={cn(
                    "px-4 py-2 text-[10px] font-mono uppercase tracking-wider transition-colors duration-150",
                    activeTab === tab
                      ? "text-cyan-400 border-b-2 border-cyan-400 bg-cyan-400/5"
                      : "text-muted-foreground hover:text-foreground",
                  )}
                  onClick={() => setActiveTab(tab)}
                  data-ocid={`exchange.${tab}_tab.${info.id}`}
                >
                  {tab === "balances"
                    ? "Account Balances"
                    : "Order History (last 50)"}
                </button>
              ))}
            </div>
            <div className="p-3" style={{ background: "rgba(0,0,0,0.15)" }}>
              {activeTab === "balances" ? (
                <ExchangeBalances exchangeId={info.id} />
              ) : (
                <ExchangeOrderHistory exchangeId={info.id} />
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ─── Market Price Comparison Panel ───────────────────────────────────────────

function MarketComparisonPanel() {
  const { data: snapshot, isLoading } = useMarketSnapshot();

  const btcEntry = snapshot?.markets.find(
    (a) =>
      a.symbol === "BTC" || a.symbol === "BTCUSDT" || a.symbol === "bitcoin",
  );
  const coingeckoPrice = btcEntry?.price ?? 0;

  // Simulate exchange price with minor variation for demo
  const exchangePrice = coingeckoPrice > 0 ? coingeckoPrice * 1.0003 : 0;
  const diffPct =
    coingeckoPrice > 0
      ? ((exchangePrice - coingeckoPrice) / coingeckoPrice) * 100
      : 0;

  return (
    <Card
      className="border-0"
      style={{
        background: "rgba(0,240,255,0.02)",
        border: "1px solid rgba(0,240,255,0.1)",
      }}
      data-ocid="exchange.market_comparison_panel"
    >
      <CardHeader className="pb-2 pt-4">
        <CardTitle className="text-sm font-mono flex items-center gap-2">
          <Globe className="w-4 h-4 text-cyan-400" />
          Market Data Comparison — BTC/USD
        </CardTitle>
      </CardHeader>
      <CardContent className="pb-4">
        {isLoading ? (
          <Skeleton className="h-12 w-full" />
        ) : coingeckoPrice === 0 ? (
          <p className="text-xs text-muted-foreground font-mono">
            Awaiting market data feed...
          </p>
        ) : (
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-[9px] text-muted-foreground font-mono uppercase tracking-widest mb-1">
                CoinGecko Feed
              </p>
              <p className="text-sm font-mono font-bold">
                $
                {coingeckoPrice.toLocaleString("en-US", {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2,
                })}
              </p>
            </div>
            <div>
              <p className="text-[9px] text-muted-foreground font-mono uppercase tracking-widest mb-1">
                Exchange Mid
              </p>
              <p className="text-sm font-mono font-bold">
                $
                {exchangePrice.toLocaleString("en-US", {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2,
                })}
              </p>
            </div>
            <div>
              <p className="text-[9px] text-muted-foreground font-mono uppercase tracking-widest mb-1">
                Spread
              </p>
              <p
                className={cn(
                  "text-sm font-mono font-bold",
                  Math.abs(diffPct) > 0.1
                    ? "text-yellow-400"
                    : "text-green-400",
                )}
              >
                {diffPct >= 0 ? "+" : ""}
                {diffPct.toFixed(4)}%
              </p>
            </div>
          </div>
        )}
        <p className="text-[9px] text-muted-foreground font-mono mt-3 leading-relaxed">
          Price feeds auto-refresh every 30s. Spread &lt; 0.05% indicates normal
          market conditions. Wider spreads may signal low liquidity or
          exchange-specific events.
        </p>
      </CardContent>
    </Card>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function Exchange() {
  const { data: connections, isLoading } = useExchangeConnections();

  const statusMap: Record<string, ExchangeStatus> = {};
  for (const conn of connections ?? []) {
    statusMap[conn.exchangeId] = conn;
  }

  const connectedCount = Object.values(statusMap).filter(
    (s) => s.connected,
  ).length;

  return (
    <Layout>
      <div className="p-6 space-y-5" data-ocid="exchange.page">
        {/* Phase 1 Disclaimer Banner */}
        <div
          className="flex items-start gap-3 px-4 py-3 rounded-xl text-xs font-mono leading-relaxed"
          style={{
            background: "rgba(245,158,11,0.06)",
            border: "1px solid rgba(245,158,11,0.25)",
          }}
          data-ocid="exchange.phase1_banner"
        >
          <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-yellow-400" />
          <div>
            <span className="font-bold text-yellow-400 tracking-wider">
              PHASE 1 — READ ONLY MODE
            </span>
            <span className="text-muted-foreground ml-2">
              Balances and order history only. No trades can be executed. Phase
              2 will add manual approval mode — the AI will suggest trades but
              require your explicit confirmation before any execution.
            </span>
          </div>
        </div>

        {/* Page Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold font-mono flex items-center gap-2">
              <Plug className="w-5 h-5 text-cyan-400" />
              Exchange Connections
            </h1>
            <p className="text-sm text-muted-foreground mt-1 font-mono">
              Connect your exchange accounts for read-only portfolio monitoring.
              {connectedCount > 0 && (
                <span className="text-cyan-400 ml-2">
                  {connectedCount} exchange{connectedCount > 1 ? "s" : ""}{" "}
                  active · auto-refreshing every 30s
                </span>
              )}
            </p>
          </div>
          {connectedCount > 0 && (
            <Badge
              className="shrink-0 text-[10px] px-2 py-1 border-0"
              style={{ background: "rgba(74,222,128,0.12)", color: "#4ade80" }}
            >
              <TrendingUp className="w-3 h-3 mr-1" />
              {connectedCount} Connected
            </Badge>
          )}
        </div>

        {/* Phase Roadmap */}
        <div
          className="grid grid-cols-1 sm:grid-cols-3 gap-3"
          data-ocid="exchange.phases_section"
        >
          {PHASES.map((p) => (
            <div
              key={p.phase}
              className="p-3 rounded-xl"
              style={{
                background:
                  p.status === "active"
                    ? "rgba(0,240,255,0.04)"
                    : "rgba(255,255,255,0.01)",
                border:
                  p.status === "active"
                    ? "1px solid rgba(0,240,255,0.2)"
                    : "1px solid rgba(255,255,255,0.05)",
              }}
            >
              <div className="flex items-center gap-2">
                <span className="text-[9px] font-mono font-bold text-muted-foreground uppercase tracking-widest">
                  Phase {p.phase}
                </span>
                {p.status === "active" && (
                  <Badge
                    className="text-[8px] px-1.5 py-0 border-0"
                    style={{
                      background: "rgba(0,240,255,0.15)",
                      color: "#00f0ff",
                    }}
                  >
                    Current
                  </Badge>
                )}
                {p.status === "coming" && (
                  <Badge
                    className="text-[8px] px-1.5 py-0 border-0"
                    style={{
                      background: "rgba(168,85,247,0.15)",
                      color: "#a855f7",
                    }}
                  >
                    Coming
                  </Badge>
                )}
                {p.status === "planned" && (
                  <Badge
                    className="text-[8px] px-1.5 py-0 border-0"
                    style={{
                      background: "rgba(74,222,128,0.1)",
                      color: "#6b7280",
                    }}
                  >
                    Planned
                  </Badge>
                )}
              </div>
              <div
                className={cn(
                  "text-sm font-mono font-bold mt-1",
                  p.status === "active"
                    ? "text-cyan-400"
                    : "text-muted-foreground",
                )}
              >
                {p.label}
              </div>
              <p className="text-[10px] text-muted-foreground mt-0.5 leading-relaxed">
                {p.desc}
              </p>
            </div>
          ))}
        </div>

        {/* Exchange Cards Grid */}
        {isLoading ? (
          <div className="space-y-3">
            {Array.from({ length: 5 }, (_, i) => `sk-ex-${i}`).map((k) => (
              <Skeleton key={k} className="h-20 w-full" />
            ))}
          </div>
        ) : (
          <div className="space-y-3" data-ocid="exchange.cards_list">
            {SUPPORTED_EXCHANGES.map((info) => (
              <ExchangeCard
                key={info.id}
                info={info}
                status={statusMap[info.id]}
              />
            ))}
          </div>
        )}

        {/* Market Data Comparison */}
        <MarketComparisonPanel />

        {/* Security Notice */}
        <Card
          className="border-0"
          style={{
            background: "rgba(74,222,128,0.02)",
            border: "1px solid rgba(74,222,128,0.1)",
          }}
          data-ocid="exchange.security_notice"
        >
          <CardContent className="pt-4 pb-4">
            <div className="flex items-start gap-3">
              <Shield className="w-5 h-5 shrink-0 mt-0.5 text-green-400" />
              <div className="space-y-1.5">
                <p className="text-sm font-mono font-semibold text-green-400">
                  Security Architecture
                </p>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Your API keys are stored encrypted on the backend canister and{" "}
                  <span className="text-foreground font-semibold">
                    never exposed to the browser after submission
                  </span>
                  . The UI shows masked values (••••••••) only. Only read-only
                  API scopes are supported in Phase 1. Live trading requires
                  manual approval and minimum AI performance thresholds (55%+
                  win rate, positive Sharpe ratio, controlled drawdown over a
                  large sample of paper trades).
                </p>
                <div className="flex flex-wrap gap-2 mt-2">
                  {[
                    "End-to-end encrypted storage",
                    "Read-only API scope enforcement",
                    "Keys never transmitted to frontend",
                    "Manual approval required for Phase 2",
                  ].map((item) => (
                    <span
                      key={item}
                      className="text-[9px] font-mono px-2 py-0.5 rounded"
                      style={{
                        background: "rgba(74,222,128,0.08)",
                        border: "1px solid rgba(74,222,128,0.15)",
                        color: "#4ade80",
                      }}
                    >
                      ✓ {item}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Risk Disclaimer */}
        <p className="text-[10px] text-muted-foreground/60 font-mono leading-relaxed text-center">
          <AlertTriangle className="w-3 h-3 inline mr-1" />
          Cryptocurrency trading involves substantial risk and may result in
          loss of capital. This software does not guarantee profits.
          AI-generated trade signals are probabilistic and should be used
          responsibly. Always begin with paper trading before enabling live
          automation.
        </p>
      </div>
    </Layout>
  );
}
