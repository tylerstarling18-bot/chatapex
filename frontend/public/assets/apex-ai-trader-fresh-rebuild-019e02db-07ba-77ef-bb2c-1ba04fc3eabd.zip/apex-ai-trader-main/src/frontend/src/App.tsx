import { useEffect, useMemo, useState } from 'react';
import { Activity, AlertTriangle, Bot, Brain, CandlestickChart, CircleStop, Database, FlaskConical, Gauge, LineChart as LineIcon, Play, RefreshCw, Shield, Trophy, Zap } from 'lucide-react';
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { CONFIG, createInitialState, engineStep, fetchLiveMarketSnapshots, getSymbols, latestDecisions, leaderboard, runBacktest, type EngineState, type SymbolKey } from './lib/tradingEngine';
import './index.css';

function money(value: number) {
  return value.toLocaleString(undefined, { style: 'currency', currency: 'USD', maximumFractionDigits: value > 100 ? 0 : 4 });
}

function pct(value: number) {
  return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`;
}

function Card({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <div className={`rounded-2xl border border-cyan-400/15 bg-slate-950/70 shadow-2xl shadow-cyan-950/20 backdrop-blur p-4 ${className}`}>{children}</div>;
}

function Pill({ children, tone = 'cyan' }: { children: React.ReactNode; tone?: 'cyan' | 'green' | 'red' | 'yellow' | 'purple' }) {
  const tones = { cyan: 'border-cyan-400/30 text-cyan-200 bg-cyan-400/10', green: 'border-emerald-400/30 text-emerald-200 bg-emerald-400/10', red: 'border-red-400/30 text-red-200 bg-red-400/10', yellow: 'border-yellow-400/30 text-yellow-200 bg-yellow-400/10', purple: 'border-purple-400/30 text-purple-200 bg-purple-400/10' };
  return <span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs ${tones[tone]}`}>{children}</span>;
}

function Stat({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: string; sub?: string }) {
  return <Card><div className="flex items-center gap-3"><div className="rounded-xl bg-cyan-400/10 p-2 text-cyan-300">{icon}</div><div><div className="text-xs uppercase tracking-widest text-slate-500">{label}</div><div className="text-2xl font-semibold text-white">{value}</div>{sub && <div className="text-xs text-slate-400">{sub}</div>}</div></div></Card>;
}

function Header({ state, setState }: { state: EngineState; setState: React.Dispatch<React.SetStateAction<EngineState>> }) {
  return <div className="flex flex-col gap-4 border-b border-cyan-400/10 bg-slate-950/80 px-6 py-5 backdrop-blur lg:flex-row lg:items-center lg:justify-between">
    <div>
      <div className="flex items-center gap-3"><div className="rounded-2xl bg-cyan-400/10 p-2 text-cyan-300"><Brain /></div><div><h1 className="text-2xl font-black tracking-tight text-white">Apex AI Trader</h1><p className="text-sm text-slate-400">Simulation-first autonomous multi-agent crypto research terminal</p></div></div>
    </div>
    <div className="flex flex-wrap items-center gap-2">
      <Pill tone="green">LIVE TRADING DISABLED</Pill>
      <Pill tone={state.simulationRunning ? 'green' : 'yellow'}>{state.simulationRunning ? 'SIM RUNNING' : 'SIM PAUSED'}</Pill>
      <button onClick={() => setState((s) => ({ ...s, simulationRunning: !s.simulationRunning }))} className="rounded-xl border border-cyan-400/20 bg-cyan-400/10 px-4 py-2 text-sm text-cyan-100 hover:bg-cyan-400/20">{state.simulationRunning ? 'Pause Sim' : 'Resume Sim'}</button>
      <button onClick={() => setState((s) => ({ ...s, emergencyStop: !s.emergencyStop }))} className={`rounded-xl border px-4 py-2 text-sm ${state.emergencyStop ? 'border-red-400/40 bg-red-500/20 text-red-100' : 'border-yellow-400/30 bg-yellow-400/10 text-yellow-100'}`}><CircleStop className="mr-2 inline h-4 w-4" />{state.emergencyStop ? 'Kill Switch Active' : 'Emergency Stop'}</button>
    </div>
  </div>;
}

function MarketCards({ state }: { state: EngineState }) {
  return <div className="grid grid-cols-2 gap-3 md:grid-cols-5 xl:grid-cols-10">{state.snapshots.map((s) => <Card key={s.symbol} className="p-3"><div className="text-xs text-slate-500">{s.symbol}</div><div className="text-lg font-bold text-white">{money(s.price)}</div><div className={s.change24h >= 0 ? 'text-xs text-emerald-300' : 'text-xs text-red-300'}>{pct(s.change24h)}</div></Card>)}</div>;
}

function Leaderboard({ state }: { state: EngineState }) {
  const rows = useMemo(() => leaderboard(state), [state]);
  return <Card className="xl:col-span-5"><div className="mb-3 flex items-center justify-between"><h2 className="flex items-center gap-2 text-lg font-bold text-white"><Trophy className="h-5 w-5 text-yellow-300" /> Agent Competition Arena</h2><Pill>fair same-data sim</Pill></div><div className="overflow-x-auto"><table className="w-full text-sm"><thead className="text-left text-xs uppercase tracking-widest text-slate-500"><tr><th className="py-2">Agent</th><th>Equity</th><th>Return</th><th>Trades</th><th>Win</th><th>PF</th><th>Weight</th></tr></thead><tbody>{rows.map((r, i) => <tr key={r.agent} className="border-t border-slate-800/80"><td className="py-2 text-white"><span className="mr-2 text-slate-500">#{i + 1}</span>{r.agent}</td><td className="text-slate-200">{money(r.equity)}</td><td className={r.returnPct >= 0 ? 'text-emerald-300' : 'text-red-300'}>{pct(r.returnPct)}</td><td className="text-slate-300">{r.trades}</td><td className="text-slate-300">{r.winRate.toFixed(0)}%</td><td className="text-slate-300">{r.profitFactor > 90 ? '∞' : r.profitFactor.toFixed(2)}</td><td className="text-cyan-200">{r.weight.toFixed(2)}x</td></tr>)}</tbody></table></div></Card>;
}

function EquityChart({ state }: { state: EngineState }) {
  const top = leaderboard(state).slice(0, 4).map((r) => r.agent);
  const maxLen = Math.max(...state.agents.map((a) => a.equityCurve.length));
  const data = Array.from({ length: maxLen }, (_, i) => {
    const row: Record<string, number | string> = { t: String(i) };
    state.agents.filter((a) => top.includes(a.name)).forEach((a) => { row[a.name] = a.equityCurve[i]?.equity ?? a.equityCurve.at(-1)?.equity ?? CONFIG.startingBalance; });
    return row;
  });
  return <Card className="xl:col-span-7"><div className="mb-3 flex items-center gap-2"><LineIcon className="h-5 w-5 text-cyan-300" /><h2 className="text-lg font-bold text-white">Portfolio Equity Curve</h2></div><div className="h-80"><ResponsiveContainer width="100%" height="100%"><LineChart data={data}><CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,.15)" /><XAxis dataKey="t" stroke="rgba(148,163,184,.7)" /><YAxis stroke="rgba(148,163,184,.7)" domain={['auto','auto']} /><Tooltip contentStyle={{ background: '#020617', border: '1px solid rgba(34,211,238,.25)', borderRadius: 12 }} /><Legend />{top.map((name) => <Line key={name} dataKey={name} dot={false} strokeWidth={2} />)}</LineChart></ResponsiveContainer></div></Card>;
}

function Decisions({ state }: { state: EngineState }) {
  const decisions = useMemo(() => latestDecisions(state), [state]);
  return <Card className="xl:col-span-4"><div className="mb-3 flex items-center gap-2"><Bot className="h-5 w-5 text-purple-300" /><h2 className="text-lg font-bold text-white">AI Explainability Feed</h2></div><div className="space-y-3">{decisions.map((d) => <div key={`${d.agent}-${d.symbol}`} className="rounded-xl border border-slate-800 bg-slate-900/50 p-3"><div className="flex items-center justify-between gap-2"><div className="font-semibold text-white">{d.agent}</div><Pill tone={d.action === 'BUY' ? 'green' : d.action === 'SELL' ? 'red' : 'yellow'}>{d.action} {d.symbol}</Pill></div><div className="mt-2 grid grid-cols-3 gap-2 text-xs"><div className="text-slate-400">Confidence <span className="text-cyan-200">{d.confidence.final}</span></div><div className="text-slate-400">Regime <span className="text-slate-200">{d.regime}</span></div><div className="text-slate-400">R/R <span className="text-slate-200">{d.riskReward.toFixed(2)}</span></div></div><p className="mt-2 text-xs leading-relaxed text-slate-300">{d.reason}</p>{d.rejectionReason && <p className="mt-1 text-xs text-yellow-300">Skipped: {d.rejectionReason}</p>}</div>)}</div></Card>;
}

function PositionsTrades({ state }: { state: EngineState }) {
  const positions = state.agents.flatMap((a) => a.openPositions.map((p) => ({ ...p, agent: a.name })));
  const trades = state.agents.flatMap((a) => a.closedTrades).sort((a, b) => b.exitTime - a.exitTime).slice(0, 12);
  return <div className="grid gap-4 xl:grid-cols-2"><Card><h2 className="mb-3 flex items-center gap-2 text-lg font-bold text-white"><Activity className="h-5 w-5 text-emerald-300" /> Open Positions</h2><div className="space-y-2">{positions.length === 0 && <div className="rounded-xl border border-dashed border-slate-700 p-4 text-sm text-slate-400">No open positions yet. The agents are scanning and logging skipped trade reasons.</div>}{positions.slice(0, 12).map((p) => <div key={p.id} className="grid grid-cols-5 gap-2 rounded-xl border border-slate-800 bg-slate-900/50 p-2 text-sm"><div className="col-span-2 text-white">{p.agent}</div><div className="text-cyan-200">{p.symbol}</div><div className="text-slate-300">{money(p.entryPrice)}</div><div className="text-slate-400">C{p.confidence}</div></div>)}</div></Card><Card><h2 className="mb-3 flex items-center gap-2 text-lg font-bold text-white"><Database className="h-5 w-5 text-cyan-300" /> Closed Trades</h2><div className="space-y-2">{trades.length === 0 && <div className="rounded-xl border border-dashed border-slate-700 p-4 text-sm text-slate-400">No closed trades yet.</div>}{trades.map((t) => <div key={t.id} className="grid grid-cols-5 gap-2 rounded-xl border border-slate-800 bg-slate-900/50 p-2 text-sm"><div className="col-span-2 truncate text-white">{t.agent}</div><div className="text-cyan-200">{t.symbol}</div><div className={t.pnl >= 0 ? 'text-emerald-300' : 'text-red-300'}>{money(t.pnl)}</div><div className="truncate text-slate-400">{t.reason}</div></div>)}</div></Card></div>;
}

function CandlePanel({ state }: { state: EngineState }) {
  const [symbol, setSymbol] = useState<SymbolKey>('BTC');
  const data = state.candles[symbol].slice(-80).map((c, i) => ({ i, close: c.close, high: c.high, low: c.low, open: c.open, volume: c.volume }));
  const markers = state.agents.flatMap((a) => a.closedTrades.filter((t) => t.symbol === symbol).slice(0, 10));
  return <Card className="xl:col-span-8"><div className="mb-3 flex flex-wrap items-center justify-between gap-2"><h2 className="flex items-center gap-2 text-lg font-bold text-white"><CandlestickChart className="h-5 w-5 text-cyan-300" /> Market Replay / Chart</h2><select value={symbol} onChange={(e) => setSymbol(e.target.value as SymbolKey)} className="rounded-xl border border-cyan-400/20 bg-slate-950 px-3 py-2 text-sm text-cyan-100">{getSymbols().map((s) => <option key={s}>{s}</option>)}</select></div><div className="h-80"><ResponsiveContainer width="100%" height="100%"><AreaChart data={data}><CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,.15)" /><XAxis dataKey="i" stroke="rgba(148,163,184,.7)" /><YAxis stroke="rgba(148,163,184,.7)" domain={['auto','auto']} /><Tooltip contentStyle={{ background: '#020617', border: '1px solid rgba(34,211,238,.25)', borderRadius: 12 }} /><Area type="monotone" dataKey="close" fill="rgba(34,211,238,.12)" stroke="rgb(34,211,238)" strokeWidth={2} /></AreaChart></ResponsiveContainer></div><div className="mt-3 flex flex-wrap gap-2 text-xs text-slate-400"><Pill tone="green">actual trade markers</Pill><Pill tone="purple">forward-looking AI signals</Pill><span>{markers.length} completed {symbol} trades in memory</span></div></Card>;
}

function BacktestPanel() {
  const [symbol, setSymbol] = useState<SymbolKey>('BTC');
  const [rows, setRows] = useState<ReturnType<typeof runBacktest>>([]);
  const [running, setRunning] = useState(false);
  const start = () => { setRunning(true); setTimeout(() => { setRows(runBacktest(symbol, 220)); setRunning(false); }, 50); };
  return <Card className="xl:col-span-4"><div className="mb-3 flex items-center gap-2"><FlaskConical className="h-5 w-5 text-purple-300" /><h2 className="text-lg font-bold text-white">Backtest Lab</h2></div><p className="mb-3 text-sm text-slate-400">Runs all agents through the same generated historical candle stream for fair comparison.</p><div className="flex gap-2"><select value={symbol} onChange={(e) => setSymbol(e.target.value as SymbolKey)} className="flex-1 rounded-xl border border-cyan-400/20 bg-slate-950 px-3 py-2 text-sm text-cyan-100">{getSymbols().map((s) => <option key={s}>{s}</option>)}</select><button onClick={start} className="rounded-xl bg-cyan-400 px-4 py-2 text-sm font-bold text-slate-950 hover:bg-cyan-300"><Play className="mr-1 inline h-4 w-4" />Run</button></div>{running && <div className="mt-3 text-sm text-cyan-200">Running replay...</div>}<div className="mt-4 space-y-2">{rows.slice(0, 6).map((r, i) => <div key={r.agent} className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-900/50 p-2 text-sm"><span className="text-white">#{i + 1} {r.agent}</span><span className={r.returnPct >= 0 ? 'text-emerald-300' : 'text-red-300'}>{pct(r.returnPct)}</span></div>)}</div></Card>;
}

function RiskAndLogs({ state }: { state: EngineState }) {
  const top = leaderboard(state)[0];
  return <div className="grid gap-4 xl:grid-cols-3"><Card><h2 className="mb-3 flex items-center gap-2 text-lg font-bold text-white"><Shield className="h-5 w-5 text-emerald-300" /> Risk Engine</h2><div className="space-y-3 text-sm"><div className="flex justify-between"><span className="text-slate-400">Live trading</span><Pill tone="green">disabled</Pill></div><div className="flex justify-between"><span className="text-slate-400">Emergency stop</span><Pill tone={state.emergencyStop ? 'red' : 'green'}>{state.emergencyStop ? 'active' : 'clear'}</Pill></div><div className="flex justify-between"><span className="text-slate-400">Max daily loss</span><span className="text-white">{CONFIG.maxDailyLossPct * 100}%</span></div><div className="flex justify-between"><span className="text-slate-400">Max position</span><span className="text-white">{CONFIG.maxPositionPct * 100}%</span></div><div className="flex justify-between"><span className="text-slate-400">Current leader</span><span className="text-cyan-200">{top?.agent}</span></div></div></Card><Card className="xl:col-span-2"><h2 className="mb-3 flex items-center gap-2 text-lg font-bold text-white"><AlertTriangle className="h-5 w-5 text-yellow-300" /> Structured Event Logs</h2><div className="max-h-72 space-y-2 overflow-y-auto pr-2">{state.logs.slice(0, 25).map((l) => <div key={l.id} className="rounded-lg border border-slate-800 bg-slate-900/60 px-3 py-2 text-xs"><span className={l.level === 'TRADE' ? 'text-emerald-300' : l.level === 'RISK' ? 'text-yellow-300' : l.level === 'AI' ? 'text-purple-300' : 'text-cyan-300'}>[{l.level}]</span> <span className="text-slate-400">{l.source}</span> <span className="text-slate-200">{l.message}</span></div>)}</div></Card></div>;
}

export default function App() {
  const [state, setState] = useState<EngineState>(() => createInitialState());
  const [liveDataStatus, setLiveDataStatus] = useState<'fallback' | 'live'>('fallback');

  useEffect(() => {
    let mounted = true;
    const interval = setInterval(async () => {
      const live = await fetchLiveMarketSnapshots();
      if (!mounted) return;
      setLiveDataStatus(live ? 'live' : 'fallback');
      setState((s) => engineStep(s, live));
    }, 3000);
    return () => { mounted = false; clearInterval(interval); };
  }, []);

  const rows = leaderboard(state);
  const totalTrades = state.agents.reduce((s, a) => s + a.closedTrades.length, 0);
  const openPositions = state.agents.reduce((s, a) => s + a.openPositions.length, 0);
  const leader = rows[0];

  return <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,rgba(6,182,212,.18),transparent_35%),radial-gradient(circle_at_top_right,rgba(168,85,247,.18),transparent_30%),#020617] text-slate-100"><Header state={state} setState={setState} /><main className="space-y-4 p-4 lg:p-6"><div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4"><Stat icon={<Gauge />} label="Leading Agent Equity" value={money(leader?.equity ?? CONFIG.startingBalance)} sub={`${leader?.agent ?? 'N/A'} ${leader ? pct(leader.returnPct) : ''}`} /><Stat icon={<Zap />} label="Total Closed Trades" value={String(totalTrades)} sub={`${openPositions} open positions`} /><Stat icon={<RefreshCw />} label="Market Data" value={liveDataStatus === 'live' ? 'Live API' : 'Fallback Sim'} sub="CoinGecko with cached simulation fallback" /><Stat icon={<Shield />} label="Safety Mode" value="Paper Only" sub="ENABLE_LIVE_TRADING=false" /></div><MarketCards state={state} /><div className="grid gap-4 xl:grid-cols-12"><EquityChart state={state} /><Leaderboard state={state} /></div><div className="grid gap-4 xl:grid-cols-12"><CandlePanel state={state} /><BacktestPanel /></div><div className="grid gap-4 xl:grid-cols-12"><Decisions state={state} /><div className="xl:col-span-8"><PositionsTrades state={state} /></div></div><RiskAndLogs state={state} /><Card><h2 className="mb-2 text-lg font-bold text-white">Build Notes</h2><p className="text-sm leading-relaxed text-slate-400">This rebuild is intentionally simulation-first: multiple agents compete on the same market stream, Apex Intelligence Core reweights strategies based on performance, every skipped trade produces explainable rejection logic, and live exchange execution is structurally disabled. Next production steps are persistent database storage, authenticated user accounts, real exchange read-only adapters, and server-side scheduled execution.</p></Card></main></div>;
}
