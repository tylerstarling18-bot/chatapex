import { Layout } from "@/components/Layout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useArenaResults,
  useArenaSessions,
  useStartArena,
} from "@/hooks/useQueries";
import { cn } from "@/lib/utils";
import type { ArenaResult, ArenaSession } from "@/types";
import {
  Award,
  BarChart2,
  Brain,
  ChevronDown,
  ChevronUp,
  Loader2,
  Play,
  Shield,
  Swords,
  Target,
  TrendingDown,
  TrendingUp,
  Trophy,
  Zap,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

// ─── Agent profiles ──────────────────────────────────────────────────────────

const AGENT_PROFILES: Record<
  string,
  {
    label: string;
    color: string;
    glowColor: string;
    icon: React.ElementType;
    desc: string;
    riskMultiplier: string;
    preferredTimeframe: string;
    strategyFocus: string;
  }
> = {
  aggressive_momentum: {
    label: "Aggressive Momentum",
    color: "#f87171",
    glowColor: "rgba(248,113,113,0.25)",
    icon: Zap,
    desc: "Chases breakouts and momentum explosions with tight stops. High risk, high frequency, maximum aggression.",
    riskMultiplier: "2.5×",
    preferredTimeframe: "1m–5m",
    strategyFocus: "Breakout & momentum",
  },
  conservative_risk: {
    label: "Conservative Risk",
    color: "#4ade80",
    glowColor: "rgba(74,222,128,0.2)",
    icon: Shield,
    desc: "Capital-first approach. Wide stops, slow compounding, never overtrades. Survives every crash.",
    riskMultiplier: "0.5×",
    preferredTimeframe: "4h–1d",
    strategyFocus: "Capital preservation",
  },
  scalping: {
    label: "Scalping AI",
    color: "#facc15",
    glowColor: "rgba(250,204,21,0.2)",
    icon: Target,
    desc: "Ultra-short holds, micro profit targets, very high trade frequency. Lives on bid-ask spread.",
    riskMultiplier: "1.0×",
    preferredTimeframe: "1m",
    strategyFocus: "Micro-profit scalping",
  },
  swing_trading: {
    label: "Swing Trading",
    color: "#818cf8",
    glowColor: "rgba(129,140,248,0.2)",
    icon: TrendingUp,
    desc: "Multi-day holds with trend confirmation. Patient, calculated, rides full price swings.",
    riskMultiplier: "1.2×",
    preferredTimeframe: "1h–4h",
    strategyFocus: "Trend swing capture",
  },
  mean_reversion: {
    label: "Mean Reversion",
    color: "#fb923c",
    glowColor: "rgba(251,146,60,0.2)",
    icon: TrendingDown,
    desc: "Fades price extremes. Range-bound specialist — profits when overextended moves snap back.",
    riskMultiplier: "1.0×",
    preferredTimeframe: "15m–1h",
    strategyFocus: "Reversion to mean",
  },
  trend_following: {
    label: "Trend Following",
    color: "#22d3ee",
    glowColor: "rgba(34,211,238,0.2)",
    icon: Brain,
    desc: "Pure trend rider — never counter-trend. Follows institutional momentum. Patience incarnate.",
    riskMultiplier: "1.5×",
    preferredTimeframe: "1h–1d",
    strategyFocus: "Trend identification",
  },
};

const AGENT_ORDER = Object.keys(AGENT_PROFILES);

// ─── Helpers ─────────────────────────────────────────────────────────────────

function formatHoldTime(avgHoldTimeBigInt: bigint): string {
  const seconds = Number(avgHoldTimeBigInt);
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.round(seconds / 60)}m`;
  if (seconds < 86400) return `${(seconds / 3600).toFixed(1)}h`;
  return `${(seconds / 86400).toFixed(1)}d`;
}

function ReturnBadge({ pct }: { pct: number }) {
  const isPos = pct >= 0;
  return (
    <span
      className={cn(
        "font-bold font-mono text-base",
        isPos ? "text-green-400" : "text-red-400",
      )}
    >
      {isPos ? "+" : ""}
      {pct.toFixed(2)}%
    </span>
  );
}

function RankMedal({ rank }: { rank: number }) {
  if (rank === 1)
    return (
      <span className="text-amber-400 font-bold font-mono text-sm">🥇 1st</span>
    );
  if (rank === 2)
    return (
      <span className="text-slate-300 font-bold font-mono text-sm">🥈 2nd</span>
    );
  if (rank === 3)
    return (
      <span className="text-orange-400 font-bold font-mono text-sm">
        🥉 3rd
      </span>
    );
  return (
    <span className="text-muted-foreground font-mono text-sm">#{rank}</span>
  );
}

// ─── Agent Profile Cards ──────────────────────────────────────────────────────

function AgentCard({ agentId }: { agentId: string }) {
  const p = AGENT_PROFILES[agentId];
  if (!p) return null;
  const Icon = p.icon;
  return (
    <div
      className="rounded-xl border p-4 transition-smooth hover:scale-[1.02]"
      style={{
        background: `linear-gradient(135deg, ${p.glowColor}, rgba(10,14,26,0.6))`,
        borderColor: `${p.color}30`,
        boxShadow: `inset 0 1px 0 ${p.color}15`,
      }}
      data-ocid={`arena.agent_profile.${agentId}`}
    >
      <div className="flex items-start gap-3">
        <div
          className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
          style={{
            background: `${p.color}20`,
            border: `1px solid ${p.color}40`,
          }}
        >
          <Icon className="w-4 h-4" style={{ color: p.color }} />
        </div>
        <div className="flex-1 min-w-0">
          <div
            className="font-mono font-bold text-sm"
            style={{ color: p.color }}
          >
            {p.label}
          </div>
          <p className="text-[11px] text-muted-foreground mt-0.5 leading-relaxed">
            {p.desc}
          </p>
        </div>
      </div>
      <div
        className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t"
        style={{ borderColor: `${p.color}15` }}
      >
        {[
          { label: "Risk", value: p.riskMultiplier },
          { label: "Timeframe", value: p.preferredTimeframe },
          { label: "Focus", value: p.strategyFocus },
        ].map(({ label, value }) => (
          <div key={label}>
            <div className="text-[9px] font-mono uppercase tracking-wider text-muted-foreground">
              {label}
            </div>
            <div className="text-[11px] font-mono font-semibold mt-0.5 truncate">
              {value}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Leaderboard Table ────────────────────────────────────────────────────────

function LeaderboardTable({
  results,
  title,
  subtitle,
  sortKey,
  ascending = false,
  highlightFirst = true,
  icon: Icon,
}: {
  results: ArenaResult[];
  title: string;
  subtitle: string;
  sortKey: keyof ArenaResult;
  ascending?: boolean;
  highlightFirst?: boolean;
  icon: React.ElementType;
}) {
  const sorted = [...results].sort((a, b) => {
    const aVal = Number(a[sortKey]);
    const bVal = Number(b[sortKey]);
    return ascending ? aVal - bVal : bVal - aVal;
  });

  return (
    <Card
      className="border-0"
      style={{
        background: "rgba(10,14,26,0.7)",
        border: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
          <Icon className="w-4 h-4 text-cyan-400" />
          {title}
        </CardTitle>
        <p className="text-xs text-muted-foreground">{subtitle}</p>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
                {[
                  "Rank",
                  "Agent",
                  "Return",
                  "Balance",
                  "Sharpe",
                  "Max DD",
                  "Win Rate",
                  "Trades",
                  "Avg Hold",
                ].map((col) => (
                  <th
                    key={col}
                    className="text-left px-4 py-2 text-[10px] font-mono uppercase tracking-wider text-muted-foreground"
                  >
                    {col}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sorted.map((r, idx) => {
                const profile = AGENT_PROFILES[r.agentId];
                const isFirst = highlightFirst && idx === 0;
                return (
                  <tr
                    key={r.agentId}
                    data-ocid={`arena.leaderboard.${title.toLowerCase().replace(/ /g, "_")}.row.${idx + 1}`}
                    style={{
                      background: isFirst
                        ? "rgba(251,191,36,0.04)"
                        : idx % 2 === 0
                          ? "rgba(255,255,255,0.01)"
                          : "transparent",
                      borderBottom: "1px solid rgba(255,255,255,0.03)",
                    }}
                  >
                    <td className="px-4 py-3">
                      <RankMedal rank={idx + 1} />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div
                          className="w-2.5 h-2.5 rounded-full shrink-0"
                          style={{
                            background: profile?.color ?? "#64748b",
                            boxShadow: `0 0 6px ${profile?.color ?? "#64748b"}60`,
                          }}
                        />
                        <span className="text-xs font-mono font-medium">
                          {profile?.label ?? r.agentId}
                        </span>
                        {isFirst && (
                          <span
                            className="text-[9px] font-mono px-1.5 py-0.5 rounded-full"
                            style={{
                              background: "rgba(251,191,36,0.15)",
                              color: "#fbbf24",
                              border: "1px solid rgba(251,191,36,0.3)",
                            }}
                          >
                            WINNER
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <ReturnBadge pct={r.totalReturnPct} />
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-xs font-mono">
                        $
                        {r.finalBalance.toLocaleString(undefined, {
                          maximumFractionDigits: 0,
                        })}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={cn(
                          "text-xs font-mono",
                          r.sharpeRatio >= 1
                            ? "text-green-400"
                            : r.sharpeRatio >= 0
                              ? "text-muted-foreground"
                              : "text-red-400",
                        )}
                      >
                        {r.sharpeRatio.toFixed(2)}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-xs font-mono text-red-400">
                        -{r.maxDrawdownPct.toFixed(1)}%
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={cn(
                          "text-xs font-mono",
                          r.winRate >= 0.55
                            ? "text-green-400"
                            : "text-muted-foreground",
                        )}
                      >
                        {(r.winRate * 100).toFixed(1)}%
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-xs font-mono text-muted-foreground">
                        {Number(r.tradeCount)}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-xs font-mono text-muted-foreground">
                        {formatHoldTime(r.avgHoldTime)}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Regime Breakdown ─────────────────────────────────────────────────────────

function RegimeBreakdownSection({ results }: { results: ArenaResult[] }) {
  const allRegimes = Array.from(
    new Set(
      results.flatMap((r) =>
        r.performanceByRegime.map((p) => String(p.regime)),
      ),
    ),
  );

  if (allRegimes.length === 0) return null;

  return (
    <Card
      className="border-0"
      style={{
        background: "rgba(10,14,26,0.7)",
        border: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
          <BarChart2 className="w-4 h-4 text-cyan-400" />
          Performance by Market Regime
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          Which agent excels in each market condition
        </p>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
                <th className="text-left px-4 py-2 text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                  Agent
                </th>
                {allRegimes.map((regime) => (
                  <th
                    key={regime}
                    className="text-center px-3 py-2 text-[10px] font-mono uppercase tracking-wider text-muted-foreground"
                  >
                    {String(regime).replace(/_/g, " ")}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {results
                .sort((a, b) => b.totalReturnPct - a.totalReturnPct)
                .map((r, idx) => {
                  const profile = AGENT_PROFILES[r.agentId];
                  return (
                    <tr
                      key={r.agentId}
                      data-ocid={`arena.regime.row.${idx + 1}`}
                      style={{
                        background:
                          idx % 2 === 0
                            ? "rgba(255,255,255,0.01)"
                            : "transparent",
                        borderBottom: "1px solid rgba(255,255,255,0.03)",
                      }}
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div
                            className="w-2 h-2 rounded-full"
                            style={{ background: profile?.color ?? "#64748b" }}
                          />
                          <span className="text-xs font-mono">
                            {profile?.label ?? r.agentId}
                          </span>
                        </div>
                      </td>
                      {allRegimes.map((regime) => {
                        const regimeStat = r.performanceByRegime.find(
                          (p) => String(p.regime) === regime,
                        );
                        if (!regimeStat)
                          return (
                            <td
                              key={regime}
                              className="px-3 py-3 text-center text-xs font-mono text-muted-foreground/30"
                            >
                              —
                            </td>
                          );
                        return (
                          <td key={regime} className="px-3 py-3 text-center">
                            <div
                              className={cn(
                                "text-xs font-mono font-semibold",
                                regimeStat.returnPct >= 0
                                  ? "text-green-400"
                                  : "text-red-400",
                              )}
                            >
                              {regimeStat.returnPct >= 0 ? "+" : ""}
                              {regimeStat.returnPct.toFixed(1)}%
                            </div>
                            <div className="text-[9px] font-mono text-muted-foreground">
                              {(regimeStat.winRate * 100).toFixed(0)}% WR
                            </div>
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Best Performer Insights ──────────────────────────────────────────────────

function BestPerformerInsights({ results }: { results: ArenaResult[] }) {
  if (results.length === 0) return null;

  const byReturn = [...results].sort(
    (a, b) => b.totalReturnPct - a.totalReturnPct,
  );
  const bySharpe = [...results].sort((a, b) => b.sharpeRatio - a.sharpeRatio);
  const byDrawdown = [...results].sort(
    (a, b) => a.maxDrawdownPct - b.maxDrawdownPct,
  );

  const winner = byReturn[0];
  const winnerProfile = AGENT_PROFILES[winner.agentId];

  const insights = [
    {
      label: "Highest Raw Return",
      agent: byReturn[0],
      value: `+${byReturn[0].totalReturnPct.toFixed(2)}%`,
      detail: "Best absolute profit across the entire simulation period",
      color: "#22d3ee",
    },
    {
      label: "Best Drawdown Control",
      agent: byDrawdown[0],
      value: `-${byDrawdown[0].maxDrawdownPct.toFixed(1)}% DD`,
      detail: "Lowest peak-to-trough loss — most capital-protective behavior",
      color: "#4ade80",
    },
    {
      label: "Best Risk-Adjusted Return",
      agent: bySharpe[0],
      value: `${bySharpe[0].sharpeRatio.toFixed(2)} Sharpe`,
      detail: "Highest return per unit of risk — true professional performance",
      color: "#818cf8",
    },
  ];

  return (
    <Card
      className="border-0"
      style={{
        background: "rgba(251,191,36,0.03)",
        border: "1px solid rgba(251,191,36,0.2)",
        boxShadow: "0 0 40px rgba(251,191,36,0.05)",
      }}
      data-ocid="arena.best_performer.card"
    >
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
          <Trophy className="w-4 h-4 text-amber-400" />
          <span className="text-amber-400">Winner Analysis</span>
        </CardTitle>
        <div className="flex items-center gap-2 mt-1">
          <div
            className="w-3 h-3 rounded-full"
            style={{
              background: winnerProfile?.color ?? "#64748b",
              boxShadow: `0 0 8px ${winnerProfile?.color ?? "#64748b"}80`,
            }}
          />
          <span className="text-sm font-mono font-bold text-amber-300">
            {winnerProfile?.label ?? winner.agentId}
          </span>
          <span className="text-xs text-muted-foreground">
            dominated the competition
          </span>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {insights.map((ins, i) => {
            const insProfile = AGENT_PROFILES[ins.agent.agentId];
            return (
              <div
                key={ins.label}
                className="rounded-lg p-3"
                style={{
                  background: `${ins.color}08`,
                  border: `1px solid ${ins.color}20`,
                }}
                data-ocid={`arena.insight.${i + 1}`}
              >
                <div
                  className="text-[10px] font-mono uppercase tracking-wider mb-2"
                  style={{ color: ins.color }}
                >
                  {ins.label}
                </div>
                <div className="flex items-center gap-2 mb-1">
                  <div
                    className="w-2 h-2 rounded-full"
                    style={{ background: insProfile?.color ?? "#64748b" }}
                  />
                  <span className="text-xs font-mono font-bold">
                    {insProfile?.label ?? ins.agent.agentId}
                  </span>
                </div>
                <div
                  className="text-lg font-bold font-mono"
                  style={{ color: ins.color }}
                >
                  {ins.value}
                </div>
                <p className="text-[10px] text-muted-foreground mt-1 leading-relaxed">
                  {ins.detail}
                </p>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Historical Sessions List ─────────────────────────────────────────────────

function SessionHistory({
  sessions,
  selectedId,
  onSelect,
}: {
  sessions: ArenaSession[];
  selectedId: string | null;
  onSelect: (id: string | null) => void;
}) {
  if (sessions.length === 0) return null;

  return (
    <Card
      className="border-0"
      style={{
        background: "rgba(10,14,26,0.7)",
        border: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
          <Award className="w-4 h-4 text-cyan-400" />
          Historical Sessions
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {sessions.map((s, idx) => {
          const best = [...s.results].sort(
            (a, b) => b.totalReturnPct - a.totalReturnPct,
          )[0];
          const winner = best
            ? (AGENT_PROFILES[best.agentId]?.label ?? best.agentId)
            : "—";
          const winnerColor = best
            ? (AGENT_PROFILES[best.agentId]?.color ?? "#64748b")
            : "#64748b";
          const isSelected = selectedId === s.sessionId;
          return (
            <button
              type="button"
              key={s.sessionId}
              className={cn(
                "w-full text-left p-3 rounded-lg border transition-smooth",
                isSelected
                  ? "border-cyan-500/30"
                  : "border-border/20 hover:border-border/40",
              )}
              style={{
                background: isSelected
                  ? "rgba(0,240,255,0.05)"
                  : "rgba(255,255,255,0.01)",
              }}
              onClick={() => onSelect(isSelected ? null : s.sessionId)}
              data-ocid={`arena.session.item.${idx + 1}`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span
                    className="text-sm font-mono font-semibold"
                    style={{ color: "#22d3ee" }}
                  >
                    {s.symbol}
                  </span>
                  <Badge
                    variant="outline"
                    className="text-[9px] border-border/30 text-muted-foreground"
                  >
                    {s.results.length} agents
                  </Badge>
                </div>
                {best && (
                  <div className="flex items-center gap-1.5">
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{ background: winnerColor }}
                    />
                    <span
                      className="text-xs font-mono"
                      style={{ color: winnerColor }}
                    >
                      {winner}
                    </span>
                    <span
                      className={cn(
                        "text-xs font-mono font-bold",
                        best.totalReturnPct >= 0
                          ? "text-green-400"
                          : "text-red-400",
                      )}
                    >
                      {best.totalReturnPct >= 0 ? "+" : ""}
                      {best.totalReturnPct.toFixed(1)}%
                    </span>
                  </div>
                )}
              </div>
              <div className="text-[10px] font-mono text-muted-foreground mt-1">
                {s.startDate} → {s.endDate}
              </div>
            </button>
          );
        })}
      </CardContent>
    </Card>
  );
}

// ─── Full Session Results View ─────────────────────────────────────────────────

function SessionResultsView({ session }: { session: ArenaSession }) {
  return (
    <div className="space-y-5" data-ocid="arena.session_results.panel">
      <div className="flex items-center gap-3">
        <Trophy className="w-5 h-5 text-amber-400" />
        <div>
          <h2 className="text-base font-bold font-mono">
            {session.symbol} Competition Results
          </h2>
          <p className="text-xs text-muted-foreground font-mono">
            {session.startDate} → {session.endDate} · Capital: $
            {session.initialCapital.toLocaleString()}
          </p>
        </div>
      </div>

      <BestPerformerInsights results={session.results} />

      <LeaderboardTable
        results={session.results}
        title="Overall Leaderboard"
        subtitle="Ranked by total return percentage"
        sortKey="totalReturnPct"
        icon={Trophy}
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <LeaderboardTable
          results={session.results}
          title="Risk-Adjusted Ranking"
          subtitle="Ranked by Sharpe ratio — return per unit of risk"
          sortKey="sharpeRatio"
          icon={Target}
          highlightFirst={false}
        />
        <LeaderboardTable
          results={session.results}
          title="Consistency Ranking"
          subtitle="Ranked by lowest max drawdown — most stable agent"
          sortKey="maxDrawdownPct"
          ascending={true}
          icon={Shield}
          highlightFirst={false}
        />
      </div>

      <RegimeBreakdownSection results={session.results} />
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function Arena() {
  const { data: sessions, isLoading } = useArenaSessions();
  const startArena = useStartArena();
  const [selectedSession, setSelectedSession] = useState<string | null>(null);
  const { data: sessionDetail, isLoading: isLoadingDetail } = useArenaResults(
    selectedSession ?? "",
  );

  const defaultEnd = new Date().toISOString().split("T")[0];
  const defaultStart = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
    .toISOString()
    .split("T")[0];

  const [form, setForm] = useState({
    symbol: "BTC",
    startDate: defaultStart,
    endDate: defaultEnd,
  });

  const handleStart = async () => {
    try {
      await startArena.mutateAsync(form);
      toast.success("Arena competition launched — 6 agents are competing!");
    } catch {
      toast.error("Failed to launch arena competition");
    }
  };

  const latestSession =
    sessions && sessions.length > 0
      ? [...sessions].sort(
          (a, b) => Number(b.completedAt) - Number(a.completedAt),
        )[0]
      : null;

  const displaySession =
    selectedSession && sessionDetail
      ? sessionDetail
      : selectedSession === null && latestSession
        ? latestSession
        : null;

  return (
    <Layout>
      <div className="p-6 space-y-6" data-ocid="arena.page">
        {/* ── Header ── */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold font-mono flex items-center gap-2.5">
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center"
                style={{
                  background: "rgba(251,191,36,0.15)",
                  border: "1px solid rgba(251,191,36,0.3)",
                }}
              >
                <Swords className="w-4 h-4 text-amber-400" />
              </div>
              Strategy Competition Arena
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Fair head-to-head AI agent benchmarking — same market data, same
              conditions, same fees &amp; slippage
            </p>
          </div>
          {sessions && sessions.length > 0 && (
            <Badge
              className="text-xs font-mono"
              style={{
                background: "rgba(34,211,238,0.1)",
                border: "1px solid rgba(34,211,238,0.25)",
                color: "#22d3ee",
              }}
            >
              {sessions.length} session{sessions.length !== 1 ? "s" : ""}{" "}
              completed
            </Badge>
          )}
        </div>

        {/* ── Agent Profiles Grid ── */}
        <div>
          <div className="text-[11px] font-mono uppercase tracking-widest text-muted-foreground mb-3">
            Competing Agents
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
            {AGENT_ORDER.map((id) => (
              <AgentCard key={id} agentId={id} />
            ))}
          </div>
        </div>

        {/* ── Launch Panel + Session History ── */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Launch Form */}
          <Card
            className="border-0"
            style={{
              background: "rgba(0,240,255,0.03)",
              border: "1px solid rgba(0,240,255,0.12)",
            }}
          >
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-mono uppercase tracking-wider flex items-center gap-2">
                <Play className="w-4 h-4 text-cyan-400" />
                Launch Competition
              </CardTitle>
              <p className="text-xs text-muted-foreground">
                All 6 agents will receive identical data — same timestamps, same
                conditions
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-mono text-muted-foreground">
                  Symbol
                </Label>
                <Input
                  value={form.symbol}
                  onChange={(e) =>
                    setForm((f) => ({
                      ...f,
                      symbol: e.target.value.toUpperCase(),
                    }))
                  }
                  className="font-mono text-sm h-8"
                  placeholder="BTC"
                  data-ocid="arena.symbol_input"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-mono text-muted-foreground">
                  Start Date
                </Label>
                <Input
                  type="date"
                  value={form.startDate}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, startDate: e.target.value }))
                  }
                  className="font-mono text-sm h-8"
                  data-ocid="arena.start_date_input"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-mono text-muted-foreground">
                  End Date
                </Label>
                <Input
                  type="date"
                  value={form.endDate}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, endDate: e.target.value }))
                  }
                  className="font-mono text-sm h-8"
                  data-ocid="arena.end_date_input"
                />
              </div>

              <Button
                className="w-full gap-2"
                style={{
                  background: startArena.isPending
                    ? "rgba(0,240,255,0.1)"
                    : "rgba(0,240,255,0.9)",
                  color: "#0a0e1a",
                  border: "1px solid rgba(0,240,255,0.4)",
                }}
                onClick={handleStart}
                disabled={startArena.isPending}
                data-ocid="arena.launch_button"
              >
                {startArena.isPending ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span className="text-sm font-mono">
                      Simulation running…
                    </span>
                  </>
                ) : (
                  <>
                    <Swords className="w-3.5 h-3.5" />
                    <span className="text-sm font-mono">
                      Launch Competition
                    </span>
                  </>
                )}
              </Button>

              {startArena.isPending && (
                <div
                  className="rounded-lg p-3 text-center"
                  style={{
                    background: "rgba(0,240,255,0.05)",
                    border: "1px solid rgba(0,240,255,0.15)",
                  }}
                  data-ocid="arena.simulation.loading_state"
                >
                  <Loader2 className="w-6 h-6 text-cyan-400 animate-spin mx-auto mb-2" />
                  <p className="text-xs font-mono text-cyan-400">
                    Replaying market data…
                  </p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">
                    6 agents competing through identical conditions
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Session History */}
          <div className="lg:col-span-2">
            {isLoading ? (
              <div
                className="space-y-2"
                data-ocid="arena.sessions.loading_state"
              >
                {Array.from({ length: 4 }, (_, i) => `sk-${i}`).map((k) => (
                  <Skeleton key={k} className="h-14 w-full" />
                ))}
              </div>
            ) : !sessions || sessions.length === 0 ? (
              <Card
                className="border-0 h-full"
                style={{
                  background: "rgba(10,14,26,0.5)",
                  border: "1px solid rgba(255,255,255,0.06)",
                }}
              >
                <CardContent className="flex flex-col items-center justify-center py-16">
                  <div
                    className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4"
                    style={{
                      background: "rgba(251,191,36,0.08)",
                      border: "1px solid rgba(251,191,36,0.2)",
                    }}
                    data-ocid="arena.sessions.empty_state"
                  >
                    <Trophy className="w-8 h-8 text-amber-400 opacity-60" />
                  </div>
                  <h3 className="text-sm font-mono font-bold mb-1">
                    No competitions yet
                  </h3>
                  <p className="text-xs text-muted-foreground text-center max-w-xs">
                    Launch your first arena session to see 6 AI agents compete
                    head-to-head through identical historical market data
                  </p>
                </CardContent>
              </Card>
            ) : (
              <SessionHistory
                sessions={sessions}
                selectedId={selectedSession}
                onSelect={setSelectedSession}
              />
            )}
          </div>
        </div>

        {/* ── Session Results ── */}
        {isLoadingDetail && selectedSession && (
          <div className="space-y-3" data-ocid="arena.results.loading_state">
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-48 w-full" />
            <Skeleton className="h-64 w-full" />
          </div>
        )}

        {displaySession && !isLoadingDetail && (
          <SessionResultsView session={displaySession} />
        )}

        {/* ── Disclaimer ── */}
        <div
          className="p-4 rounded-xl text-xs text-muted-foreground leading-relaxed"
          style={{
            background: "rgba(255,255,255,0.02)",
            border: "1px solid rgba(255,255,255,0.05)",
          }}
        >
          <strong className="text-foreground">Disclaimer:</strong> All arena
          results are simulated using historical paper trading with identical
          fees, slippage, and latency assumptions per agent. Past simulated
          performance does not guarantee future live results. Cryptocurrency
          trading involves substantial risk and may result in loss of capital.
        </div>
      </div>
    </Layout>
  );
}
