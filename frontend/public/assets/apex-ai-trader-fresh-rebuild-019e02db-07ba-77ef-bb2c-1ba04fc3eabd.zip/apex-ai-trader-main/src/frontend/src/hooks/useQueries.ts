import { createActor } from "@/backend";
import type { RiskSettings as BackendRiskSettings } from "@/backend";
import type { AIDecisionLogFull } from "@/types";
import type {
  AIStatus,
  AITrainingState,
  ArenaSession,
  AssetBalance,
  BacktestSession,
  ExchangeStatus,
  MarketCondition,
  MarketSnapshot,
  NoTradeDecision,
  OrderRecord,
  Portfolio,
  Position,
  RiskEvent,
  RiskSettings,
  RiskStatus,
  StrategyPerformance,
  StrategyPerformanceByRegime,
  Trade,
  TradeSnapshot,
} from "@/types";
import { useActor } from "@caffeineai/core-infrastructure";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

export function useMarketSnapshot() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<MarketSnapshot | null>({
    queryKey: ["marketSnapshot"],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getLatestSnapshot();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 30_000,
  });
}

export function useMarketCondition() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<MarketCondition | null>({
    queryKey: ["marketCondition"],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getCurrentMarketCondition();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 60_000,
  });
}

export function usePortfolio() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<Portfolio>({
    queryKey: ["portfolio"],
    queryFn: async () => {
      if (!actor)
        return {
          totalTrades: 0n,
          dayPnl: 0,
          dayPnlPercent: 0,
          totalValue: 10000,
          totalPnl: 0,
          cashBalance: 10000,
          winningTrades: 0n,
          positions: [],
          winRate: 0,
          totalPnlPercent: 0,
          investedValue: 0,
        } as Portfolio;
      return actor.getPortfolio();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 15_000,
  });
}

export function useOpenPositions() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<Position[]>({
    queryKey: ["openPositions"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getOpenPositions();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 15_000,
  });
}

export function useTradeHistory(limit = 50n) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<Trade[]>({
    queryKey: ["tradeHistory", limit.toString()],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getTradeHistory(limit);
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 30_000,
  });
}

export function useAIStatus() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<AIStatus>({
    queryKey: ["aiStatus"],
    queryFn: async () => {
      if (!actor)
        return {
          mode: "Offline",
          lastRunTime: 0n,
          nextRunTime: 0n,
          isRunning: false,
          cycleCount: 0n,
        };
      return actor.getAIStatus();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 10_000,
  });
}

export function useLatestDecisions(limit = 20n) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<AIDecisionLogFull[]>({
    queryKey: ["latestDecisions", limit.toString()],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getLatestDecisions(limit) as unknown as AIDecisionLogFull[];
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 15_000,
  });
}

export function useRiskStatus() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<RiskStatus>({
    queryKey: ["riskStatus"],
    queryFn: async () => {
      if (!actor)
        return {
          dailyLoss: 0,
          isPaused: false,
          consecutiveLosses: 0n,
          riskScore: 0,
          dailyLossPercent: 0,
        };
      return actor.getRiskStatus();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 10_000,
  });
}

export function useRiskSettings() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<RiskSettings>({
    queryKey: ["riskSettings"],
    queryFn: async () => {
      if (!actor)
        return {
          conservativeMode: true,
          maxConsecutiveLosses: 3n,
          enablePaperTrading: true,
          emergencyStopEnabled: false,
          maxDailyLossPercent: 5,
          maxPositionSizePercent: 2,
        };
      return actor.getRiskSettings();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useRiskEvents(limit = 20n) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<RiskEvent[]>({
    queryKey: ["riskEvents", limit.toString()],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getRiskEvents(limit);
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 30_000,
  });
}

export function useStrategyPerformances() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<StrategyPerformance[]>({
    queryKey: ["strategyPerformances"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getStrategyPerformances();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 60_000,
  });
}

export function useAITrainingState() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<AITrainingState>({
    queryKey: ["aiTrainingState"],
    queryFn: async () => {
      if (!actor)
        return {
          lastTrainingUpdate: 0n,
          avgConfidenceScore: 0,
          strategyPerformances: [],
          overallWinRate: 0,
          learningProgress: 0,
          confidenceCalibration: 0,
          practiceTradesCount: 0n,
          totalSessions: 0n,
          marketMemory: [],
          noTradeLog: [],
          correlationData: [],
          confidenceThreshold: 65,
          overtradingCount: 0n,
          consecutiveLosses: 0n,
        };
      return actor.getAITrainingState();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 60_000,
  });
}

export function useNoTradeLog() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<NoTradeDecision[]>({
    queryKey: ["noTradeLog"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getNoTradeLog();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 60_000,
  });
}

export function useMarketMemory() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<StrategyPerformanceByRegime[]>({
    queryKey: ["marketMemory"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getMarketMemory();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 120_000,
  });
}

export function useTopSetups() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<StrategyPerformanceByRegime[]>({
    queryKey: ["topSetups"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getTopSetups();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 120_000,
  });
}

export function useTradeSnapshot(tradeId: string) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<TradeSnapshot | null>({
    queryKey: ["tradeSnapshot", tradeId],
    queryFn: async () => {
      if (!actor || !tradeId) return null;
      return actor.getTradeSnapshot(tradeId);
    },
    enabled: !!actor && !isFetching && !!tradeId,
  });
}

export function useArenaSessions() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<ArenaSession[]>({
    queryKey: ["arenaSessions"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getArenaSessions();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 30_000,
  });
}

export function useArenaResults(sessionId: string) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<ArenaSession | null>({
    queryKey: ["arenaResults", sessionId],
    queryFn: async () => {
      if (!actor || !sessionId) return null;
      return actor.getArenaResults(sessionId);
    },
    enabled: !!actor && !isFetching && !!sessionId,
  });
}

export function useStartArena() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      symbol: string;
      startDate: string;
      endDate: string;
    }) => {
      if (!actor) throw new Error("Actor not ready");
      return actor.startArena(params.symbol, params.startDate, params.endDate);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["arenaSessions"] });
    },
  });
}

export function useExchangeConnections() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<ExchangeStatus[]>({
    queryKey: ["exchangeConnections"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getExchangeConnections();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 30_000,
  });
}

export function useSaveExchangeConnection() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      exchangeId: string;
      apiKey: string;
      apiSecret: string;
    }) => {
      if (!actor) throw new Error("Actor not ready");
      return actor.saveExchangeConnection(
        params.exchangeId,
        params.apiKey,
        params.apiSecret,
      );
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["exchangeConnections"] });
    },
  });
}

export function useRemoveExchangeConnection() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (exchangeId: string) => {
      if (!actor) throw new Error("Actor not ready");
      return actor.removeExchangeConnection(exchangeId);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["exchangeConnections"] });
    },
  });
}

export function useTestExchangeConnection() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (exchangeId: string) => {
      if (!actor) throw new Error("Actor not ready");
      return actor.testExchangeConnection(exchangeId);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["exchangeConnections"] });
    },
  });
}

export function useExchangeBalances(exchangeId: string) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<AssetBalance[]>({
    queryKey: ["exchangeBalances", exchangeId],
    queryFn: async () => {
      if (!actor || !exchangeId) return [];
      return actor.getExchangeBalances(exchangeId);
    },
    enabled: !!actor && !isFetching && !!exchangeId,
    refetchInterval: 30_000,
  });
}

export function useExchangeOrderHistory(exchangeId: string) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<OrderRecord[]>({
    queryKey: ["exchangeOrderHistory", exchangeId],
    queryFn: async () => {
      if (!actor || !exchangeId) return [];
      return actor.getExchangeOrderHistory(exchangeId);
    },
    enabled: !!actor && !isFetching && !!exchangeId,
    refetchInterval: 60_000,
  });
}

export function useBacktestSessions() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<BacktestSession[]>({
    queryKey: ["backtestSessions"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.listBacktestSessions();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useClosePosition() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (symbol: string) => {
      if (!actor) throw new Error("Actor not ready");
      const result = await actor.closePosition(symbol);
      if (result.__kind__ === "err") throw new Error(result.err);
      return (result as { __kind__: "ok"; ok: Trade }).ok;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["openPositions"] });
      qc.invalidateQueries({ queryKey: ["tradeHistory"] });
      qc.invalidateQueries({ queryKey: ["portfolio"] });
    },
  });
}

export function useEmergencyStop() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Actor not ready");
      return actor.triggerEmergencyStop();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["riskStatus"] });
      qc.invalidateQueries({ queryKey: ["aiStatus"] });
    },
  });
}

export function useResumeTrading() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Actor not ready");
      return actor.resumeTrading();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["riskStatus"] });
      qc.invalidateQueries({ queryKey: ["aiStatus"] });
    },
  });
}

export function useRunAIAnalysis() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Actor not ready");
      return actor.runAIAnalysis();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["latestDecisions"] });
      qc.invalidateQueries({ queryKey: ["portfolio"] });
    },
  });
}

export function useExecutePendingDecisions() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Actor not ready");
      return actor.executePendingDecisions();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["openPositions"] });
      qc.invalidateQueries({ queryKey: ["portfolio"] });
      qc.invalidateQueries({ queryKey: ["latestDecisions"] });
    },
  });
}

export function useUpdateRiskSettings() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (settings: BackendRiskSettings) => {
      if (!actor) throw new Error("Actor not ready");
      return actor.updateRiskSettings(settings);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["riskSettings"] });
    },
  });
}

export function useStartBacktest() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      name: string;
      symbols: string[];
      startDate: bigint;
      endDate: bigint;
      initialBalance: number;
    }) => {
      if (!actor) throw new Error("Actor not ready");
      return actor.startBacktest(
        params.name,
        params.symbols,
        params.startDate,
        params.endDate,
        params.initialBalance,
      );
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["backtestSessions"] });
    },
  });
}

export function useRefreshMarketData() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Actor not ready");
      return actor.refreshGlobalData();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["marketSnapshot"] });
      qc.invalidateQueries({ queryKey: ["marketCondition"] });
    },
  });
}

export function useResetTrainingData() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Actor not ready");
      return actor.resetTrainingData();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["aiTrainingState"] });
    },
  });
}

// ─── Bot Control Hooks ────────────────────────────────────────────────────────

export function useBotState() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["botState"],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getBotState();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 5_000,
  });
}

export function useBotConfig() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["botConfig"],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getBotConfig();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useDataFeedStatus() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["dataFeedStatus"],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getDataFeedStatus();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 10_000,
  });
}

export function useStartBot() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Actor not ready");
      return actor.startBot();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["botState"] });
    },
  });
}

export function usePauseBot() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Actor not ready");
      return actor.pauseBot();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["botState"] });
    },
  });
}

export function useResumeBot() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Actor not ready");
      return actor.resumeBot();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["botState"] });
    },
  });
}

export function useEmergencyStopBot() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Actor not ready");
      return actor.emergencyStopBot();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["botState"] });
      qc.invalidateQueries({ queryKey: ["riskStatus"] });
    },
  });
}

export function useResetBot() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Actor not ready");
      return actor.resetBot();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["botState"] });
      qc.invalidateQueries({ queryKey: ["portfolio"] });
    },
  });
}

export function useRunMarketCycle() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Actor not ready");
      return actor.runMarketCycle();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["dataFeedStatus"] });
      qc.invalidateQueries({ queryKey: ["marketSnapshot"] });
    },
  });
}

export function useRunDecisionCycle() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Actor not ready");
      return actor.runDecisionCycle();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["liveActivityFeed"] });
      qc.invalidateQueries({ queryKey: ["openPositions"] });
      qc.invalidateQueries({ queryKey: ["decisionCycleStats"] });
      qc.invalidateQueries({ queryKey: ["botState"] });
    },
  });
}

export function useUpdateBotConfig() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (cfg: import("@/backend").BotConfig) => {
      if (!actor) throw new Error("Actor not ready");
      return actor.updateBotConfig(cfg);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["botConfig"] });
    },
  });
}

export function useEquityHistory(limit: bigint) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["equityHistory", limit.toString()],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getEquityHistory(limit);
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 30_000,
  });
}

export function useCurrentEquity() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["currentEquity"],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getCurrentEquity();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 15_000,
  });
}

export function useLiveActivityFeed(limit: bigint) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["liveActivityFeed", limit.toString()],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getLiveActivityFeed(limit);
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 15_000,
  });
}

export function useDecisionCycleStats() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["decisionCycleStats"],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getDecisionCycleStats();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 60_000,
  });
}

export function useSimulationStats() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["simulationStats"],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getSimulationStats();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 60_000,
  });
}

export function useAllConfidenceTimeline(limit: bigint) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["allConfidenceTimeline", limit.toString()],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllConfidenceTimeline(limit);
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 60_000,
  });
}

export function useMarketCandles(symbol: string, days = 7n) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["marketCandles", symbol, days.toString()],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getHistoricalCandles(symbol, days);
    },
    enabled: !!actor && !isFetching && !!symbol,
    refetchInterval: 60_000,
    staleTime: 55_000,
  });
}

export function useGetRecentDecisions(limit: bigint) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["recentDecisions", limit.toString()],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getRecentDecisions(limit);
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 15_000,
  });
}
