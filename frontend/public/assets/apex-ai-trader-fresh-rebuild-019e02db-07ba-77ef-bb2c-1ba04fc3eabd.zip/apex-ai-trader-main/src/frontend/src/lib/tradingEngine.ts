export type SymbolKey = 'BTC' | 'ETH' | 'SOL' | 'ICP' | 'BNB' | 'XRP' | 'DOGE' | 'AVAX' | 'LINK' | 'ADA';

export type AgentName =
  | 'Momentum Agent'
  | 'Mean Reversion Agent'
  | 'Breakout Agent'
  | 'RSI/MACD Technical Agent'
  | 'Volatility Agent'
  | 'Trend Following Agent'
  | 'Conservative Risk Agent'
  | 'Aggressive Agent'
  | 'Apex Intelligence Core';

export type Side = 'LONG' | 'FLAT';
export type DecisionAction = 'BUY' | 'SELL' | 'HOLD';
export type MarketRegime = 'TRENDING_UP' | 'TRENDING_DOWN' | 'RANGING' | 'HIGH_VOLATILITY' | 'LOW_MOMENTUM';

export interface Candle {
  symbol: SymbolKey;
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface MarketSnapshot {
  symbol: SymbolKey;
  price: number;
  change24h: number;
  volume: number;
  marketCap: number;
  lastUpdated: number;
}

export interface ConfidenceBreakdown {
  trend: number;
  momentum: number;
  volatility: number;
  liquidity: number;
  historicalEdge: number;
  regime: number;
  final: number;
}

export interface AgentDecision {
  agent: AgentName;
  symbol: SymbolKey;
  action: DecisionAction;
  confidence: ConfidenceBreakdown;
  regime: MarketRegime;
  reason: string;
  rejectionReason?: string;
  stopLossPct: number;
  takeProfitPct: number;
  riskReward: number;
  positionSizePct: number;
}

export interface Position {
  id: string;
  agent: AgentName;
  symbol: SymbolKey;
  side: Side;
  entryPrice: number;
  quantity: number;
  entryTime: number;
  stopLoss: number;
  takeProfit: number;
  confidence: number;
  reason: string;
}

export interface Trade {
  id: string;
  agent: AgentName;
  symbol: SymbolKey;
  entryTime: number;
  exitTime: number;
  entryPrice: number;
  exitPrice: number;
  quantity: number;
  pnl: number;
  pnlPct: number;
  fees: number;
  reason: string;
  entryReason: string;
}

export interface AgentState {
  name: AgentName;
  cash: number;
  startingCash: number;
  openPositions: Position[];
  closedTrades: Trade[];
  equityCurve: Array<{ timestamp: number; equity: number }>;
  cooldownUntil: Record<string, number>;
  weight: number;
  disabled: boolean;
}

export interface EventLog {
  id: string;
  timestamp: number;
  level: 'INFO' | 'WARN' | 'TRADE' | 'RISK' | 'AI';
  source: string;
  message: string;
}

export interface EngineState {
  candles: Record<SymbolKey, Candle[]>;
  snapshots: MarketSnapshot[];
  agents: AgentState[];
  logs: EventLog[];
  emergencyStop: boolean;
  liveTradingEnabled: false;
  simulationRunning: boolean;
  tick: number;
}

const SYMBOLS: SymbolKey[] = ['BTC', 'ETH', 'SOL', 'ICP', 'BNB', 'XRP', 'DOGE', 'AVAX', 'LINK', 'ADA'];

const START_PRICES: Record<SymbolKey, number> = {
  BTC: 63500,
  ETH: 3150,
  SOL: 145,
  ICP: 12.5,
  BNB: 590,
  XRP: 0.56,
  DOGE: 0.13,
  AVAX: 35,
  LINK: 14.8,
  ADA: 0.46,
};

const AGENTS: AgentName[] = [
  'Momentum Agent',
  'Mean Reversion Agent',
  'Breakout Agent',
  'RSI/MACD Technical Agent',
  'Volatility Agent',
  'Trend Following Agent',
  'Conservative Risk Agent',
  'Aggressive Agent',
  'Apex Intelligence Core',
];

export const CONFIG = {
  startingBalance: 10_000,
  feePct: 0.001,
  slippagePct: 0.0008,
  spreadPct: 0.0004,
  maxDailyLossPct: 0.05,
  maxPositionPct: 0.18,
  tradeCooldownMs: 60_000,
  minCandles: 35,
  liveTradingEnabled: false as const,
};

function id(prefix = 'id') {
  return `${prefix}_${Math.random().toString(36).slice(2)}_${Date.now().toString(36)}`;
}

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function avg(values: number[]) {
  if (!values.length) return 0;
  return values.reduce((a, b) => a + b, 0) / values.length;
}

function std(values: number[]) {
  const m = avg(values);
  return Math.sqrt(avg(values.map((v) => (v - m) ** 2)));
}

function sma(values: number[], period: number) {
  if (values.length < period) return avg(values);
  return avg(values.slice(-period));
}

function ema(values: number[], period: number) {
  if (!values.length) return 0;
  const k = 2 / (period + 1);
  return values.reduce((prev, price, index) => (index === 0 ? price : price * k + prev * (1 - k)), values[0]);
}

function rsi(closes: number[], period = 14) {
  if (closes.length <= period) return 50;
  const slice = closes.slice(-(period + 1));
  let gains = 0;
  let losses = 0;
  for (let i = 1; i < slice.length; i++) {
    const change = slice[i] - slice[i - 1];
    if (change >= 0) gains += change;
    else losses -= change;
  }
  if (losses === 0) return 100;
  const rs = gains / losses;
  return 100 - 100 / (1 + rs);
}

function atr(candles: Candle[], period = 14) {
  const slice = candles.slice(-period);
  if (slice.length < 2) return 0;
  const trs = slice.map((c, i) => {
    const prevClose = i === 0 ? c.open : slice[i - 1].close;
    return Math.max(c.high - c.low, Math.abs(c.high - prevClose), Math.abs(c.low - prevClose));
  });
  return avg(trs);
}

function macd(closes: number[]) {
  const line = ema(closes, 12) - ema(closes, 26);
  const recentMacd = closes.slice(-18).map((_, i, arr) => {
    const prefix = closes.slice(0, closes.length - arr.length + i + 1);
    return ema(prefix, 12) - ema(prefix, 26);
  });
  const signal = ema(recentMacd, 9);
  return { line, signal, histogram: line - signal };
}

function indicators(candles: Candle[]) {
  const closes = candles.map((c) => c.close);
  const current = closes.at(-1) ?? 0;
  const ema9 = ema(closes, 9);
  const ema21 = ema(closes, 21);
  const ema50 = ema(closes, 50);
  const rsi14 = rsi(closes);
  const macdVal = macd(closes);
  const volatility = atr(candles) / Math.max(current, 1);
  const high20 = Math.max(...candles.slice(-20).map((c) => c.high));
  const low20 = Math.min(...candles.slice(-20).map((c) => c.low));
  const mid20 = sma(closes, 20);
  const sd20 = std(closes.slice(-20));
  const upperBand = mid20 + 2 * sd20;
  const lowerBand = mid20 - 2 * sd20;
  const volumeNow = candles.at(-1)?.volume ?? 0;
  const volumeAvg = avg(candles.slice(-20).map((c) => c.volume));
  const momentum5 = closes.length > 6 ? (current - closes[closes.length - 6]) / closes[closes.length - 6] : 0;
  const momentum20 = closes.length > 21 ? (current - closes[closes.length - 21]) / closes[closes.length - 21] : 0;
  return { current, ema9, ema21, ema50, rsi14, macdVal, volatility, high20, low20, upperBand, lowerBand, volumeNow, volumeAvg, momentum5, momentum20 };
}

function detectRegime(candles: Candle[]): MarketRegime {
  const ind = indicators(candles);
  if (ind.volatility > 0.035) return 'HIGH_VOLATILITY';
  if (Math.abs(ind.momentum20) < 0.006) return 'RANGING';
  if (ind.ema9 > ind.ema21 && ind.ema21 > ind.ema50 && ind.momentum20 > 0.01) return 'TRENDING_UP';
  if (ind.ema9 < ind.ema21 && ind.ema21 < ind.ema50 && ind.momentum20 < -0.01) return 'TRENDING_DOWN';
  return 'LOW_MOMENTUM';
}

function confidence(final: number, overrides: Partial<ConfidenceBreakdown> = {}): ConfidenceBreakdown {
  const base = {
    trend: final,
    momentum: final,
    volatility: final,
    liquidity: 60,
    historicalEdge: 55,
    regime: final,
  };
  const merged = { ...base, ...overrides };
  const weighted = merged.trend * 0.22 + merged.momentum * 0.22 + merged.volatility * 0.14 + merged.liquidity * 0.1 + merged.historicalEdge * 0.16 + merged.regime * 0.16;
  return { ...merged, final: Math.round(clamp(weighted, 0, 100)) };
}

function historicalEdge(agent: AgentState, regime: MarketRegime) {
  const recent = agent.closedTrades.slice(-30);
  if (recent.length < 5) return 55;
  const winRate = recent.filter((t) => t.pnl > 0).length / recent.length;
  const profit = recent.reduce((sum, t) => sum + t.pnl, 0);
  const consistency = clamp(winRate * 70 + (profit > 0 ? 15 : -10), 20, 85);
  return regime === 'HIGH_VOLATILITY' && winRate < 0.5 ? consistency - 10 : consistency;
}

function buildDecision(agent: AgentState, symbol: SymbolKey, candles: Candle[]): AgentDecision {
  const ind = indicators(candles);
  const regime = detectRegime(candles);
  const edge = historicalEdge(agent, regime);
  let action: DecisionAction = 'HOLD';
  let score = 45;
  let reason = 'No high-quality edge detected.';
  let size = 0.06;
  let stopLossPct = 0.025;
  let takeProfitPct = 0.045;

  switch (agent.name) {
    case 'Momentum Agent': {
      score = 50 + ind.momentum5 * 900 + (ind.volumeNow > ind.volumeAvg ? 8 : -5) + (regime === 'TRENDING_UP' ? 12 : 0);
      action = score > 58 ? 'BUY' : ind.momentum5 < -0.012 ? 'SELL' : 'HOLD';
      reason = `Momentum ${Math.round(ind.momentum5 * 10000) / 100}% with volume ${ind.volumeNow > ind.volumeAvg ? 'expansion' : 'below average'}.`;
      break;
    }
    case 'Mean Reversion Agent': {
      const oversold = ind.current < ind.lowerBand || ind.rsi14 < 38;
      const overbought = ind.current > ind.upperBand || ind.rsi14 > 68;
      score = oversold ? 67 : overbought ? 62 : 42;
      action = oversold ? 'BUY' : overbought ? 'SELL' : 'HOLD';
      reason = `RSI ${Math.round(ind.rsi14)} and Bollinger position suggest ${oversold ? 'oversold reversal' : overbought ? 'overbought exit' : 'no reversion edge'}.`;
      takeProfitPct = 0.028;
      stopLossPct = 0.018;
      break;
    }
    case 'Breakout Agent': {
      const breakout = ind.current >= ind.high20 * 0.998 && ind.volumeNow > ind.volumeAvg * 1.05;
      score = breakout ? 72 : ind.current <= ind.low20 * 1.005 ? 60 : 40;
      action = breakout ? 'BUY' : ind.current <= ind.low20 * 1.005 ? 'SELL' : 'HOLD';
      reason = breakout ? 'Price is pressing 20-candle highs with volume confirmation.' : 'No confirmed breakout.';
      takeProfitPct = 0.06;
      stopLossPct = 0.028;
      break;
    }
    case 'RSI/MACD Technical Agent': {
      const bullish = ind.rsi14 > 45 && ind.rsi14 < 70 && ind.macdVal.histogram > 0 && ind.ema9 > ind.ema21;
      const bearish = ind.rsi14 > 72 || ind.macdVal.histogram < -0.4;
      score = bullish ? 70 : bearish ? 64 : 44;
      action = bullish ? 'BUY' : bearish ? 'SELL' : 'HOLD';
      reason = `RSI ${Math.round(ind.rsi14)}, MACD histogram ${ind.macdVal.histogram.toFixed(2)}, EMA alignment ${ind.ema9 > ind.ema21 ? 'bullish' : 'weak'}.`;
      break;
    }
    case 'Volatility Agent': {
      const controlledExpansion = ind.volatility > 0.012 && ind.volatility < 0.035 && ind.momentum5 > 0.004;
      score = controlledExpansion ? 68 : ind.volatility > 0.04 ? 65 : 41;
      action = controlledExpansion ? 'BUY' : ind.volatility > 0.04 ? 'SELL' : 'HOLD';
      reason = `ATR volatility ${(ind.volatility * 100).toFixed(2)}%; ${controlledExpansion ? 'tradable expansion' : 'waiting for cleaner volatility'}.`;
      stopLossPct = clamp(ind.volatility * 1.8, 0.018, 0.055);
      takeProfitPct = stopLossPct * 1.9;
      break;
    }
    case 'Trend Following Agent': {
      const uptrend = ind.ema9 > ind.ema21 && ind.ema21 > ind.ema50 && ind.current > ind.ema9;
      score = uptrend ? 75 : ind.ema9 < ind.ema21 ? 60 : 43;
      action = uptrend ? 'BUY' : ind.ema9 < ind.ema21 ? 'SELL' : 'HOLD';
      reason = `EMA stack ${uptrend ? 'bullish' : 'not bullish'}; regime ${regime}.`;
      takeProfitPct = 0.075;
      stopLossPct = 0.035;
      break;
    }
    case 'Conservative Risk Agent': {
      const clean = regime === 'TRENDING_UP' && ind.rsi14 < 65 && ind.volatility < 0.025;
      score = clean ? 76 : 38;
      action = clean ? 'BUY' : 'HOLD';
      reason = clean ? 'Clean trend, moderate RSI, and controlled volatility.' : 'Conservative filter rejected trade.';
      size = 0.035;
      stopLossPct = 0.018;
      takeProfitPct = 0.035;
      break;
    }
    case 'Aggressive Agent': {
      const trigger = ind.momentum5 > 0.003 || ind.rsi14 < 35 || ind.current > ind.high20 * 0.995;
      score = trigger ? 63 : 45;
      action = trigger ? 'BUY' : ind.momentum5 < -0.01 ? 'SELL' : 'HOLD';
      reason = 'Aggressive agent is willing to act on earlier momentum/reversal signals.';
      size = 0.12;
      stopLossPct = 0.04;
      takeProfitPct = 0.085;
      break;
    }
    case 'Apex Intelligence Core': {
      const trend = ind.ema9 > ind.ema21 && ind.momentum20 > 0 ? 70 : 42;
      const momentum = ind.momentum5 > 0 ? 62 + ind.momentum5 * 500 : 42;
      const vol = ind.volatility < 0.035 ? 65 : 35;
      score = trend * 0.35 + momentum * 0.3 + vol * 0.2 + edge * 0.15;
      action = score > 61 && regime !== 'HIGH_VOLATILITY' ? 'BUY' : score < 42 ? 'SELL' : 'HOLD';
      reason = `Meta-agent blended trend, momentum, volatility and historical edge. Current regime: ${regime}.`;
      size = 0.07;
      break;
    }
  }

  const conf = confidence(score, {
    trend: clamp(ind.ema9 > ind.ema21 ? score + 8 : score - 8, 0, 100),
    momentum: clamp(50 + ind.momentum5 * 900, 0, 100),
    volatility: clamp(75 - ind.volatility * 1000, 10, 90),
    liquidity: clamp(ind.volumeNow / Math.max(ind.volumeAvg, 1) * 55, 25, 88),
    historicalEdge: edge,
    regime: regime === 'HIGH_VOLATILITY' ? 35 : regime === 'TRENDING_UP' ? 75 : 55,
  });

  const threshold = agent.name === 'Aggressive Agent' ? 56 : agent.name === 'Conservative Risk Agent' ? 70 : 60;
  if (action === 'BUY' && conf.final < threshold) {
    return { agent: agent.name, symbol, action: 'HOLD', confidence: conf, regime, reason, rejectionReason: `Confidence ${conf.final} below ${threshold} threshold.`, stopLossPct, takeProfitPct, riskReward: takeProfitPct / stopLossPct, positionSizePct: size };
  }

  return { agent: agent.name, symbol, action, confidence: conf, regime, reason, stopLossPct, takeProfitPct, riskReward: takeProfitPct / stopLossPct, positionSizePct: size };
}

function createInitialCandles(symbol: SymbolKey, count = 70): Candle[] {
  let price = START_PRICES[symbol];
  const now = Date.now() - count * 60_000;
  const candles: Candle[] = [];
  for (let i = 0; i < count; i++) {
    const drift = Math.sin(i / 9) * 0.002 + (Math.random() - 0.48) * 0.012;
    const open = price;
    price = Math.max(price * (1 + drift), 0.0001);
    const close = price;
    const high = Math.max(open, close) * (1 + Math.random() * 0.004);
    const low = Math.min(open, close) * (1 - Math.random() * 0.004);
    const volume = 1_000_000 + Math.random() * 9_000_000;
    candles.push({ symbol, timestamp: now + i * 60_000, open, high, low, close, volume });
  }
  return candles;
}

export function createInitialState(): EngineState {
  const candles = Object.fromEntries(SYMBOLS.map((s) => [s, createInitialCandles(s)])) as Record<SymbolKey, Candle[]>;
  const snapshots = SYMBOLS.map((symbol) => {
    const c = candles[symbol].at(-1)!;
    const first = candles[symbol].at(-24)!;
    return { symbol, price: c.close, change24h: ((c.close - first.close) / first.close) * 100, volume: c.volume, marketCap: c.close * 1_000_000_000, lastUpdated: c.timestamp };
  });
  return {
    candles,
    snapshots,
    agents: AGENTS.map((name) => ({ name, cash: CONFIG.startingBalance, startingCash: CONFIG.startingBalance, openPositions: [], closedTrades: [], equityCurve: [{ timestamp: Date.now(), equity: CONFIG.startingBalance }], cooldownUntil: {}, weight: name === 'Apex Intelligence Core' ? 1.3 : 1, disabled: false })),
    logs: [{ id: id('log'), timestamp: Date.now(), level: 'INFO', source: 'System', message: 'Apex AI Trader initialized in simulation-first mode. Live trading disabled.' }],
    emergencyStop: false,
    liveTradingEnabled: false,
    simulationRunning: true,
    tick: 0,
  };
}

export async function fetchLiveMarketSnapshots(): Promise<MarketSnapshot[] | null> {
  const ids = 'bitcoin,ethereum,solana,internet-computer,binancecoin,ripple,dogecoin,avalanche-2,chainlink,cardano';
  const map: Record<string, SymbolKey> = {
    bitcoin: 'BTC', ethereum: 'ETH', solana: 'SOL', 'internet-computer': 'ICP', binancecoin: 'BNB', ripple: 'XRP', dogecoin: 'DOGE', 'avalanche-2': 'AVAX', chainlink: 'LINK', cardano: 'ADA'
  };
  try {
    const res = await fetch(`https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${ids}&order=market_cap_desc&per_page=10&page=1&sparkline=false&price_change_percentage=24h`, { cache: 'no-store' });
    if (!res.ok) throw new Error(`CoinGecko ${res.status}`);
    const data = await res.json();
    return data.map((coin: any) => ({ symbol: map[coin.id], price: coin.current_price, change24h: coin.price_change_percentage_24h ?? 0, volume: coin.total_volume ?? 0, marketCap: coin.market_cap ?? 0, lastUpdated: Date.now() })).filter((x: MarketSnapshot) => x.symbol);
  } catch {
    return null;
  }
}

function appendMarketTick(state: EngineState, live?: MarketSnapshot[] | null): EngineState {
  const candles: Record<SymbolKey, Candle[]> = { ...state.candles };
  const snapshots: MarketSnapshot[] = [];
  for (const symbol of SYMBOLS) {
    const existing = candles[symbol];
    const last = existing.at(-1)!;
    const livePrice = live?.find((s) => s.symbol === symbol)?.price;
    const change = livePrice ? livePrice / last.close - 1 : Math.sin((state.tick + symbol.length) / 12) * 0.004 + (Math.random() - 0.48) * 0.015;
    const close = livePrice ?? Math.max(last.close * (1 + change), 0.0001);
    const open = last.close;
    const spread = Math.abs(close - open) + close * (0.002 + Math.random() * 0.005);
    const high = Math.max(open, close) + spread * Math.random();
    const low = Math.max(0.0001, Math.min(open, close) - spread * Math.random());
    const liveSnap = live?.find((s) => s.symbol === symbol);
    const volume = liveSnap?.volume ?? Math.max(250_000, last.volume * (0.92 + Math.random() * 0.18));
    const c = { symbol, timestamp: Date.now(), open, high, low, close, volume };
    candles[symbol] = [...existing.slice(-199), c];
    const dayAgo = candles[symbol].at(-60) ?? candles[symbol][0];
    snapshots.push({ symbol, price: close, change24h: liveSnap?.change24h ?? ((close - dayAgo.close) / dayAgo.close) * 100, volume, marketCap: liveSnap?.marketCap ?? close * 1_000_000_000, lastUpdated: c.timestamp });
  }
  return { ...state, candles, snapshots, tick: state.tick + 1 };
}

function equity(agent: AgentState, snapshots: MarketSnapshot[]) {
  return agent.cash + agent.openPositions.reduce((sum, p) => sum + p.quantity * (snapshots.find((s) => s.symbol === p.symbol)?.price ?? p.entryPrice), 0);
}

function riskAllows(agent: AgentState, decision: AgentDecision, state: EngineState) {
  if (state.emergencyStop) return 'Emergency stop is enabled.';
  if (agent.disabled) return 'Agent disabled.';
  const now = Date.now();
  if ((agent.cooldownUntil[decision.symbol] ?? 0) > now) return 'Asset cooldown active.';
  const open = agent.openPositions.find((p) => p.symbol === decision.symbol);
  if (decision.action === 'BUY' && open) return 'Already has open position.';
  const eq = equity(agent, state.snapshots);
  const dailyPnl = eq - agent.startingCash;
  if (dailyPnl / agent.startingCash < -CONFIG.maxDailyLossPct) return 'Daily loss limit reached.';
  if (decision.regime === 'HIGH_VOLATILITY' && decision.agent !== 'Volatility Agent' && decision.agent !== 'Aggressive Agent') return 'High-volatility risk filter blocked entry.';
  return null;
}

function executeBuy(agent: AgentState, decision: AgentDecision, price: number) {
  const eq = agent.cash + agent.openPositions.reduce((sum, p) => sum + p.quantity * price, 0);
  const notional = Math.min(agent.cash * 0.95, eq * clamp(decision.positionSizePct, 0.015, CONFIG.maxPositionPct));
  const fill = price * (1 + CONFIG.slippagePct + CONFIG.spreadPct / 2);
  const fee = notional * CONFIG.feePct;
  const quantity = (notional - fee) / fill;
  const position: Position = { id: id('pos'), agent: agent.name, symbol: decision.symbol, side: 'LONG', entryPrice: fill, quantity, entryTime: Date.now(), stopLoss: fill * (1 - decision.stopLossPct), takeProfit: fill * (1 + decision.takeProfitPct), confidence: decision.confidence.final, reason: decision.reason };
  return { ...agent, cash: agent.cash - notional, openPositions: [...agent.openPositions, position], cooldownUntil: { ...agent.cooldownUntil, [decision.symbol]: Date.now() + CONFIG.tradeCooldownMs } };
}

function closePosition(agent: AgentState, position: Position, price: number, reason: string) {
  const fill = price * (1 - CONFIG.slippagePct - CONFIG.spreadPct / 2);
  const gross = fill * position.quantity;
  const fees = gross * CONFIG.feePct;
  const proceeds = gross - fees;
  const cost = position.entryPrice * position.quantity;
  const pnl = proceeds - cost;
  const trade: Trade = { id: id('trade'), agent: agent.name, symbol: position.symbol, entryTime: position.entryTime, exitTime: Date.now(), entryPrice: position.entryPrice, exitPrice: fill, quantity: position.quantity, pnl, pnlPct: pnl / cost * 100, fees, reason, entryReason: position.reason };
  return { ...agent, cash: agent.cash + proceeds, openPositions: agent.openPositions.filter((p) => p.id !== position.id), closedTrades: [trade, ...agent.closedTrades].slice(0, 500), cooldownUntil: { ...agent.cooldownUntil, [position.symbol]: Date.now() + CONFIG.tradeCooldownMs } };
}

function updateAgent(agent: AgentState, state: EngineState): { agent: AgentState; logs: EventLog[]; decisions: AgentDecision[] } {
  let next = agent;
  const logs: EventLog[] = [];
  const decisions: AgentDecision[] = [];

  for (const p of [...next.openPositions]) {
    const snap = state.snapshots.find((s) => s.symbol === p.symbol);
    if (!snap) continue;
    if (snap.price <= p.stopLoss) {
      next = closePosition(next, p, snap.price, 'Stop-loss hit');
      logs.push({ id: id('log'), timestamp: Date.now(), level: 'TRADE', source: next.name, message: `Closed ${p.symbol} at stop-loss. P&L ${next.closedTrades[0].pnl.toFixed(2)}` });
    } else if (snap.price >= p.takeProfit) {
      next = closePosition(next, p, snap.price, 'Take-profit hit');
      logs.push({ id: id('log'), timestamp: Date.now(), level: 'TRADE', source: next.name, message: `Closed ${p.symbol} at take-profit. P&L ${next.closedTrades[0].pnl.toFixed(2)}` });
    }
  }

  for (const symbol of SYMBOLS.slice(0, 8)) {
    const candles = state.candles[symbol];
    if (!candles || candles.length < CONFIG.minCandles) continue;
    const decision = buildDecision(next, symbol, candles);
    decisions.push(decision);
    const snap = state.snapshots.find((s) => s.symbol === symbol);
    if (!snap) continue;
    if (decision.action === 'BUY') {
      const blocked = riskAllows(next, decision, state);
      if (blocked) {
        logs.push({ id: id('log'), timestamp: Date.now(), level: 'RISK', source: next.name, message: `${symbol} buy rejected: ${blocked}` });
      } else {
        next = executeBuy(next, decision, snap.price);
        logs.push({ id: id('log'), timestamp: Date.now(), level: 'TRADE', source: next.name, message: `Opened LONG ${symbol} @ ${snap.price.toFixed(4)} | confidence ${decision.confidence.final} | ${decision.reason}` });
      }
    } else if (decision.action === 'SELL') {
      const open = next.openPositions.find((p) => p.symbol === symbol);
      if (open) {
        next = closePosition(next, open, snap.price, decision.reason);
        logs.push({ id: id('log'), timestamp: Date.now(), level: 'TRADE', source: next.name, message: `Closed ${symbol} by signal. P&L ${next.closedTrades[0].pnl.toFixed(2)}` });
      } else if (decision.rejectionReason) {
        logs.push({ id: id('log'), timestamp: Date.now(), level: 'AI', source: next.name, message: `${symbol} skipped: ${decision.rejectionReason}` });
      }
    } else if (decision.rejectionReason && Math.random() > 0.82) {
      logs.push({ id: id('log'), timestamp: Date.now(), level: 'AI', source: next.name, message: `${symbol} skipped: ${decision.rejectionReason}` });
    }
  }

  next = { ...next, equityCurve: [...next.equityCurve.slice(-199), { timestamp: Date.now(), equity: equity(next, state.snapshots) }] };
  return { agent: next, logs, decisions };
}

function updateApexWeights(agents: AgentState[]): AgentState[] {
  const scored = agents.map((agent) => {
    const eq = agent.equityCurve.at(-1)?.equity ?? agent.startingCash;
    const ret = (eq - agent.startingCash) / agent.startingCash;
    const wins = agent.closedTrades.filter((t) => t.pnl > 0).length;
    const winRate = agent.closedTrades.length ? wins / agent.closedTrades.length : 0.5;
    const score = clamp(1 + ret * 5 + (winRate - 0.5), 0.35, 1.8);
    return { ...agent, weight: agent.name === 'Apex Intelligence Core' ? 1.4 : score };
  });
  return scored;
}

export function engineStep(state: EngineState, live?: MarketSnapshot[] | null): EngineState {
  const withMarket = appendMarketTick(state, live);
  if (!withMarket.simulationRunning) return withMarket;
  const allLogs: EventLog[] = [];
  const agents = withMarket.agents.map((agent) => {
    const result = updateAgent(agent, withMarket);
    allLogs.push(...result.logs);
    return result.agent;
  });
  const weightedAgents = updateApexWeights(agents);
  const metaLog = allLogs.length ? [{ id: id('log'), timestamp: Date.now(), level: 'AI' as const, source: 'Apex Intelligence Core', message: `Processed ${allLogs.length} trade/risk/AI events this cycle. Agent weights updated from live simulated performance.` }] : [];
  return { ...withMarket, agents: weightedAgents, logs: [...metaLog, ...allLogs, ...withMarket.logs].slice(0, 300) };
}

export function runBacktest(symbol: SymbolKey, steps = 160, startingBalance = 10_000) {
  let state = createInitialState();
  state = { ...state, agents: state.agents.map((a) => ({ ...a, cash: startingBalance, startingCash: startingBalance, openPositions: [], closedTrades: [], equityCurve: [{ timestamp: Date.now(), equity: startingBalance }] })) };
  for (let i = 0; i < steps; i++) state = engineStep(state, null);
  return leaderboard(state).map((row) => ({ ...row, symbol }));
}

export function leaderboard(state: EngineState) {
  return state.agents.map((agent) => {
    const eq = equity(agent, state.snapshots);
    const trades = agent.closedTrades;
    const wins = trades.filter((t) => t.pnl > 0);
    const losses = trades.filter((t) => t.pnl <= 0);
    const grossWin = wins.reduce((s, t) => s + t.pnl, 0);
    const grossLoss = Math.abs(losses.reduce((s, t) => s + t.pnl, 0));
    const peak = Math.max(...agent.equityCurve.map((p) => p.equity), agent.startingCash);
    const trough = Math.min(...agent.equityCurve.map((p) => p.equity), eq);
    const drawdown = peak ? (peak - trough) / peak * 100 : 0;
    return {
      agent: agent.name,
      equity: eq,
      returnPct: (eq - agent.startingCash) / agent.startingCash * 100,
      trades: trades.length,
      winRate: trades.length ? wins.length / trades.length * 100 : 0,
      profitFactor: grossLoss ? grossWin / grossLoss : grossWin > 0 ? 99 : 0,
      drawdown,
      weight: agent.weight,
      openPositions: agent.openPositions.length,
    };
  }).sort((a, b) => b.equity - a.equity);
}

export function latestDecisions(state: EngineState): AgentDecision[] {
  return state.agents.slice(0, 5).flatMap((agent) => SYMBOLS.slice(0, 3).map((symbol) => buildDecision(agent, symbol, state.candles[symbol]))).sort((a, b) => b.confidence.final - a.confidence.final).slice(0, 12);
}

export function getSymbols() {
  return SYMBOLS;
}
