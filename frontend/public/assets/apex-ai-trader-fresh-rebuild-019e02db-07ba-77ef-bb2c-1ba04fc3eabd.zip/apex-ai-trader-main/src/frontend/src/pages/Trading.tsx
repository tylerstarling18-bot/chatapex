import {
  ActionBadge,
  DecisionReasoningPanel,
  ExecutionBadge,
} from "@/components/DecisionReasoningPanel";
import { Layout } from "@/components/Layout";
import { TradeReplayModal } from "@/components/TradeReplayModal";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useClosePosition,
  useLatestDecisions,
  useOpenPositions,
  usePortfolio,
  useTradeHistory,
  useTradeSnapshot,
} from "@/hooks/useQueries";
import { cn } from "@/lib/utils";
import type { AIDecisionLog, Trade } from "@/types";
import {
  ExecutionStatus,
  MarketCondition,
  StrategyMode,
  TradeAction,
  TradeStatus,
  TradeTag,
} from "@/types";
import {
  Activity,
  AlertTriangle,
  ChevronDown,
  ChevronRight,
  Loader2,
  Play,
  TrendingDown,
  TrendingUp,
  X,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";

// ─── Helpers ────────────────────────────────────────────────────────────────

const CONDITION_COLORS: Record<MarketCondition, string> = {
  [MarketCondition.StrongBullish]: "#22c55e",
  [MarketCondition.Bullish]: "#86efac",
  [MarketCondition.Neutral]: "#94a3b8",
  [MarketCondition.Ranging]: "#facc15",
  [MarketCondition.WeakBearish]: "#f97316",
  [MarketCondition.StrongBearish]: "#ef4444",
  [MarketCondition.HighVolatility]: "#a855f7",
  [MarketCondition.ManipulationRisk]: "#ec4899",
  [MarketCondition.LowLiquidityDanger]: "#f59e0b",
};

const STRATEGY_SHORT: Record<string, string> = {
  [StrategyMode.TrendFollowing]: "Trend",
  [StrategyMode.MeanReversion]: "Mean Rev",
  [StrategyMode.Scalping]: "Scalp",
  [StrategyMode.Defensive]: "Defensive",
  [StrategyMode.Observation]: "Observe",
};

function tradeStatusStyle(status: TradeStatus): {
  color: string;
  label: string;
} {
  switch (status) {
    case TradeStatus.TakeProfitHit:
      return { color: "#22c55e", label: "TP Hit" };
    case TradeStatus.StopLossHit:
      return { color: "#ef4444", label: "SL Hit" };
    case TradeStatus.Closed:
      return { color: "#94a3b8", label: "Closed" };
    case TradeStatus.Open:
      return { color: "#22d3ee", label: "Open" };
    case TradeStatus.Cancelled:
      return { color: "#6b7280", label: "Cancelled" };
    default:
      return { color: "#94a3b8", label: String(status) };
  }
}

function calcDuration(open: bigint, close: bigint): string {
  const ms = Number(close - open) / 1_000_000;
  if (ms < 0 || close === 0n) return "—";
  const secs = Math.floor(ms / 1000);
  if (secs < 60) return `${secs}s`;
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m`;
  return `${Math.floor(mins / 60)}h ${mins % 60}m`;
}

// ─── Performance summary ────────────────────────────────────────────────────

function PerformanceSummary({
  trades,
  decisions,
}: { trades: Trade[]; decisions: AIDecisionLog[] }) {
  const closed = trades.filter((t) => t.status !== TradeStatus.Open);
  const wins = closed.filter((t) => (t.pnl ?? 0) > 0).length;
  const winRate = closed.length > 0 ? (wins / closed.length) * 100 : 0;
  const totalPnl = closed.reduce((s, t) => s + (t.pnl ?? 0), 0);
  const pnls = closed.map((t) => t.pnl ?? 0);
  const best = pnls.length ? Math.max(...pnls) : 0;
  const worst = pnls.length ? Math.min(...pnls) : 0;
  const executed = decisions.filter(
    (d) => d.executionStatus === ExecutionStatus.Executed,
  );
  const avgConf = executed.length
    ? (executed.reduce((s, d) => s + d.decision.confidence, 0) /
        executed.length) *
      100
    : 0;

  const stats: { label: string; value: string; color?: string }[] = [
    {
      label: "Win Rate",
      value: `${winRate.toFixed(1)}%`,
      color: winRate >= 55 ? "#22c55e" : winRate >= 45 ? "#facc15" : "#ef4444",
    },
    { label: "Total Trades", value: String(closed.length) },
    {
      label: "Total P&L",
      value: `${totalPnl >= 0 ? "+" : ""}$${totalPnl.toFixed(2)}`,
      color: totalPnl >= 0 ? "#22c55e" : "#ef4444",
    },
    { label: "Best Trade", value: `+$${best.toFixed(2)}`, color: "#22c55e" },
    {
      label: "Worst Trade",
      value: `$${worst.toFixed(2)}`,
      color: worst < 0 ? "#ef4444" : "#94a3b8",
    },
    { label: "Avg AI Conf", value: `${avgConf.toFixed(1)}%`, color: "#a855f7" },
  ];

  return (
    <div
      className="sticky bottom-0 z-10 mt-4 rounded-xl px-4 py-3 flex flex-wrap gap-x-8 gap-y-2"
      style={{
        background: "rgba(10,15,30,0.95)",
        backdropFilter: "blur(24px)",
        borderTop: "1px solid rgba(6,182,212,0.2)",
      }}
      data-ocid="trading.performance_strip"
    >
      {stats.map(({ label, value, color }) => (
        <div key={label} className="flex items-center gap-2">
          <span className="text-xs font-mono text-muted-foreground uppercase">
            {label}
          </span>
          <span
            className="text-sm font-mono font-bold"
            style={{ color: color ?? "#e2e8f0" }}
          >
            {value}
          </span>
        </div>
      ))}
    </div>
  );
}

// ─── Decision Card ───────────────────────────────────────────────────────────

function DecisionCard({
  log,
  selected,
  onSelect,
  index,
}: {
  log: AIDecisionLog;
  selected: boolean;
  onSelect: () => void;
  index: number;
}) {
  const [expanded, setExpanded] = useState(false);
  const d = log.decision;
  const confPct = Math.round(d.confidence * 100);
  const confColor =
    confPct >= 70 ? "#22c55e" : confPct >= 50 ? "#eab308" : "#ef4444";
  const condColor = CONDITION_COLORS[d.marketCondition] ?? "#94a3b8";
  const ts = new Date(Number(d.timestamp) / 1_000_000);

  return (
    <motion.div
      initial={{ opacity: 0, x: -8 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: Math.min(index * 0.03, 0.3) }}
      className={cn(
        "rounded-xl p-3 cursor-pointer transition-all duration-200",
        selected
          ? "border border-cyan-500/50"
          : "border border-transparent hover:border-cyan-500/20",
      )}
      style={{
        background: selected
          ? "rgba(6,182,212,0.08)"
          : "rgba(255,255,255,0.03)",
      }}
      onClick={onSelect}
      data-ocid={`decisions.item.${index + 1}`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <span className="text-base font-mono font-bold text-cyan-300 shrink-0">
            {d.symbol}
          </span>
          <ActionBadge action={d.action} />
        </div>
        <div className="text-right shrink-0">
          <span
            className="text-sm font-mono font-bold"
            style={{ color: confColor }}
          >
            {confPct}%
          </span>
        </div>
      </div>

      {/* Confidence bar */}
      <div
        className="mt-2 h-1 rounded-full"
        style={{ background: "rgba(255,255,255,0.07)" }}
      >
        <div
          className="h-full rounded-full"
          style={{
            width: `${confPct}%`,
            background: "linear-gradient(90deg, #ef4444, #eab308 50%, #22c55e)",
            clipPath: `inset(0 ${100 - confPct}% 0 0 round 9999px)`,
          }}
        />
      </div>

      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-2">
        <span className="text-xs font-mono" style={{ color: condColor }}>
          {d.marketCondition}
        </span>
        <span className="text-xs font-mono text-purple-400">
          {STRATEGY_SHORT[d.strategyMode] ?? d.strategyMode}
        </span>
        <ExecutionBadge status={log.executionStatus} />
      </div>

      <div className="flex items-center justify-between mt-2">
        <span className="text-xs font-mono text-muted-foreground">
          {ts.toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit",
          })}
        </span>
        <button
          type="button"
          className="flex items-center gap-1 text-xs font-mono text-cyan-500 hover:text-cyan-300 transition-colors"
          onClick={(e) => {
            e.stopPropagation();
            setExpanded((v) => !v);
          }}
          aria-label="Toggle reasoning"
          data-ocid={`decisions.view_reasoning.${index + 1}`}
        >
          {expanded ? (
            <ChevronDown className="w-3 h-3" />
          ) : (
            <ChevronRight className="w-3 h-3" />
          )}
          Reasoning
        </button>
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div
              className="mt-3 p-2 rounded-lg text-xs font-mono leading-relaxed text-muted-foreground"
              style={{
                background: "rgba(6,182,212,0.05)",
                borderLeft: "2px solid rgba(6,182,212,0.3)",
              }}
            >
              {d.reasoning}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// ─── Close Position Confirmation ────────────────────────────────────────────

function CloseButton({ symbol }: { symbol: string }) {
  const [confirm, setConfirm] = useState(false);
  const mutation = useClosePosition();

  if (confirm) {
    return (
      <div className="flex items-center gap-1">
        <button
          type="button"
          className="text-xs font-mono font-semibold text-red-400 hover:text-red-300 px-2 py-0.5 rounded border border-red-500/30 transition-colors"
          onClick={() => mutation.mutate(symbol)}
          disabled={mutation.isPending}
          data-ocid="positions.confirm_button"
        >
          Confirm
        </button>
        <button
          type="button"
          className="text-xs font-mono text-muted-foreground hover:text-foreground px-1.5 py-0.5 rounded transition-colors"
          onClick={() => setConfirm(false)}
          data-ocid="positions.cancel_button"
        >
          Cancel
        </button>
      </div>
    );
  }

  return (
    <button
      type="button"
      className="text-xs font-mono text-muted-foreground hover:text-red-400 flex items-center gap-1 px-2 py-0.5 rounded border border-transparent hover:border-red-500/20 transition-all"
      onClick={() => setConfirm(true)}
      data-ocid="positions.delete_button"
    >
      <X className="w-3 h-3" /> Close
    </button>
  );
}
// Inline snapshot cells (per-row lazy fetch)

const TAG_CFG: Record<TradeTag, { label: string; color: string; bg: string }> =
  {
    [TradeTag.TextbookWin]: {
      label: "Textbook Win",
      color: "#22c55e",
      bg: "rgba(34,197,94,0.12)",
    },
    [TradeTag.TightStop]: {
      label: "Tight Stop",
      color: "#22c55e",
      bg: "rgba(34,197,94,0.12)",
    },
    [TradeTag.GoodDiscipline]: {
      label: "Good Discipline",
      color: "#22c55e",
      bg: "rgba(34,197,94,0.12)",
    },
    [TradeTag.GoodScaling]: {
      label: "Good Scaling",
      color: "#22c55e",
      bg: "rgba(34,197,94,0.12)",
    },
    [TradeTag.PrematureExit]: {
      label: "Premature Exit",
      color: "#ef4444",
      bg: "rgba(239,68,68,0.12)",
    },
    [TradeTag.OvertradeLoss]: {
      label: "Overtrade Loss",
      color: "#ef4444",
      bg: "rgba(239,68,68,0.12)",
    },
    [TradeTag.RegimeMismatch]: {
      label: "Regime Mismatch",
      color: "#f59e0b",
      bg: "rgba(245,158,11,0.12)",
    },
  };

function NetImpactCell({ tradeId }: { tradeId: string }) {
  const { data: snap, isLoading } = useTradeSnapshot(tradeId);
  if (isLoading)
    return <Loader2 className="w-3 h-3 animate-spin text-muted-foreground" />;
  if (!snap)
    return <span className="text-xs font-mono text-muted-foreground">—</span>;
  return (
    <span className="text-xs font-mono" style={{ color: "#f87171" }}>
      -{snap.netImpactPct.toFixed(3)}%
    </span>
  );
}

function TradeTagsCell({ tradeId }: { tradeId: string }) {
  const { data: snap } = useTradeSnapshot(tradeId);
  if (!snap || snap.tags.length === 0)
    return <span className="text-xs font-mono text-muted-foreground">—</span>;
  const shown = snap.tags.slice(0, 2);
  return (
    <div className="flex items-center gap-1 flex-wrap">
      {shown.map((tag) => {
        const cfg = TAG_CFG[tag];
        return (
          <span
            key={tag}
            className="text-xs font-mono px-1.5 py-0.5 rounded whitespace-nowrap"
            style={{ background: cfg.bg, color: cfg.color }}
          >
            {cfg.label}
          </span>
        );
      })}
    </div>
  );
}
// ─── Main Page ────────────────────────────────────────────────────────────────

export default function Trading() {
  const { data: decisions, isLoading: decLoading } = useLatestDecisions(20n);
  const { data: positions, isLoading: posLoading } = useOpenPositions();
  const { data: history, isLoading: histLoading } = useTradeHistory(50n);
  const { data: portfolio } = usePortfolio();
  const [selectedLog, setSelectedLog] = useState<AIDecisionLog | null>(null);
  const [replayTrade, setReplayTrade] = useState<Trade | null>(null);

  const handleSelect = (log: AIDecisionLog) => {
    setSelectedLog((prev) =>
      prev?.decision.id === log.decision.id ? null : log,
    );
  };

  const handleReplayOpen = (trade: Trade) => setReplayTrade(trade);
  const handleReplayClose = () => setReplayTrade(null);

  return (
    <Layout>
      <div
        className="flex flex-col min-h-full p-4 gap-4"
        data-ocid="trading.page"
      >
        {/* Page header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold font-mono flex items-center gap-2">
              <Activity className="w-5 h-5 text-cyan-400" />
              AI Decision Center
            </h1>
            <p className="text-xs text-muted-foreground mt-0.5 font-mono">
              Paper trading · AI-controlled execution · Full reasoning
              transparency
            </p>
          </div>
          {portfolio && (
            <div className="hidden sm:flex items-center gap-6">
              <div className="text-right">
                <div className="text-xs font-mono text-muted-foreground">
                  Portfolio Value
                </div>
                <div className="text-lg font-mono font-bold text-cyan-400">
                  $
                  {portfolio.totalValue.toLocaleString("en-US", {
                    minimumFractionDigits: 2,
                  })}
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs font-mono text-muted-foreground">
                  Day P&amp;L
                </div>
                <div
                  className="text-lg font-mono font-bold"
                  style={{
                    color: portfolio.dayPnl >= 0 ? "#22c55e" : "#ef4444",
                  }}
                >
                  {portfolio.dayPnl >= 0 ? "+" : ""}$
                  {portfolio.dayPnl.toFixed(2)}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* ── SECTION 1: Decision Feed + Reasoning ── */}
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_420px] gap-4 min-h-[420px]">
          {/* Left: Live Decision Feed */}
          <div className="glass-panel rounded-xl flex flex-col overflow-hidden">
            <div
              className="px-4 py-3 flex items-center justify-between shrink-0"
              style={{ borderBottom: "1px solid rgba(6,182,212,0.15)" }}
            >
              <div className="flex items-center gap-2">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500" />
                </span>
                <span className="text-xs font-mono uppercase tracking-wider text-cyan-400">
                  Live Decision Feed
                </span>
              </div>
              <span className="text-xs font-mono text-muted-foreground">
                {decisions?.length ?? 0} decisions
              </span>
            </div>
            <ScrollArea className="flex-1 p-3" data-ocid="decisions.list">
              {decLoading ? (
                <div className="space-y-2">
                  {Array.from({ length: 5 }, (_, i) => `dec-sk-${i}`).map(
                    (k) => (
                      <Skeleton key={k} className="h-20 w-full rounded-xl" />
                    ),
                  )}
                </div>
              ) : !decisions?.length ? (
                <div
                  className="flex flex-col items-center justify-center py-16 gap-3"
                  data-ocid="decisions.empty_state"
                >
                  <Activity className="w-8 h-8 text-muted-foreground" />
                  <p className="text-sm text-muted-foreground font-mono">
                    No decisions yet — AI is scanning
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {decisions.map((log, i) => (
                    <DecisionCard
                      key={log.decision.id}
                      log={log}
                      selected={selectedLog?.decision.id === log.decision.id}
                      onSelect={() => handleSelect(log)}
                      index={i}
                    />
                  ))}
                </div>
              )}
            </ScrollArea>
          </div>

          {/* Right: Reasoning Detail */}
          <div className="min-h-[360px] lg:min-h-0">
            <DecisionReasoningPanel log={selectedLog} />
          </div>
        </div>

        {/* ── SECTION 2: Trade Journal ── */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
          {/* Open Positions */}
          <div className="glass-panel rounded-xl overflow-hidden">
            <div
              className="px-4 py-3 flex items-center justify-between"
              style={{ borderBottom: "1px solid rgba(6,182,212,0.15)" }}
            >
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-mono uppercase tracking-wider text-cyan-400">
                  Open Positions
                </span>
                <span
                  className="text-xs font-mono px-1.5 py-0.5 rounded"
                  style={{
                    background: "rgba(6,182,212,0.15)",
                    color: "#22d3ee",
                  }}
                >
                  {positions?.length ?? 0}
                </span>
              </div>
            </div>
            <div className="overflow-x-auto">
              {posLoading ? (
                <div className="p-4 space-y-2">
                  {["p-sk-0", "p-sk-1", "p-sk-2"].map((k) => (
                    <Skeleton key={k} className="h-10 w-full" />
                  ))}
                </div>
              ) : !positions?.length ? (
                <div
                  className="py-10 text-center"
                  data-ocid="positions.empty_state"
                >
                  <Activity className="w-7 h-7 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground font-mono">
                    No open positions
                  </p>
                </div>
              ) : (
                <table className="w-full text-sm">
                  <thead>
                    <tr
                      style={{
                        borderBottom: "1px solid rgba(255,255,255,0.06)",
                      }}
                    >
                      {[
                        "Symbol",
                        "Side",
                        "Entry",
                        "Current",
                        "P&L",
                        "P&L%",
                        "SL",
                        "TP",
                        "",
                      ].map((h) => (
                        <th
                          key={h}
                          className="text-left px-3 py-2 text-xs font-mono uppercase text-muted-foreground whitespace-nowrap"
                        >
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {positions.map((pos, idx) => (
                      <tr
                        key={pos.symbol}
                        style={{
                          borderBottom: "1px solid rgba(255,255,255,0.04)",
                        }}
                        data-ocid={`positions.row.${idx + 1}`}
                      >
                        <td className="px-3 py-2 font-mono font-bold text-cyan-300">
                          {pos.symbol}
                        </td>
                        <td className="px-3 py-2">
                          <span
                            className="text-xs font-mono font-bold px-1.5 py-0.5 rounded"
                            style={{
                              background: "rgba(6,182,212,0.12)",
                              color: "#22d3ee",
                            }}
                          >
                            LONG
                          </span>
                        </td>
                        <td className="px-3 py-2 font-mono text-xs">
                          ${pos.averageEntryPrice.toFixed(2)}
                        </td>
                        <td className="px-3 py-2 font-mono text-xs">
                          ${pos.currentPrice.toFixed(2)}
                        </td>
                        <td
                          className="px-3 py-2 font-mono text-xs font-semibold"
                          style={{
                            color:
                              pos.unrealizedPnl >= 0 ? "#22c55e" : "#ef4444",
                          }}
                        >
                          {pos.unrealizedPnl >= 0 ? "+" : ""}$
                          {pos.unrealizedPnl.toFixed(2)}
                        </td>
                        <td
                          className="px-3 py-2 font-mono text-xs font-semibold"
                          style={{
                            color:
                              pos.unrealizedPnlPercent >= 0
                                ? "#22c55e"
                                : "#ef4444",
                          }}
                        >
                          {pos.unrealizedPnlPercent >= 0 ? "+" : ""}
                          {pos.unrealizedPnlPercent.toFixed(2)}%
                        </td>
                        <td
                          className="px-3 py-2 font-mono text-xs"
                          style={{ color: "#f87171" }}
                        >
                          ${pos.stopLoss.toFixed(2)}
                        </td>
                        <td
                          className="px-3 py-2 font-mono text-xs"
                          style={{ color: "#22c55e" }}
                        >
                          {pos.takeProfit != null
                            ? `$${pos.takeProfit.toFixed(2)}`
                            : "—"}
                        </td>
                        <td className="px-3 py-2">
                          <CloseButton symbol={pos.symbol} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>

          {/* Trade History */}
          <div className="glass-panel rounded-xl overflow-hidden">
            <div
              className="px-4 py-3 flex items-center gap-2"
              style={{ borderBottom: "1px solid rgba(6,182,212,0.15)" }}
            >
              <TrendingDown className="w-4 h-4 text-purple-400" />
              <span className="text-xs font-mono uppercase tracking-wider text-purple-400">
                Trade History
              </span>
              <span
                className="text-xs font-mono px-1.5 py-0.5 rounded"
                style={{
                  background: "rgba(168,85,247,0.12)",
                  color: "#c084fc",
                }}
              >
                {history?.length ?? 0}
              </span>
            </div>
            <ScrollArea className="h-64">
              <div className="overflow-x-auto">
                {histLoading ? (
                  <div className="p-4 space-y-2">
                    {["h-sk-0", "h-sk-1", "h-sk-2", "h-sk-3"].map((k) => (
                      <Skeleton key={k} className="h-9 w-full" />
                    ))}
                  </div>
                ) : !history?.length ? (
                  <div
                    className="py-10 text-center"
                    data-ocid="history.empty_state"
                  >
                    <Activity className="w-7 h-7 text-muted-foreground mx-auto mb-2" />
                    <p className="text-sm text-muted-foreground font-mono">
                      No trade history yet
                    </p>
                  </div>
                ) : (
                  <table className="w-full text-sm">
                    <thead>
                      <tr
                        style={{
                          borderBottom: "1px solid rgba(255,255,255,0.06)",
                        }}
                      >
                        {[
                          "Symbol",
                          "Action",
                          "Entry",
                          "Exit",
                          "Qty",
                          "P&L",
                          "P&L%",
                          "Cost",
                          "Tags",
                          "Status",
                          "Duration",
                          "",
                        ].map((h) => (
                          <th
                            key={h}
                            className="text-left px-3 py-2 text-xs font-mono uppercase text-muted-foreground whitespace-nowrap"
                          >
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {history.map((trade, idx) => {
                        const st = tradeStatusStyle(trade.status);
                        const pnl = trade.pnl ?? 0;
                        const pnlPct = trade.pnlPercent ?? 0;
                        return (
                          <tr
                            key={trade.id}
                            style={{
                              borderBottom: "1px solid rgba(255,255,255,0.04)",
                            }}
                            data-ocid={`history.row.${idx + 1}`}
                          >
                            <td className="px-3 py-2 font-mono font-bold text-cyan-300">
                              {trade.symbol}
                            </td>
                            <td className="px-3 py-2">
                              <ActionBadge action={trade.action} />
                            </td>
                            <td className="px-3 py-2 font-mono text-xs">
                              ${trade.entryPrice.toFixed(2)}
                            </td>
                            <td className="px-3 py-2 font-mono text-xs">
                              {trade.exitPrice != null
                                ? `$${trade.exitPrice.toFixed(2)}`
                                : "—"}
                            </td>
                            <td className="px-3 py-2 font-mono text-xs text-muted-foreground">
                              {trade.quantity.toFixed(4)}
                            </td>
                            <td
                              className="px-3 py-2 font-mono text-xs font-semibold"
                              style={{
                                color: pnl >= 0 ? "#22c55e" : "#ef4444",
                              }}
                            >
                              {pnl >= 0 ? "+" : ""}${pnl.toFixed(2)}
                            </td>
                            <td
                              className="px-3 py-2 font-mono text-xs font-semibold"
                              style={{
                                color: pnlPct >= 0 ? "#22c55e" : "#ef4444",
                              }}
                            >
                              {pnlPct >= 0 ? "+" : ""}
                              {pnlPct.toFixed(2)}%
                            </td>
                            <td className="px-3 py-2">
                              <NetImpactCell tradeId={trade.id} />
                            </td>
                            <td className="px-3 py-2">
                              <TradeTagsCell tradeId={trade.id} />
                            </td>
                            <td className="px-3 py-2">
                              <span
                                className="text-xs font-mono font-semibold"
                                style={{ color: st.color }}
                              >
                                {st.label}
                              </span>
                            </td>
                            <td className="px-3 py-2 font-mono text-xs text-muted-foreground">
                              {calcDuration(trade.openTime, trade.closeTime)}
                            </td>
                            <td className="px-3 py-2">
                              <button
                                type="button"
                                className="flex items-center gap-1 text-xs font-mono px-2 py-0.5 rounded transition-all border hover:border-cyan-500/40 hover:text-cyan-300"
                                style={{
                                  borderColor: "rgba(6,182,212,0.2)",
                                  color: "#94a3b8",
                                }}
                                onClick={() => handleReplayOpen(trade)}
                                aria-label={`Replay trade ${trade.symbol}`}
                                data-ocid={`history.replay_button.${idx + 1}`}
                              >
                                <Play className="w-3 h-3" /> Replay
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            </ScrollArea>
          </div>
        </div>

        {/* ── Trade Replay Modal ── */}
        <TradeReplayModal trade={replayTrade} onClose={handleReplayClose} />

        {/* ── SECTION 3: Performance Strip ── */}
        <PerformanceSummary
          trades={history ?? []}
          decisions={decisions ?? []}
        />
      </div>
    </Layout>
  );
}
