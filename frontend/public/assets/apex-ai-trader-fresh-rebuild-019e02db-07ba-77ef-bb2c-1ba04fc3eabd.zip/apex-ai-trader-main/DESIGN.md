# Apex AI Trader — Design System

## Overview
Institutional-grade AI crypto trading terminal. Dark cyberpunk aesthetic with glassmorphism, neon accents, and real-time data visualization. The entire interface is designed around the Apex Intelligence Core — an autonomous AI agent that continuously analyzes markets and executes trades.

## Visual Direction
**Tone:** Bold cyberpunk futurism meets institutional credibility. Intense, precise, data-driven — a command center for autonomous trading.
**Differentiation:** Every surface uses layered glassmorphism with neon accent borders that respond on hover. Monospace fonts throughout for authenticity and data focus.
**Mood:** High-stakes decision-making environment; trust in AI autonomy; vigilant market monitoring.

## Color Palette (OKLCH)
| Role | L | C | H | Usage |
|------|-------|--------|-------|------------------------------------------|
| Background | 0.08 | 0 | — | Deep near-black immersive base |
| Card | 0.12 | 0 | — | Lifted surfaces for panels & modals |
| Primary (Cyan) | 0.65 | 0.21 | 217 | CTAs, highlights, data emphasis |
| Secondary (Purple) | 0.55 | 0.18 | 300 | Risk metrics, secondary actions |
| Accent (Green) | 0.72 | 0.22 | 136 | Profit, positive actions, gains |
| Destructive (Red) | 0.55 | 0.20 | 10 | Losses, warnings, emergency stop |
| Foreground | 0.95 | 0 | — | Near-white text on dark backgrounds |
| Border | 0.18 | 0.05 | 217 | Subtle glass panel borders |
| Muted | 0.16 | 0.02 | 0 | Secondary text, disabled states |

## Typography
| Scale | Font | Weight | Usage |
|-------|------|--------|-------|
| Display (32px) | JetBrainsMono | 600 | AI status, main metrics |
| Body (16px) | GeistMono | 400 | Labels, descriptions, UI text |
| Small (12px) | GeistMono | 400 | Secondary data, timestamps |
| Mono (14px) | GeistMono | 400 | Code blocks, trade logs, prices |

## Structural Zones
| Zone | Background | Treatment | Purpose |
|------|------------|-----------|----------|
| Header | card/30 + backdrop-blur | Glass panel, cyan accent border | Navigation, branding, key metrics |
| Sidebar | card bg-12 | Minimal, dark, sharp edges | Navigation tree, settings |
| Main Content | background | Clear space for content panels | Dashboard, charts, logs |
| Card/Panel | card/30 + backdrop-blur-xl | Glass panel with cyan/purple/green borders, hover lift | Modular data displays, widgets |
| Footer | muted/20 | Minimal glass, bottom border | Status, disclaimers |

## Elevation & Depth
**Glassmorphism Layers:**
- **Base:** `bg-background` (0.08 L)
- **Elevated (Card):** `bg-card/30 backdrop-blur-xl` + `border border-cyan-500/20`
- **Interactive (Hover):** `border-cyan-500/40` + `shadow-lg shadow-cyan-500/20`
- **Modal/Popover:** `bg-popover/40 backdrop-blur-xl` + purple accent border

## Utilities & Patterns
**Glass Panel Class:** `.glass-panel` — reusable glassmorphic surface with cyan border and blur. Lifts on hover.
**Neon Accents:** `.neon-cyan`, `.neon-green`, `.neon-purple` — text color utilities for emphasis.
**Glow Effects:** `.glow-cyan`, `.glow-green`, `.glow-purple` — shadow-based glow for data highlights.
**Data Typography:** `.data-mono` — compact monospace for numbers, prices, metrics.
**Chart Annotations:** `.chart-entry` (green), `.chart-exit` (red), `.chart-sl` (orange), `.chart-marker` (circle base).
**Confidence Tiers:** `.confidence-tier-high` (green zone), `.confidence-tier-medium` (cyan zone), `.confidence-tier-low` (muted zone).
**Heatmap Cells:** `.heatmap-cell` base, then `.heatmap-high/medium/low` for color intensity.
**Table Rows:** `.table-header` (card/40 bg, uppercase labels), `.table-row` (border, hover lift).
**Status Badges:** `.status-connected` (green), `.status-disconnected` (muted), `.status-error` (red).
**Expandable:** `.expandable-trigger` (mono text, cyan hover), content animates with `.slide-in`.

## Component Patterns
**Buttons:** Cyan primary, purple secondary, red destructive. Always monospace. Hover: neon glow + 20% border lift.
**Cards:** Glass panel base. Title in display mono, content in body mono. Accent border matching purpose (cyan=info, purple=risk, green=profit).
**Inputs:** Dark background (0.14 L), cyan focus ring, monospace text for data entry.
**Badges:** Neon text on card/50 background. Monospace for consistency. Status badges: green=connected, muted=disconnected, red=error.
**Trade Log:** Mint monospace on dark. Cyan highlights for key data (entry, exit, P&L).
**Confidence Gauge:** Radial progress bar in cyan (bg) to green (fill). Percentage in large display mono.
**Risk Meter:** Horizontal progress bar in cyan-to-red gradient. Real-time update animation.
**Chart Markers:** Entry=green-400, Exit=red-500, Stop-loss=orange-500. Circular glyphs with confidence label.
**Heatmap Cells:** 8x8px cells with gradient: high=green-500/60, medium=cyan-500/40, low=muted/30. Interactive tooltips.
**Leaderboard:** Table with sortable columns, regime breakdown matrix, consistency ranking. Row hover lifts background.
**Expandable Sections:** Monospace trigger text that glows cyan on hover. Content slides in with animation.

## Motion & Animation
**Transition Default:** `all 0.3s cubic-bezier(0.4, 0, 0.2, 1)` — smooth curves for interactive states.
**Entrance:** Fade + subtle upward slide (0.3s) for modals, panels, sections. Class: `animate-slide-in`.
**Real-time Updates:** `.animate-pulse-gentle` (infinite 2s) for live metrics. `.animate-glow-pulse` for neon accents.
**Hover:** Instant border color lift, shadow glow appears. Table rows lift background.
**Disable State:** Opacity 0.5, no hover effects. Cursor not-allowed on inputs.

## Constraints & Guardrails
- **No rainbow palettes:** Cyan, purple, green, red only. All other text is white/muted.
- **No full-page gradients:** Depth through layers and composition.
- **Monospace everywhere:** All data, labels, code. Ensure readability with tight letter-spacing.
- **Dark mode only:** No light theme. Immersive deep black enforces focus.
- **No arbitrary Tailwind colors:** All tokens via CSS variables.
- **Glassmorphism only:** No solid card backgrounds; always `backdrop-blur-xl` + transparency.
- **Neon accents sparingly:** Reserve bright neon for interactive states, emphasis, and real-time data only.

## Signature Detail
**The Glass Border Glow:** Every interactive panel has a subtle cyan border (`border-cyan-500/20`) that strengthens to `border-cyan-500/40` on hover. This single detail — combined with `backdrop-blur-xl` — creates the perception of a **futuristic holographic interface**. It's the visual signature of an advanced AI trading system.

## New Pages Overview
**Candlestick Chart** — Multi-timeframe price chart with dual overlays: (1) Historical trade markers (entry/exit/SL with confidence scores), (2) Live AI signals (entry/exit zones, risk areas with confidence tier coloring and probability estimates). Toggle filters by confidence and outcome.
**Strategy Competition Arena** — Six AI agents competing head-to-head through same historical periods. Leaderboard (return%, Sharpe, drawdown, win rate), regime breakdown matrix, consistency ranking, risk-adjusted ranking. Date range picker.
**Exchange Connections** — Cards for Binance/Coinbase/Kraken/Bybit/OKX. API key input per exchange. Connected/disconnected/error status badges. Balance display. Order history table. Phase 1 read-only disclaimer.

## Brand Expression
Apex AI Trader is not a typical fintech dashboard. It is a **command center for an autonomous intelligence**. Every design choice — monospace typography, glassmorphism, neon accents, high contrast — reinforces that you are interfacing with a powerful, precise, alien intelligence. The AI is the product. The UI is its control surface. New pages extend this vision: candlestick overlays show AI thinking visually, competition arena displays strategic diversity, exchange connections bridge to market reality.
